#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

namespace fs = std::filesystem;

static uint64_t splitmix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

struct Sampler {
    uint64_t seed = 0;
    uint64_t target = 0;
    uint64_t source_count = 0;
    uint64_t selected = 0;
    uint64_t next_pos = 0;
    long double phase = 0.5L;
    bool have_last = false;
    uint64_t last = 0;
    uint64_t first = 0;
    std::ofstream out;
    fs::path path;

    void update_next(uint64_t current_pos = 0, bool retry_duplicate = false) {
        if (selected >= target) {
            next_pos = std::numeric_limits<uint64_t>::max();
            return;
        }
        if (retry_duplicate) {
            next_pos = current_pos + 1;
            return;
        }
        long double x = (static_cast<long double>(selected) + phase)
                      * static_cast<long double>(source_count)
                      / static_cast<long double>(target);
        uint64_t p = static_cast<uint64_t>(x);
        if (p >= source_count) p = source_count - 1;
        if (p <= current_pos && selected > 0) p = current_pos + 1;
        next_pos = p;
    }
};

int main(int argc, char** argv) {
    if (argc < 5) {
        std::cerr << "Usage: " << argv[0]
                  << " SOURCE_UINT64 OUT_DIR TARGET_KEYS SEED [SEED ...]\n";
        return 2;
    }
    const fs::path src = argv[1];
    const fs::path outdir = argv[2];
    const uint64_t target = std::strtoull(argv[3], nullptr, 10);
    const char* label_env = std::getenv("SAMPLE_LABEL");
    const std::string label = label_env && *label_env ? label_env : "fb";
    if (target == 0) {
        std::cerr << "TARGET_KEYS must be > 0\n";
        return 2;
    }

    std::ifstream in(src, std::ios::binary);
    if (!in) {
        std::cerr << "Cannot open source: " << src << "\n";
        return 2;
    }
    const auto bytes = fs::file_size(src);
    if (bytes == 0 || bytes % sizeof(uint64_t) != 0) {
        std::cerr << "Source size is not a positive multiple of uint64_t: "
                  << bytes << " bytes\n";
        return 2;
    }

    // Accept both formats encountered in SOSD exports:
    //   (1) the original RQ6 count-prefixed file, and
    //   (2) a raw uint64 stream with no header.
    // The generated per-seed samples are always raw uint64 streams.
    uint64_t first = 0;
    in.read(reinterpret_cast<char*>(&first), sizeof(first));
    if (!in) {
        std::cerr << "Cannot read the first uint64 from source\n";
        return 2;
    }
    const bool count_prefixed =
        first >= target && first <= (std::numeric_limits<uint64_t>::max() - sizeof(uint64_t)) / sizeof(uint64_t) &&
        sizeof(uint64_t) + first * sizeof(uint64_t) == bytes;
    const uint64_t count = count_prefixed ? first : bytes / sizeof(uint64_t);
    if (count < target) {
        std::cerr << "Source contains fewer than target keys: count=" << count
                  << " target=" << target << "\n";
        return 2;
    }
    if (count_prefixed) {
        in.clear();
        in.seekg(static_cast<std::streamoff>(sizeof(uint64_t)), std::ios::beg);
    } else {
        in.clear();
        in.seekg(0, std::ios::beg);
    }

    fs::create_directories(outdir);
    std::vector<Sampler> samplers;
    for (int i = 4; i < argc; ++i) {
        Sampler s;
        s.seed = std::strtoull(argv[i], nullptr, 10);
        s.target = target;
        s.source_count = count;
        const uint64_t h = splitmix64(s.seed ^ 0x46414345424f4f4bULL);
        s.phase = (static_cast<long double>((h % 1000000000ULL) + 1ULL)
                   / 1000000001.0L);
        s.path = outdir / (label + "_" + std::to_string(target / 1000000ULL)
                         + "M_seed" + std::to_string(s.seed) + ".uint64");
        s.out.open(s.path, std::ios::binary | std::ios::trunc);
        if (!s.out) {
            std::cerr << "Cannot create " << s.path << "\n";
            return 2;
        }
        s.update_next();
        samplers.push_back(std::move(s));
    }

    constexpr size_t CHUNK = 1u << 20;
    std::vector<uint64_t> buf(CHUNK);
    uint64_t global_pos = 0;
    while (global_pos < count) {
        const uint64_t remain = count - global_pos;
        const size_t want = static_cast<size_t>(std::min<uint64_t>(remain, CHUNK));
        in.read(reinterpret_cast<char*>(buf.data()), want * sizeof(uint64_t));
        if (static_cast<size_t>(in.gcount()) != want * sizeof(uint64_t)) {
            std::cerr << "Unexpected EOF at key " << global_pos << "\n";
            return 2;
        }
        for (size_t j = 0; j < want; ++j, ++global_pos) {
            const uint64_t key = buf[j];
            for (auto& s : samplers) {
                if (s.selected >= s.target || global_pos < s.next_pos) continue;
                if (s.have_last && key == s.last) {
                    s.update_next(global_pos, true);
                    continue;
                }
                if (!s.have_last) s.first = key;
                s.out.write(reinterpret_cast<const char*>(&key), sizeof(key));
                if (!s.out) {
                    std::cerr << "Write failed: " << s.path << "\n";
                    return 2;
                }
                s.last = key;
                s.have_last = true;
                ++s.selected;
                s.update_next(global_pos, false);
            }
        }
    }

    for (auto& s : samplers) {
        s.out.close();
        if (s.selected != s.target) {
            std::cerr << "Seed " << s.seed << " produced only " << s.selected
                      << " sampled keys\n";
            return 3;
        }
        const auto sz = fs::file_size(s.path);
        if (sz != s.target * sizeof(uint64_t)) {
            std::cerr << "Output size mismatch for " << s.path << "\n";
            return 3;
        }

        // Verify global uniqueness (not only adjacent uniqueness) and rewrite
        // in sorted order. This makes the experiment loader's exact-cardinality
        // check deterministic even if the source file were not sorted.
        std::vector<uint64_t> verify(static_cast<size_t>(s.target));
        {
            std::ifstream vf(s.path, std::ios::binary);
            vf.read(reinterpret_cast<char*>(verify.data()),
                    static_cast<std::streamsize>(verify.size() * sizeof(uint64_t)));
            if (!vf) {
                std::cerr << "Verification read failed: " << s.path << "\n";
                return 3;
            }
        }
        std::sort(verify.begin(), verify.end());
        auto ue = std::unique(verify.begin(), verify.end());
        if (ue != verify.end()) {
            const auto uniq = static_cast<uint64_t>(std::distance(verify.begin(), ue));
            std::cerr << "Seed " << s.seed << " sample contains duplicates: unique="
                      << uniq << " target=" << s.target << "\n";
            return 3;
        }
        {
            std::ofstream vf(s.path, std::ios::binary | std::ios::trunc);
            vf.write(reinterpret_cast<const char*>(verify.data()),
                     static_cast<std::streamsize>(verify.size() * sizeof(uint64_t)));
            if (!vf) {
                std::cerr << "Verification rewrite failed: " << s.path << "\n";
                return 3;
            }
        }

        std::ofstream meta(s.path.string() + ".meta.txt");
        const char* source_name_env = std::getenv("SAMPLE_SOURCE_NAME");
        const std::string source_name = source_name_env && *source_name_env
            ? source_name_env : src.filename().string();
        meta << "source=<SOSD_ROOT>/" << source_name << "\n"
             << "source_format=" << (count_prefixed ? "count_prefixed" : "raw_uint64") << "\n"
             << "source_count=" << count << "\n"
             << "target_keys=" << s.target << "\n"
             << "seed=" << s.seed << "\n"
             << std::setprecision(18) << "systematic_phase=" << static_cast<double>(s.phase) << "\n"
             << "first_key=" << s.first << "\n"
             << "last_key=" << s.last << "\n";
        std::cout << "[OK] seed=" << s.seed << " keys=" << s.selected
                  << " file=" << s.path << "\n";
    }
    return 0;
}
