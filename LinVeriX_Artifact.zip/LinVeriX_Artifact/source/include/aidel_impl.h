#ifndef __AIDEL_IMPL_H__
#define __AIDEL_IMPL_H__

#include "aidel.h"
#include "util.h"
#include "aidel_model.h"
#include "aidel_model_impl.h"
#include "piecewise_linear_model.h"
#include <algorithm>
#include <numeric>

namespace aidel {

template<class key_t, class val_t>
inline AIDEL<key_t, val_t>::AIDEL()
    : maxErr(64), learning_step(1000), learning_rate(0.1f)
{}

template<class key_t, class val_t>
inline AIDEL<key_t, val_t>::AIDEL(int _maxErr, int _learning_step, float _learning_rate)
    : maxErr(_maxErr), learning_step(_learning_step), learning_rate(_learning_rate)
{}

template<class key_t, class val_t>
AIDEL<key_t, val_t>::~AIDEL() = default;

// ====================== train models ========================
template<class key_t, class val_t>
void AIDEL<key_t, val_t>::train(const std::vector<key_t> &keys,
                                const std::vector<val_t> &vals, size_t _maxErr)
{
    assert(keys.size() == vals.size());
    maxErr = _maxErr;
    std::cout << "Training begin, length of training_data is: " << keys.size()
              << " ,maxErr: " << maxErr << std::endl;

    model_keys.clear();
    aimodels.clear();
    model_prefix_.clear();
    total_keys_ = keys.size();

    if (keys.empty()) {
        COUT_THIS("[aidle] get models -> 0");
        return;
    }

    const size_t base_step = (learning_step > 0) ? static_cast<size_t>(learning_step) : size_t(1);
    size_t expected_models = std::max<size_t>(1, keys.size() / std::max<size_t>(1, base_step));
    model_keys.reserve(expected_models + 8);
    aimodels.reserve(expected_models + 8);
    model_prefix_.reserve(expected_models + 8);

    size_t start = 0;
    size_t end = std::min(base_step, keys.size());

    while (start < keys.size()) {
        lrmodel_type model;
        model.train(keys.begin() + start, end - start);
        size_t err = model.get_maxErr();

        if (err == maxErr) {
            append_model(model, keys.begin() + start, vals.begin() + start, end - start, static_cast<int>(err));
            start = end;
            end = std::min(start + base_step, keys.size());
        } else if (err < maxErr) {
            if (end >= keys.size()) {
                append_model(model, keys.begin() + start, vals.begin() + start, end - start, static_cast<int>(err));
                start = end;
                end = std::min(start + base_step, keys.size());
            } else {
                end = std::min(end + base_step, keys.size());
            }
        } else { // err > maxErr
            size_t offset = backward_train(keys.begin() + start, vals.begin() + start,
                                           static_cast<uint32_t>(end - start),
                                           static_cast<int>(std::max<size_t>(1, static_cast<size_t>(base_step * std::max(0.01f, learning_rate)))));
            start += offset;
            end = std::min(start + base_step, keys.size());
        }
    }

    model_prefix_.resize(aimodels.size());
    {
        size_t running = 0;
        for (size_t i=0;i<aimodels.size();++i){
            model_prefix_[i] = running;
            running += aimodels[i].get_capacity();   
        }
    }

    COUT_THIS("[aidle] get models -> " << model_keys.size());
    assert(model_keys.size() == aimodels.size());
}


template<class key_t, class val_t>
size_t AIDEL<key_t, val_t>::backward_train(const typename std::vector<key_t>::const_iterator &keys_begin,
                                           const typename std::vector<val_t>::const_iterator &vals_begin,
                                           uint32_t size_u32, int step_i)
{
    size_t size = static_cast<size_t>(size_u32);
    if (size == 0) return 0;

    size_t step = (step_i <= 0) ? size_t(1) : static_cast<size_t>(step_i);
    float lr = (learning_rate <= 0.f) ? 0.1f : learning_rate;
    lr = std::min(std::max(lr, 0.01f), 0.9f);

    while (true) {
        size_t end = size;
        end = (end > step) ? (end - step) : size_t(1);

        while (end > 0) {
            lrmodel_type model;
            model.train(keys_begin, end);
            size_t err = model.get_maxErr();
            if (err <= maxErr) {
                append_model(model, keys_begin, vals_begin, end, static_cast<int>(err));
                return end;
            }
            if (end <= step) break;
            end -= step;
        }

        if (step == 1) {
            lrmodel_type model;
            model.train(keys_begin, 1);
            size_t err = model.get_maxErr();
            append_model(model, keys_begin, vals_begin, 1, static_cast<int>(err));
            return 1;
        }

        size_t next_step = static_cast<size_t>(step * lr);
        step = std::max<size_t>(1, next_step);
    }
}

template<class key_t, class val_t>
void AIDEL<key_t, val_t>::append_model(lrmodel_type &model,
                                       const typename std::vector<key_t>::const_iterator &keys_begin,
                                       const typename std::vector<val_t>::const_iterator &vals_begin,
                                       size_t size, int err)
{
    assert(size >= 1);
    assert(static_cast<size_t>(err) <= maxErr);
    key_t key = *(keys_begin + (size - 1));
    model_keys.push_back(key);
    aimodels.emplace_back(model, keys_begin, vals_begin, size, maxErr);
}

template<class key_t, class val_t>
typename AIDEL<key_t, val_t>::aidelmodel_type*
AIDEL<key_t, val_t>::find_model(const key_t &key)
{
    size_t mk_sz = model_keys.size();
    assert(mk_sz > 0);
    size_t model_pos = binary_search_branchless(&model_keys[0], mk_sz, key);
    if (model_pos >= aimodels.size())
        model_pos = aimodels.size() - 1;
    return &aimodels[model_pos];
}

// 全局预测
template<class key_t, class val_t>
inline size_t AIDEL<key_t, val_t>::predict(const key_t& key) const {
    if (aimodels.empty()) return 0;
    size_t mk_sz = model_keys.size();
    size_t pos = binary_search_branchless(const_cast<key_t*>(&model_keys[0]), mk_sz, key);
    if (pos >= aimodels.size()) pos = aimodels.size() - 1;

    size_t base = (pos < model_prefix_.size()) ? model_prefix_[pos] : 0;
    size_t local = aimodels[pos].predict_public(key);  // 窗口内索引
    size_t cap   = aimodels[pos].get_capacity();
    if (cap == 0) return base;
    if (local >= cap) local = cap - 1;

    size_t g = base + local;
    if (g >= total_keys_) {
        if (total_keys_ == 0) return 0;
        g = total_keys_ - 1;
    }
    return g;
}

// 打印 / 自检
template<class key_t, class val_t>
void AIDEL<key_t, val_t>::print_models()
{
    for (size_t i = 0; i < model_keys.size(); i++) {
        std::cout << "model " << i << " ,key:" << model_keys[i] << " ->";
        aimodels[i].print_model();
    }
}

template<class key_t, class val_t>
void AIDEL<key_t, val_t>::self_check()
{
    for (size_t i = 0; i < model_keys.size(); i++) {
        aimodels[i].self_check();
    }
}

// CRUD
template<class key_t, class val_t>
inline result_t AIDEL<key_t, val_t>::find(const key_t &key, val_t &val)
{
    return find_model(key)->con_find_retrain(key, val);
}

template<class key_t, class val_t>
inline result_t AIDEL<key_t, val_t>::find_with_prediction_bias(
    const key_t &key, val_t &val, int64_t prediction_bias,
    size_t *correction_comparisons)
{
    return find_model(key)->con_find_retrain_with_prediction_bias(
        key, val, prediction_bias, correction_comparisons);
}

template<class key_t, class val_t>
inline result_t AIDEL<key_t, val_t>::insert(const key_t& key, const val_t& val)
{
    return find_model(key)->con_insert_retrain(key, val);
}

template<class key_t, class val_t>
inline result_t AIDEL<key_t, val_t>::update(const key_t& key, const val_t& val)
{
    return find_model(key)->update(key, val);
}

template<class key_t, class val_t>
inline result_t AIDEL<key_t, val_t>::remove(const key_t& key)
{
    return find_model(key)->remove(key);
}

// 扫描
template<class key_t, class val_t>
int AIDEL<key_t, val_t>::scan(const key_t &key, const size_t n, std::vector<std::pair<key_t, val_t>> &result)
{
    if (aimodels.empty() || n == 0) return 0;

    size_t remaining = n;
    size_t model_pos = binary_search_branchless(&model_keys[0], model_keys.size(), key);
    if (model_pos >= aimodels.size())
        model_pos = aimodels.size() - 1;

    key_t cur_key = key;
    while (remaining > 0 && model_pos < aimodels.size()) {
        remaining = aimodels[model_pos].scan(cur_key, remaining, result);
        ++model_pos;
    }
    return static_cast<int>(remaining);
}

template<class key_t, class val_t>
size_t AIDEL<key_t, val_t>::model_size(){
    return aimodels.size();
}

} // namespace aidel
#endif
