#ifndef __LEVELINDEX_H__
#define __LEVELINDEX_H__

#include "util.h"
#include <cmath>
#include <cstdlib>
#include <cassert>
#include <vector>
#include <limits>
#include <utility>
#include <type_traits>

template<class key_t>
class LevelIndex {

public:
    using key_type = key_t;

    explicit inline LevelIndex()
        : page_size(64), top_size(0), capacity(0), keys(nullptr), tables(nullptr) {}

    explicit inline LevelIndex(std::vector<key_t> &data)
        : page_size(64), keys(nullptr), tables(nullptr) {
        capacity = data.size();
        stride = page_size * page_size;
        assert(capacity > 0);
        int hang = data.size() % page_size;
        hang = hang > 0 ? page_size - hang : 0;

        keys = (key_t *) aligned_alloc(CACHELINE_SIZE, (capacity + hang) * sizeof(key_t));
        for (size_t i = 0; i < capacity; i++) {
            keys[i] = data[i];
        }
        for (size_t i = capacity; i < (capacity + hang); i++) {
            keys[i] = std::numeric_limits<key_t>::max();
        }

        if (capacity <= page_size) {
            COUT_THIS("[Root-0level], capacity:" << capacity);
        } else if (capacity <= stride) {
            onelevel(hang);
        } else {
            twolevel(hang);
        }
    }

    ~LevelIndex() {
        if (keys)
            free(keys);
        if (tables)
            free(tables);
        keys = nullptr;
        tables = nullptr;
    }


    size_t find(const key_t key) const {
        if (capacity <= page_size) {
            return ls_avx(keys, (int)page_size, key);
        }
        if (capacity <= stride) {
            return find_1level(key);
        }
        return find_2level(key);
    }

    inline size_t size() const { return capacity; }
    inline size_t page_size_value() const { return page_size; }
    inline size_t num_segments() const { return (capacity + page_size - 1) / page_size; }

    inline std::pair<size_t,size_t> segment_range(size_t seg) const {
        size_t begin = seg * page_size;
        size_t end = std::min(begin + page_size, capacity);
        return {begin, end};
    }

    inline key_t key_at(size_t idx) const {
        assert(idx < capacity);
        return keys[idx];
    }

    inline std::vector<std::pair<uint64_t,uint64_t>> export_sorted_kv_for_mst_count() const {
        std::vector<std::pair<uint64_t,uint64_t>> kv;
        kv.reserve(capacity);
        for (size_t i=0;i<capacity;++i) {
            kv.emplace_back(static_cast<uint64_t>(keys[i]), 1ull);
        }
        return kv;
    }

private:

    static inline int ls_avx(const key_t* arr, int n, key_t key) {
        if constexpr (std::is_same<key_t, uint64_t>::value) {
            return linear_search_avx(reinterpret_cast<const int64_t*>(arr), n, static_cast<int64_t>(key));
        } else if constexpr (std::is_same<key_t, int64_t>::value) {
            return linear_search_avx(reinterpret_cast<const int64_t*>(arr), n, key);
        } else {
            return linear_search_avx(reinterpret_cast<const int*>(arr), n, static_cast<int>(key));
        }
    }

    void onelevel(size_t hang) {
        top_size = static_cast<int>(std::ceil((capacity + hang) / static_cast<double>(page_size)));
        COUT_THIS("[Root-1level] capacity+hang:" << capacity + hang << " ,top_size: " << top_size);
        tables = (key_t *) aligned_alloc(CACHELINE_SIZE, top_size * sizeof(key_t));
        for (int i = 0; i < top_size; i++) {
            size_t pos = (i + 1) * page_size;
            tables[i] = (pos <= capacity) ? keys[pos - 1] : std::numeric_limits<key_t>::max();
        }
    }

    void twolevel(size_t hang) {
        top_size = static_cast<int>(std::ceil((capacity + hang) / static_cast<double>(page_size * page_size)));
        COUT_THIS("[Root-2level] top_size: " << top_size);
        tables = (key_t *) aligned_alloc(CACHELINE_SIZE, top_size * (page_size + 1) * sizeof(key_t));
        for (int i = 0; i < top_size * (int)page_size; i++) {
            size_t pos = (i + 1) * page_size;
            tables[top_size + i] = (pos <= capacity) ? keys[pos - 1] : std::numeric_limits<key_t>::max();
        }
        for (int i = 0; i < top_size; i++) {
            tables[i] = tables[top_size + (i + 1) * page_size - 1];
        }
    }

    size_t find_1level(const key_t key) const {
        int i = binary_search_branchless(tables, top_size, key);
        int pos = i * (int)page_size;
        memory_fence();
        int offset = ls_avx(&keys[pos], (int)page_size, key);
        return pos + offset;
    }

    size_t find_2level(const key_t key) const {
        int i = binary_search_branchless(tables, top_size, key);
        memory_fence();
        int j = ls_avx(tables + top_size + i * (int)page_size, (int)page_size, key);
        int pos = i * (int)stride + j * (int)page_size;
        memory_fence();
        int offset = ls_avx(&keys[pos], (int)page_size, key);
        return pos + offset;
    }

private:
    size_t page_size = 64;
    size_t stride = 0;
    size_t top_size = 0;
    size_t capacity = 0;
    key_t *keys = nullptr;
    key_t *tables = nullptr;
};


template<class key_t>
class TwoLevelIndex {
    const key_t* data_;
    int k1_, k2_, k2stride_, page_size_;
    key_t* tables_;

public:
    explicit TwoLevelIndex(std::vector<key_t>& data, int k2, int page_size)
            : k2_(k2), page_size_(page_size) {
        int hang = data.size() % page_size;
        if (hang > 0) {
            for (int i = 0; i < page_size - hang; i++) {
                data.push_back(std::numeric_limits<key_t>::max());
            }
        }

        data_ = &data[0];
        k1_ = static_cast<int>(std::ceil(data.size() / static_cast<double>(k2_ * page_size_)));
        tables_ = (key_t*) aligned_alloc(CACHELINE_SIZE, k1_ * (k2 + 1) * sizeof(key_t));
        k2stride_ = k2 * page_size_;

        for (int i = 0; i < k1_ * k2_; i++) {
            tables_[k1_ + i] = ((i + 1) * page_size_ > data.size()) ? std::numeric_limits<key_t>::max() : data[(i + 1) * page_size_ - 1];
        }

        for (int i = 0; i < k1_; i++) {
            tables_[i] = tables_[k1_ + (i + 1) * k2 - 1];
        }
    }

    ~TwoLevelIndex() {
        free(tables_);
    }

    int find(int key) {
        int i = binary_search_branchless(tables_, k1_, key);
        int j = linear_search_avx(tables_ + k1_ + i * k2_, k2_, key);
        int pos = i * k2stride_ + j * page_size_;
        int offset = linear_search_avx(data_ + pos, page_size_, key);
        return pos + offset;
    }
};

#endif