#pragma once
#include <unordered_map>
#include <vector>
#include <algorithm>
#include "linucb_controller.h"
#include "metrics_collector.h"

// 注意：make_context / contexts_from_stats / compose_reward 已在 metrics_collector.h 定义
// 本文件只提供将 {seg_id -> 特征向量} 适配为 LinUCB 所需的 ArmContext 数组，避免重定义冲突。

static inline std::vector<ArmContext>
build_arm_contexts_from_map(const std::unordered_map<int, std::vector<double>>& feat_map,
                            const std::vector<SegmentStats>& stats,
                            double default_cost_ms = 1.0) {
  std::vector<ArmContext> out;
  out.reserve(feat_map.size());
  for (const auto& kv : feat_map) {
    const int seg_id = kv.first;
    ArmContext a;
    a.arm_id = static_cast<uint32_t>(seg_id);
    a.x = kv.second;
    // 如果能从 stats 拿到该 seg 的估计成本，则使用之；否则使用默认值
    double est_cost = default_cost_ms;
    if (seg_id >= 0 && seg_id < (int)stats.size() && stats[seg_id].seg_id == seg_id) {
      est_cost = std::max(1.0, stats[seg_id].est_cost_ms);
    }
    a.est_cost = est_cost;
    out.emplace_back(std::move(a));
  }
  return out;
}