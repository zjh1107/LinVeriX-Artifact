#pragma once
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cstdint>

struct SegmentStats {
  int seg_id=0;
  double max_err=0, err_slope=0, qps=0, write_ratio=0, mean_read_ms=0, size_mb=0,
         last_retrain_sec=0, maintenance_age_sec=0, est_cost_ms=0, drift=0,
         correction_steps_per_query=0, p99_read_ms=0, warmup_p99_read_ms=0;
  uint64_t correction_queries=0, tail_latency_samples=0, warmup_tail_latency_samples=0;
};

inline std::vector<double> make_context(const SegmentStats& s){
  return {
    std::clamp(s.max_err,0.0,1e6)/1e3,
    s.err_slope,
    std::clamp(s.qps,0.0,1e9)/1e6,
    std::clamp(s.write_ratio,0.0,1.0),
    std::clamp(s.mean_read_ms,0.0,5e3)/1e2,
    std::clamp(s.correction_steps_per_query,0.0,1e6)/1e2,
    std::clamp(s.size_mb,0.0,1e6)/1e3,
    std::clamp(s.last_retrain_sec,0.0,1e6)/1e3,
    std::clamp(s.est_cost_ms,0.0,1e6)/1e3,
    std::clamp(s.drift,0.0,1e6)/1e4,
    1.0, 0.0 // bias + reserved
  };
}

inline std::unordered_map<int, std::vector<double>>
contexts_from_stats(const std::vector<SegmentStats>& v){
  std::unordered_map<int, std::vector<double>> m; m.reserve(v.size());
  for (auto& s : v) m[s.seg_id] = make_context(s);
  return m;
}

inline double compose_reward(double d_mean_read_ms, double d_err, double cost_ms){
  double r = 0.5*(-d_mean_read_ms/10.0) + 0.5*(-d_err/100.0) - 0.2*(cost_ms/100.0);
  return std::max(-1.0, std::min(1.0, r));
}
