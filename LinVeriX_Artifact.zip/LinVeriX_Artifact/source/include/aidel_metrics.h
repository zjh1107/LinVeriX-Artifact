#pragma once
#include <vector>
#include <algorithm>
#include <cstdint>

template<typename AIDEL, typename KeyT>
struct PredictionErrorStats {
  uint64_t max_err=0;
  double mean_err=0;
  double p95=0;
  double p99=0;
  size_t n=0;
};

inline double percentile_interp_(const std::vector<uint64_t>& v, double q){
  if(v.empty()) return 0;
  double idx = q*(v.size()-1);
  size_t lo = (size_t)idx;
  size_t hi = lo==v.size()-1 ? lo : lo+1;
  double w = idx - lo;
  return (1-w)*v[lo] + w*v[hi];
}

template<typename AIDEL, typename KeyT>
PredictionErrorStats<AIDEL,KeyT>
compute_error_stats(const AIDEL* model, const std::vector<KeyT>& sorted_keys){
  PredictionErrorStats<AIDEL,KeyT> s;
  size_t n = sorted_keys.size();
  if(!n) return s;
  std::vector<uint64_t> errs; errs.reserve(n);
  long double sum=0;
  uint64_t mx=0;
  for(size_t i=0;i<n;++i){
    size_t pred = model->predict(sorted_keys[i]);
    if (pred >= n) pred = n-1;
    uint64_t e = pred>i ? pred-i : i-pred;
    if(e>mx) mx=e;
    sum += e;
    errs.push_back(e);
  }
  std::sort(errs.begin(), errs.end());
  s.max_err = mx;
  s.mean_err = (double)(sum/n);
  s.p95 = percentile_interp_(errs, 0.95);
  s.p99 = percentile_interp_(errs, 0.99);
  s.n = n;
  return s;
}