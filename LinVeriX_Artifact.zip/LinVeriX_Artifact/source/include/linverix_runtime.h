#pragma once
#include <thread>
#include <atomic>
#include <chrono>
#include <memory>
#include <vector>
#include <cmath>
#include <algorithm>

#include "linucb_controller.h"
#include "linverix_adapter.h"      // 定义 SegmentStats / IIndexAdapter

class LinVeriXRuntime {
public:
  struct Config { int epoch_ms=1000; int budget_B=4; double alpha=1.0; };

  LinVeriXRuntime(IIndexAdapter* adapter, const Config& cfg)
    : adapter_(adapter), cfg_(cfg) {}

  void start() {
    if (running_.exchange(true)) return;
    auto stats = adapter_->collect_all_stats();
    if (stats.empty()) { running_ = false; return; }
    int d = (int)make_context(stats.front()).size();
    LinUCBController::Config bcfg; bcfg.d=d; bcfg.alpha=cfg_.alpha; bcfg.budget_B=cfg_.budget_B;
    ctrl_ = std::make_unique<LinUCBController>(bcfg);
    worker_ = std::thread([this]{ loop(); });
  }

  void stop() {
    if (!running_.exchange(false)) return;
    if (worker_.joinable()) worker_.join();
  }

  ~LinVeriXRuntime(){ stop(); }

private:
  // 将 SegmentStats 规范化为特征向量（维度 d）
  static std::vector<double> make_context(const SegmentStats& s) {
    auto th = [](double v, double k){ return std::tanh(v / k); };
    std::vector<double> x;
    x.reserve(8);
    x.push_back(th(std::max(0.0, s.max_err),         50.0));  // 误差
    x.push_back(th(std::max(0.0, s.qps),            1000.0)); // QPS
    x.push_back(th(std::max(0.0, s.mean_read_ms),          50.0));  // 平均读延迟
    x.push_back(th(std::max(0.0, s.correction_steps_per_query), 16.0)); // 校正比较/查询
    x.push_back(th(std::max(0.0, s.last_retrain_sec),60.0));  // 距上次重训
    x.push_back(th(std::max(0.0, s.est_cost_ms),    100.0));  // 估计成本
    x.push_back(th(std::max(0.0, s.drift),          2000.0)); // 合成漂移残差
    x.push_back(th(std::abs(s.err_slope),            10.0));  // 误差斜率
    return x;
  }

  // 从 stats 构建 ArmContext 数组（LinUCB 选择所需）
  static std::vector<ArmContext> contexts_from_stats(const std::vector<SegmentStats>& stats) {
    std::vector<ArmContext> ctxs;
    ctxs.reserve(stats.size());
    for (const auto& s : stats) {
      ArmContext a;
      a.arm_id = static_cast<uint32_t>(s.seg_id);
      a.x = make_context(s);
      a.est_cost = std::max(1.0, s.est_cost_ms);  // 防除零
      ctxs.emplace_back(std::move(a));
    }
    return ctxs;
  }

  // 将回调中的指标合成为奖励（越大越好，已做成本归一）
  static double compose_reward(double d_mean_read_ms, double d_err, double cost_ms) {
    // d_mean_read_ms < 0 / d_err < 0 表示改善；平均延迟不是 P99
    const double w_p99 = 0.1, w_err = 0.02;
    const double denom = std::max(1e-6, cost_ms);
    // 改善为正收益：-d_x
    return (w_p99 * (-d_mean_read_ms) + w_err * (-d_err)) / denom;
  }

  void loop() {
    using clock = std::chrono::steady_clock;
    while (running_) {
      auto t0 = clock::now();

      auto stats = adapter_->collect_all_stats();
      if (stats.empty()) break;
      auto ctxs  = contexts_from_stats(stats);              // 这里直接得到 vector<ArmContext>
      auto pick  = ctrl_->selectTopB(ctxs);

      for (int seg : pick) {
        adapter_->retrain_segment_async(seg, [this](int seg_id, double d_mean_read_ms, double d_err, double cost_ms){
          double r = compose_reward(d_mean_read_ms, d_err, cost_ms);
          ctrl_->observeReward(static_cast<uint32_t>(seg_id), r);
        });
      }

      auto used = std::chrono::duration_cast<std::chrono::milliseconds>(clock::now()-t0).count();
      int sleep_ms = cfg_.epoch_ms - (int)used;
      if (sleep_ms > 0) std::this_thread::sleep_for(std::chrono::milliseconds(sleep_ms));
    }
  }

  IIndexAdapter* adapter_;
  Config cfg_;
  std::unique_ptr<LinUCBController> ctrl_;
  std::thread worker_;
  std::atomic<bool> running_{false};
};