#pragma once
#include <chrono>
#include <thread>
#include <atomic>
#include <mutex>
#include "levelindex.h"
#include "linverix_adapter.h"

template<typename Key>
class LevelIndexAdapter : public IIndexAdapter {
public:
  explicit LevelIndexAdapter(LevelIndex<Key>* idx) : idx_(idx) {
    const size_t segs = idx_->num_segments();
    stats_.resize(segs);
    ema_mean_read_ms_.assign(segs, 10.0);
    max_err_.assign(segs, 50.0);
    qps_.assign(segs, 0.0);
    write_ratio_.assign(segs, 0.1);
    size_mb_.assign(segs, 1.0);
    last_rt_sec_.assign(segs, 60.0);
    est_cost_ms_.assign(segs, 80.0);
    drift_.assign(segs, 0.0);
    last_snapshot_ = std::chrono::steady_clock::now();

    for (size_t s=0;s<segs;++s){
      stats_[s].seg_id = (int)s;
    }
  }

  std::vector<SegmentStats> collect_all_stats() override {
    std::lock_guard<std::mutex> g(mu_);
    decay_qps();
    const size_t segs = idx_->num_segments();
    for (size_t s=0;s<segs;++s){
      stats_[s].seg_id = (int)s;
      stats_[s].max_err = max_err_[s];
      stats_[s].err_slope = 0.0;
      stats_[s].qps = qps_[s];
      stats_[s].write_ratio = write_ratio_[s];
      stats_[s].mean_read_ms = ema_mean_read_ms_[s];
      stats_[s].size_mb = size_mb_[s];
      stats_[s].last_retrain_sec = last_rt_sec_[s];
      stats_[s].est_cost_ms = est_cost_ms_[s];
      stats_[s].drift = drift_[s]; 
    }
    return stats_;
  }

  void retrain_segment_async(int seg_id, RetrainDone cb) override {
    auto t0 = std::chrono::high_resolution_clock::now();
    {
      std::lock_guard<std::mutex> g(mu_);
  
      ema_mean_read_ms_[seg_id] = std::max(1.0, ema_mean_read_ms_[seg_id] - 2.0);
      max_err_[seg_id] = std::max(0.0, max_err_[seg_id] - 5.0);
      last_rt_sec_[seg_id] = 0.0;
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(30)); // 模拟成本
    auto t1 = std::chrono::high_resolution_clock::now();
    double cost_ms = std::chrono::duration<double,std::milli>(t1-t0).count();
    if (cb) cb(seg_id, -2.0 /* d_mean_read_ms */, -5.0 /* d_err */, cost_ms);
  }

  void mst_build_if_needed() override {
    if (mst_built_) return;
    auto kv = idx_->export_sorted_kv_for_mst_count();
    mst_.build(kv);
    mst_built_ = true;
  }
  void mst_update_by_key(uint64_t key, uint64_t new_val) override {
    if (!mst_built_) return;
    mst_.update_by_key(key, new_val);
  }
  IIndexAdapter::RangeProof mst_range_proof(uint64_t lkey, uint64_t rkey) override {
    return mst_.range_proof(lkey, rkey);
  }
  uint64_t mst_root_hash() const override { return mst_.root_hash(); }

  
  void note_query_by_key(const Key& key, double latency_ms=1.0, bool is_write=false) {
    size_t pos = idx_->find(key);
    size_t seg = pos / idx_->page_size_value();
    std::lock_guard<std::mutex> g(mu_);
    qps_[seg] += 1.0;
    ema_mean_read_ms_[seg] = 0.95*ema_mean_read_ms_[seg] + 0.05*latency_ms;
    if (is_write) write_ratio_[seg] = std::min(1.0, write_ratio_[seg] + 0.01);
    last_rt_sec_[seg] += 1.0;
  }

private:
  void decay_qps() {
    auto now = std::chrono::steady_clock::now();
    double sec = std::chrono::duration<double>(now - last_snapshot_).count();
    last_snapshot_ = now;
    double decay = std::exp(-sec / 1.0); 
    for (auto& v : qps_) v = v*decay;
    for (auto& t : last_rt_sec_) t += sec;
  }

  LevelIndex<Key>* idx_;
  std::vector<SegmentStats> stats_;
  std::vector<double> ema_mean_read_ms_, max_err_, qps_, write_ratio_, size_mb_, last_rt_sec_, est_cost_ms_, drift_;
  std::chrono::steady_clock::time_point last_snapshot_;
  std::mutex mu_;

  mks::MerkleSum mst_;
  bool mst_built_ = false;
};