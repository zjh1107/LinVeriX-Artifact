#pragma once
#include <vector>
#include <cstdint>
#include <utility>
#include <algorithm>
#include <unordered_map>
#include <functional>

namespace mks {

// 先用 FNV1a 作为占位哈希；需要可替换为 SHA-256/BLAKE3
inline uint64_t fnv1a(const void* p,size_t n){
  const uint8_t* b=(const uint8_t*)p;
  uint64_t h=1469598103934665603ull;
  while(n--){h^=*b++; h*=1099511628211ull;}
  return h;
}
inline uint64_t h_leaf(uint64_t k,uint64_t v){
  uint64_t buf[3]={0xA5ull,k,fnv1a(&v,sizeof(v))};
  return fnv1a(buf,sizeof(buf));
}
inline uint64_t h_int (uint64_t hl,uint64_t hr,uint64_t sl,uint64_t sr){
  uint64_t buf[5]={0x5Aull,hl,hr,sl,sr};
  return fnv1a(buf,sizeof(buf));
}

struct Path{ uint64_t sib_h=0,sib_s=0; bool sib_left=false; }; // sib_left=true 表示兄弟在左
struct Cover{
  // 说明：为便于调试，给出 level/prefix，但验证不依赖它们
  uint32_t level=0;      // 0=root, 64=leaf
  uint64_t prefix=0;     // 顶层 level 个高位前缀
  uint64_t h=0,s=0;      // 覆盖子树的哈希与求和值
  std::vector<Path> path; // 自底向上到 root 的兄弟路径
};
struct RangeProof{ std::vector<Cover> covers; };

class MerkleSum {
public:
  MerkleSum(){ init_defaults(); }

  // 初始化（可选）：将 (key,value) 批量写入（O(n log U)）
  void build(const std::vector<std::pair<uint64_t,uint64_t>>& kv){
    clear();
    for (auto& p : kv) update_set(p.first, p.second);
  }

  // 动态更新：设置 key 的值为 v（v=0 等价于删除）
  void update_by_key(uint64_t k,uint64_t v){ update_set(k,v); }
  void update_set(uint64_t key, uint64_t val){
    // 1) 叶子（level=64, prefix=key）
    NodeKey nk{64, key};
    if (val==0){
      // 如果置 0：擦除叶并向上尝试擦除成为默认值的内节点
      erase_path_to_root(nk);
    }else{
      Node leaf{h_leaf(key,val), val};
      set_node(nk, leaf); // 会一路向上重算父节点
    }
    // 向上重建到 root（在 set_node/erase_path_to_root 里完成）
  }

  // 生成范围证明：把 [L,R]（包含边界）分解为 O(log U) 子树覆盖
  RangeProof range_proof(uint64_t L,uint64_t R) const{
    RangeProof rp;
    if (L>R) return rp;
    // 从 level=1 的两个根孩子开始（避免 2^64 尺寸的位移）
    cover_collect(1, 0, L, R, rp);
    cover_collect(1, 1, L, R, rp);
    return rp;
  }

  // 验证范围证明（对每个覆盖子树单独重建到 root）
  bool verify(const RangeProof& rp, uint64_t root) const{
    if (rp.covers.empty()) return false;
    for (const auto& c : rp.covers){
      uint64_t h=c.h, s=c.s;
      for (const auto& p : c.path){
        if(p.sib_left){ h = h_int(p.sib_h, h, p.sib_s, s); s = p.sib_s + s; }
        else          { h = h_int(h, p.sib_h, s, p.sib_s); s = s + p.sib_s; }
      }
      if(h!=root) return false;
    }
    return true;
  }

  uint64_t root_hash() const { return get_node(NodeKey{0,0}).h; }
  uint64_t root_sum()  const { return get_node(NodeKey{0,0}).s; }

  // 便捷：覆盖节点 sum 相加
  uint64_t range_sum(uint64_t L, uint64_t R) const{
    if (L>R) return 0;
    RangeProof rp = range_proof(L,R);
    uint64_t S=0;
    for (const auto& c : rp.covers) S += c.s;
    return S;
  }

  void clear(){ nodes_.clear(); init_defaults(); }

private:
  static constexpr int LEVELS = 64;

  struct Node{ uint64_t h=0,s=0; };
  struct NodeKey{
    uint32_t level=0; // 0..64
    uint64_t prefix=0;
    bool operator==(const NodeKey& o) const noexcept {
      return level==o.level && prefix==o.prefix;
    }
  };
  struct NodeKeyHash{
    size_t operator()(const NodeKey& k) const noexcept{
      // 简单组合哈希即可；碰撞无害
      return std::hash<uint64_t>{}(k.prefix) ^ (std::hash<uint32_t>{}(k.level) + 0x9e3779b97f4a7c15ull + (std::hash<uint64_t>{}(k.prefix)<<6) + (std::hash<uint64_t>{}(k.prefix)>>2));
    }
  };

  // 稀疏节点存储；未存的节点视为“默认空子树”（sum=0, hash=def_hash_[level]）
  std::unordered_map<NodeKey, Node, NodeKeyHash> nodes_;
  uint64_t def_hash_[LEVELS+1]{}; // 每层空子树的默认哈希

  void init_defaults(){
    // 叶子（level=64）的默认哈希
    def_hash_[LEVELS] = h_leaf(0,0);
    for (int l=LEVELS-1; l>=0; --l){
      def_hash_[l] = h_int(def_hash_[l+1], def_hash_[l+1], 0, 0);
    }
  }

  static inline uint64_t prefix_of(uint64_t key, uint32_t level){
    // 返回 key 的高 level 位（level==0 时返回 0），避免未定义的右移 64 位
    if (level==0) return 0ull;
    return key >> (64u - level);
  }

  Node get_node(const NodeKey& k) const {
    auto it = nodes_.find(k);
    if (it==nodes_.end()) return Node{def_hash_[k.level], 0};
    return it->second;
  }

  void set_node(const NodeKey& leaf, const Node& nv){
    // 写叶
    if (nv.s==0 && nv.h==def_hash_[LEVELS]) nodes_.erase(leaf);
    else nodes_[leaf] = nv;

    // 自底向上重算到 root
    uint64_t key = leaf.prefix;
    for (int l=LEVELS-1; l>=0; --l){
      NodeKey parent{(uint32_t)l, prefix_of(key, (uint32_t)l)};
      uint64_t pfx = parent.prefix;
      NodeKey lc{(uint32_t)(l+1), (pfx<<1) | 0};
      NodeKey rc{(uint32_t)(l+1), (pfx<<1) | 1};
      Node L = get_node(lc), R = get_node(rc);
      Node cur{ h_int(L.h,R.h,L.s,R.s), L.s + R.s };
      // 如果与默认一致则擦除，否则写入
      if (cur.s==0 && cur.h==def_hash_[l]) nodes_.erase(parent);
      else nodes_[parent] = cur;
    }
  }

  void erase_path_to_root(const NodeKey& leaf){
    // 将叶视为默认，再向上重算
    nodes_.erase(leaf);
    uint64_t key = leaf.prefix;
    for (int l=LEVELS-1; l>=0; --l){
      NodeKey parent{(uint32_t)l, prefix_of(key, (uint32_t)l)};
      uint64_t pfx = parent.prefix;
      NodeKey lc{(uint32_t)(l+1), (pfx<<1) | 0};
      NodeKey rc{(uint32_t)(l+1), (pfx<<1) | 1};
      Node L = get_node(lc), R = get_node(rc);
      Node cur{ h_int(L.h,R.h,L.s,R.s), L.s + R.s };
      if (cur.s==0 && cur.h==def_hash_[l]) nodes_.erase(parent);
      else nodes_[parent] = cur;
    }
  }

  // 计算 level/prefix 对应区间 [begin, end]（闭区间），level in [1..64]
  static inline void node_range(uint32_t level, uint64_t prefix, uint64_t& begin, uint64_t& end){
    // 子树大小：2^(64-level)；level=64 => size=1
    uint64_t size = (level==64) ? 1ull : (1ull << (64 - level));
    begin = (level==64) ? prefix : (prefix << (64 - level));
    end   = begin + size - 1;
  }

  void cover_collect(uint32_t level, uint64_t prefix, uint64_t L, uint64_t R, RangeProof& rp) const{
    uint64_t begin=0,end=0;
    node_range(level,prefix,begin,end);
    if (R < begin || L > end) return;              // 不相交
    if (L <= begin && end <= R){                   // 完全覆盖
      Cover c; c.level=level; c.prefix=prefix;
      Node n = get_node(NodeKey{level,prefix});
      c.h = n.h; c.s = n.s;
      // 生成到 root 的兄弟路径
      uint64_t p = prefix;
      for (int l=(int)level; l>0; --l){
        bool cur_is_right = (p & 1ull) != 0;
        uint64_t sib_prefix = (p ^ 1ull);
        Node sib = get_node(NodeKey{(uint32_t)l, sib_prefix});
        c.path.push_back({sib.h, sib.s, /*sib_left=*/cur_is_right});
        p >>= 1; // 上移一层
      }
      rp.covers.push_back(std::move(c));
      return;
    }
    // 部分相交：下探
    if (level < 64){
      cover_collect(level+1, (prefix<<1) | 0, L, R, rp);
      cover_collect(level+1, (prefix<<1) | 1, L, R, rp);
    }else{
      // 到叶且部分相交（意味着 L<=key<=R）
      Cover c; c.level=64; c.prefix=prefix;
      Node n = get_node(NodeKey{64,prefix});
      c.h = n.h; c.s = n.s;
      uint64_t p = prefix;
      for (int l=64; l>0; --l){
        bool cur_is_right = (p & 1ull) != 0;
        uint64_t sib_prefix = (p ^ 1ull);
        Node sib = get_node(NodeKey{(uint32_t)l, sib_prefix});
        c.path.push_back({sib.h, sib.s, /*sib_left=*/cur_is_right});
        p >>= 1;
      }
      rp.covers.push_back(std::move(c));
    }
  }
};

} // namespace mks