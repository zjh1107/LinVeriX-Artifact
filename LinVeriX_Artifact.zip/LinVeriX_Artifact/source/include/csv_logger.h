#pragma once
#include <fstream>
#include <string>
#include <vector>
#include <unistd.h>  // getcwd

class CsvLogger {
public:
  explicit CsvLogger(const std::string& path,
                     const std::vector<std::string>& headers,
                     bool append=false)
    : ofs_(path, append ? (std::ios::out|std::ios::app)
                        : (std::ios::out|std::ios::trunc)),
      good_(ofs_.good())
  {
    if (!append) {
      for (size_t i=0;i<headers.size();++i){
        ofs_ << headers[i];
        if (i+1<headers.size()) ofs_ << ",";
      }
      ofs_ << "\n";
    }
  }

  template<typename... Args>
  void row(Args&&... args){
    write(std::forward<Args>(args)...);
    ofs_ << "\n";
  }

  void flush(){ ofs_.flush(); }
  bool good() const { return good_; }

private:
  std::ofstream ofs_;
  bool good_;
  template<typename T>
  void cell(const T& v){ ofs_ << v; }
  void cell(const std::string& v){
    ofs_ << v;
  }
  template<typename T, typename... Rest>
  void write(const T& v, Rest&&... rest){
    cell(v);
    if constexpr(sizeof...(rest)>0){
      ofs_ << ",";
      write(std::forward<Rest>(rest)...);
    }
  }
};