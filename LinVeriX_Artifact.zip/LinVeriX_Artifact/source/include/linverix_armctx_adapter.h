#pragma once
#include <unordered_map>
#include <vector>
#include <cstdint>
#include "linucb_controller.h"

// 把 {seg_id -> 特征向量} 适配为 LinUCB 需要的 ArmContext 数组
template <typename K>
static inline std::vector<ArmContext>
toArmContexts(const std::unordered_map<K, std::vector<double>>& m, double default_cost = 1.0) {
  std::vector<ArmContext> out;
  out.reserve(m.size());
  for (const auto& kv : m) {
    ArmContext a;
    a.arm_id = static_cast<uint32_t>(kv.first);
    a.x = kv.second;
    a.est_cost = default_cost;  // 如果有更准确的成本，调用处自行覆盖
    out.emplace_back(std::move(a));
  }
  return out;
}