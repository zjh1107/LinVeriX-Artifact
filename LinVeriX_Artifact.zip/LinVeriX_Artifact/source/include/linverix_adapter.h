#pragma once
#include <vector>
#include <functional>
#include <cstdint>
#include "metrics_collector.h"
#include "merklesum_tree.h"

class IIndexAdapter {
public:
  virtual ~IIndexAdapter() = default;


  virtual std::vector<SegmentStats> collect_all_stats() = 0;

  using RetrainDone = std::function<void(int seg_id, double delta_mean_read_ms, double delta_max_err, double cost_ms)>;
  virtual void retrain_segment_async(int seg_id, RetrainDone cb) = 0;

  virtual void mst_build_if_needed() = 0;
  virtual void mst_update_by_key(uint64_t key, uint64_t new_val) = 0;

  using RangeProof = mks::RangeProof;
  virtual RangeProof mst_range_proof(uint64_t lkey, uint64_t rkey) = 0;
  virtual uint64_t mst_root_hash() const = 0;
};