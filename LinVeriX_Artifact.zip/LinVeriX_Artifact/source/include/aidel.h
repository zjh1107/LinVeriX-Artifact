#ifndef __AIDEL_H__
#define __AIDEL_H__

#include "util.h"
#include "lr_model.h"
#include "lr_model_impl.h"
#include "aidel_model.h"
#include "aidel_model_impl.h"
#include "piecewise_linear_model.h"
#include <vector>
#include <cstddef>
#include <cstdint>

namespace aidel {

template<class key_t, class val_t>
class AIDEL{
public:
    typedef aidel::AidelModel<key_t, val_t> aidelmodel_type;
    typedef LinearRegressionModel<key_t>    lrmodel_type;
    typedef typename OptimalPiecewiseLinearModel<key_t, size_t>::CanonicalSegment canonical_segment;

    inline AIDEL();
    inline AIDEL(int _maxErr, int _learning_step, float _learning_rate);
    ~AIDEL();

    void train(const std::vector<key_t> &keys, const std::vector<val_t> &vals, size_t _maxErr);
    void train_opt(const std::vector<key_t> &keys, const std::vector<val_t> &vals, size_t _maxErr);

    void print_models();
    void self_check();

    inline result_t find(const key_t &key, val_t &val);
    inline result_t find_with_prediction_bias(
        const key_t &key, val_t &val, int64_t prediction_bias,
        size_t *correction_comparisons = nullptr);
    inline result_t insert(const key_t &key, const val_t &val);
    inline result_t update(const key_t &key, const val_t &val);
    inline result_t remove(const key_t &key);
    int    scan(const key_t &key, const size_t n, std::vector<std::pair<key_t, val_t>> &result);
    size_t model_size();

    // 全局预测（误差统计使用）
    inline size_t predict(const key_t& key) const;

private:
    size_t backward_train(const typename std::vector<key_t>::const_iterator &keys_begin,
                          const typename std::vector<val_t>::const_iterator &vals_begin,
                          uint32_t size, int step);
    void append_model(lrmodel_type &model,
                      const typename std::vector<key_t>::const_iterator &keys_begin,
                      const typename std::vector<val_t>::const_iterator &vals_begin,
                      size_t size, int err);
    aidelmodel_type* find_model(const key_t &key);

private:
    std::vector<key_t>            model_keys;
    std::vector<aidelmodel_type>  aimodels;
    std::vector<canonical_segment> segments;

    std::vector<size_t>           model_prefix_;  // 每模型全局起始 index
    int   maxErr = 64;
    int   learning_step = 1000;
    float learning_rate = 0.1f;
    size_t total_keys_ = 0;
};

} // namespace aidel
#endif
