#ifndef __AIDEL_MODEL_IMPL_H__
#define __AIDEL_MODEL_IMPL_H__

#include "aidel_model.h"
#include "util.h"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <limits>

namespace aidel {

template<class key_t, class val_t>
AidelModel<key_t, val_t>::AidelModel()
    : model(nullptr),
      maxErr(64),
      err(0),
      keys(nullptr),
      vals(nullptr),
      valid_flag(nullptr),
      levelbins(nullptr),
      mobs(nullptr),
      capacity(0) {}

template<class key_t, class val_t>
AidelModel<key_t, val_t>::~AidelModel() {
    // 释放子结构
    if (levelbins) {
        for (size_t i = 0; i <= capacity; ++i) {
            if (levelbins[i]) {
                delete levelbins[i];
                levelbins[i] = nullptr;
            }
        }
        delete[] levelbins;
        levelbins = nullptr;
    }
    if (mobs) {
        for (size_t i = 0; i <= capacity; ++i) {
            if (mobs[i]) {
                if (mobs[i]->isbin) {
                    delete mobs[i]->mob.lb;
                } else {
                    delete mobs[i]->mob.ai;
                }
                delete mobs[i];
                mobs[i] = nullptr;
            }
        }
        delete[] mobs;
        mobs = nullptr;
    }
    delete model;        model = nullptr;
    delete[] keys;       keys = nullptr;
    delete[] vals;       vals = nullptr;
    delete[] valid_flag; valid_flag = nullptr;
}

template<class key_t, class val_t>
AidelModel<key_t, val_t>::AidelModel(lrmodel_type &lrmodel,
                                     const typename std::vector<key_t>::const_iterator &keys_begin,
                                     const typename std::vector<val_t>::const_iterator &vals_begin,
                                     size_t size, size_t _maxErr)
    : model(nullptr),
      maxErr(_maxErr),
      err(0),
      keys(nullptr),
      vals(nullptr),
      valid_flag(nullptr),
      levelbins(nullptr),
      mobs(nullptr),
      capacity(size)
{
    assert(size > 0);
    model = new lrmodel_type(lrmodel.get_weight0(), lrmodel.get_weight1());

    keys       = new key_t[size];
    vals       = new val_t[size];
    valid_flag = new bool[size];
    for (size_t i = 0; i < size; ++i) {
        keys[i]       = *(keys_begin + i);
        vals[i]       = *(vals_begin + i);
        valid_flag[i] = true;
    }

    // 指针数组零初始化，长度 size+1，索引 [0..size] 合法
    levelbins = new levelbin_type*[size + 1]();
    mobs      = new model_or_bin_t*[size + 1]();
}


template<class key_t, class val_t>
AidelModel<key_t, val_t>::AidelModel(AidelModel&& other) noexcept
    : model(other.model),
      maxErr(other.maxErr),
      err(other.err),
      keys(other.keys),
      vals(other.vals),
      valid_flag(other.valid_flag),
      levelbins(other.levelbins),
      mobs(other.mobs),
      capacity(other.capacity)
{
    other.model = nullptr;
    other.keys = nullptr;
    other.vals = nullptr;
    other.valid_flag = nullptr;
    other.levelbins = nullptr;
    other.mobs = nullptr;
}



template<class key_t, class val_t>
inline size_t AidelModel<key_t, val_t>::get_capacity() const {
    return capacity;
}

template<class key_t, class val_t>
inline void AidelModel<key_t, val_t>::print_model() {
    std::cout << " capacity:" << capacity << " -->";
    assert(model);
    model->print_weights();
    print_keys();
}

template<class key_t, class val_t>
void AidelModel<key_t, val_t>::print_keys() {
    if (levelbins && levelbins[0]) levelbins[0]->print(std::cout);
    for (size_t i = 0; i < capacity; i++) {
        std::cout << "keys[" << i << "]: " << keys[i] << std::endl;
        if (levelbins && levelbins[i + 1]) levelbins[i + 1]->print(std::cout);
    }
}

template<class key_t, class val_t>
void AidelModel<key_t, val_t>::print_model_retrain() {
    std::cout << "[print aimodel] capacity:" << capacity << " -->";
    assert(model);
    model->print_weights();
    if (mobs && mobs[0]) {
        if (mobs[0]->isbin) {
            mobs[0]->mob.lb->print(std::cout);
        } else {
            mobs[0]->mob.ai->print_model_retrain();
        }
    }
    for (size_t i = 0; i < capacity; i++) {
        std::cout << "keys[" << i << "]: " << keys[i] << std::endl;
        if (mobs && mobs[i + 1]) {
            if (mobs[i + 1]->isbin) {
                mobs[i + 1]->mob.lb->print(std::cout);
            } else {
                mobs[i + 1]->mob.ai->print_model_retrain();
            }
        }
    }
}

template<class key_t, class val_t>
void AidelModel<key_t, val_t>::self_check() {
    if (capacity == 0) return;
    if (levelbins && levelbins[0]) levelbins[0]->self_check();
    for (size_t i = 1; i < capacity; i++) {
        assert(keys[i] > keys[i - 1]);
        if (levelbins && levelbins[i]) levelbins[i]->self_check();
    }
    if (levelbins && levelbins[capacity]) levelbins[capacity]->self_check();
}

template<class key_t, class val_t>
void AidelModel<key_t, val_t>::self_check_retrain() {
    if (capacity == 0) return;
    for (size_t i = 1; i < capacity; i++) {
        assert(keys[i] > keys[i - 1]);
    }
    if (!mobs) return;
    for (size_t i = 0; i <= capacity; i++) {
        model_or_bin_t *mob = mobs[i];
        if (mob) {
            if (mob->isbin) {
                mob->mob.lb->self_check();
            } else {
                mob->mob.ai->self_check_retrain();
            }
        }
    }
}

template<class key_t, class val_t>
bool AidelModel<key_t, val_t>::find(const key_t &key, val_t &val) {
    assert(capacity > 0 && model);
    size_t pos = predict(key);
    pos = locate_in_levelbin(key, pos);
    if (key == keys[pos]) {
        if (valid_flag[pos]) {
            val = vals[pos];
            return true;
        }
        return false;
    }
    int bin_pos = key < keys[pos] ? static_cast<int>(pos) : static_cast<int>(pos + 1);
    if (!levelbins || levelbins[bin_pos] == nullptr) return false;
    typename levelbin_type::iterator it = levelbins[bin_pos]->find(key);
    if (it != levelbins[bin_pos]->end()) {
        val = it.data();
        return true;
    }
    return false;
}

template<class key_t, class val_t>
bool AidelModel<key_t, val_t>::con_find(const key_t &key, val_t &val) {
    assert(capacity > 0 && model);
    size_t pos = predict(key);
    pos = locate_in_levelbin(key, pos);
    if (key == keys[pos]) {
        if (valid_flag[pos]) {
            val = vals[pos];
            return true;
        }
        return false;
    }
    int bin_pos = key < keys[pos] ? static_cast<int>(pos) : static_cast<int>(pos + 1);
    if (!levelbins || levelbins[bin_pos] == nullptr) return false;
    return levelbins[bin_pos]->con_find(key, val);
}

template<class key_t, class val_t>
result_t AidelModel<key_t, val_t>::con_find_retrain(const key_t &key, val_t &val) {
    assert(capacity > 0 && model);
    size_t pos = predict(key);
    pos = locate_in_levelbin(key, pos);
    if (key == keys[pos]) {
        if (valid_flag[pos]) {
            val = vals[pos];
            return result_t::ok;
        }
        return result_t::failed;
    }
    int bin_pos = key < keys[pos] ? static_cast<int>(pos) : static_cast<int>(pos + 1);
    memory_fence();
    if (!mobs) return result_t::failed;
    model_or_bin_t *mob = mobs[bin_pos];
    if (!mob) return result_t::failed;

    result_t res = result_t::failed;
    if (mob->isbin) {
        res = static_cast<Result>(mob->mob.lb->con_find_retrain(key, val));
    } else {
        res = mob->mob.ai->con_find_retrain(key, val);
    }
    return res;
}

// Controlled synthetic model drift: displace the learned position estimate,
// then widen the exact correction interval by the same amount. This increases
// real comparisons in the correction search while preserving exact lookup.
template<class key_t, class val_t>
result_t AidelModel<key_t, val_t>::con_find_retrain_with_prediction_bias(
    const key_t &key, val_t &val, int64_t prediction_bias,
    size_t *correction_comparisons) {
    assert(capacity > 0 && model);
    const size_t cap = get_capacity();
    size_t pos = predict(key);
    const uint64_t magnitude = prediction_bias < 0
        ? static_cast<uint64_t>(-(prediction_bias + 1)) + 1
        : static_cast<uint64_t>(prediction_bias);
    if (prediction_bias > 0) {
        pos += static_cast<size_t>(std::min<uint64_t>(magnitude, cap - 1 - pos));
    } else if (prediction_bias < 0) {
        pos = magnitude >= pos ? 0 : pos - static_cast<size_t>(magnitude);
    }
    const size_t extra_radius = static_cast<size_t>(
        std::min<uint64_t>(magnitude, std::numeric_limits<size_t>::max()));
    pos = locate_in_levelbin(key, pos, extra_radius, correction_comparisons);
    if (key == keys[pos]) {
        if (valid_flag[pos]) {
            val = vals[pos];
            return result_t::ok;
        }
        return result_t::failed;
    }
    int bin_pos = key < keys[pos] ? static_cast<int>(pos) : static_cast<int>(pos + 1);
    memory_fence();
    if (!mobs) return result_t::failed;
    model_or_bin_t *mob = mobs[bin_pos];
    if (!mob) return result_t::failed;
    if (mob->isbin)
        return static_cast<Result>(mob->mob.lb->con_find_retrain(key, val));
    return mob->mob.ai->con_find_retrain(key, val);
}

template<class key_t, class val_t>
result_t AidelModel<key_t, val_t>::update(const key_t &key, const val_t &val) {
    assert(capacity > 0 && model);
    size_t pos = predict(key);
    pos = locate_in_levelbin(key, pos);
    if (key == keys[pos]) {
        if (valid_flag[pos]) {
            vals[pos] = val;
            return result_t::ok;
        }
        return result_t::failed;
    }
    int bin_pos = key < keys[pos] ? static_cast<int>(pos) : static_cast<int>(pos + 1);
    memory_fence();
    if (!mobs) return result_t::failed;
    model_or_bin_t *mob = mobs[bin_pos];
    if (!mob) return result_t::failed;

    result_t res = result_t::failed;
    if (mob->isbin) {
        res = static_cast<Result>(mob->mob.lb->update(key, val));
    } else {
        res = mob->mob.ai->update(key, val);
    }
    return res;
}

template<class key_t, class val_t>
bool AidelModel<key_t, val_t>::con_insert(const key_t &key, const val_t &val) {
    assert(capacity > 0 && model);
    size_t pos = predict(key);
    pos = locate_in_levelbin(key, pos);
    if (key == keys[pos]) {
        if (valid_flag[pos]) {
            return false;
        } else {
            valid_flag[pos] = true;
            vals[pos] = val;
            return true;
        }
    }
    int bin_pos = static_cast<int>(pos);
    bin_pos = key < keys[bin_pos] ? bin_pos : (bin_pos + 1);
    if (!levelbins) return false;
    if (!levelbins[bin_pos]) {
        levelbin_type *lb = new levelbin_type();
        memory_fence();
        if (levelbins[bin_pos]) {
            delete lb;
            return levelbins[bin_pos]->con_insert(key, val);
        }
        levelbins[bin_pos] = lb;
    }
    assert(levelbins[bin_pos] != nullptr);
    return levelbins[bin_pos]->con_insert(key, val);
}

template<class key_t, class val_t>
result_t AidelModel<key_t, val_t>::con_insert_retrain(const key_t &key, const val_t &val) {
    assert(capacity > 0 && model);
    size_t pos = predict(key);
    pos = locate_in_levelbin(key, pos);
    if (key == keys[pos]) {
        if (valid_flag[pos]) {
            return result_t::failed;
        } else {
            valid_flag[pos] = true;
            vals[pos] = val;
            return result_t::ok;
        }
    }
    int bin_pos = static_cast<int>(pos);
    bin_pos = key < keys[bin_pos] ? bin_pos : (bin_pos + 1);
    return insert_model_or_bin(key, val, static_cast<size_t>(bin_pos));
}

template<class key_t, class val_t>
result_t AidelModel<key_t, val_t>::insert_model_or_bin(const key_t &key, const val_t &val, size_t bin_pos) {
    if (!mobs) return result_t::failed;
    model_or_bin_t *mob = mobs[bin_pos];
    if (!mob) {
        mob = new model_or_bin_t();
        mob->mob.lb = new levelbin_type();
        mob->isbin = true;
        memory_fence();
        if (mobs[bin_pos]) {
            delete mob->mob.lb;
            delete mob;
            return insert_model_or_bin(key, val, bin_pos);
        }
        mobs[bin_pos] = mob;
    }
    result_t res = result_t::failed;
    if (mob->isbin) {
        res = static_cast<Result>(mob->mob.lb->con_insert_retrain(key, val));
        if (res == result_t::retrain) {
            std::vector<key_t> retrain_keys;
            std::vector<val_t> retrain_vals;
            mob->mob.lb->resort(retrain_keys, retrain_vals);
            lrmodel_type model_local;
            model_local.train(retrain_keys.begin(), retrain_keys.size());
            size_t err_local = model_local.get_maxErr();
            aidelmodel_type *ai = new aidelmodel_type(model_local, retrain_keys.begin(), retrain_vals.begin(), retrain_keys.size(), err_local);

            memory_fence();
            delete mob->mob.lb;
            mob->mob.ai = ai;
            mob->isbin = false;
            res = ai->con_insert_retrain(key, val);
            return res;
        }
    } else {
        res = mob->mob.ai->con_insert_retrain(key, val);
    }
    return res;
}

template<class key_t, class val_t>
result_t AidelModel<key_t, val_t>::remove(const key_t &key) {
    assert(capacity > 0 && model);
    size_t pos = predict(key);
    pos = locate_in_levelbin(key, pos);
    if (key == keys[pos]) {
        if (valid_flag[pos]) {
            valid_flag[pos] = false;
            return result_t::ok;
        }
        return result_t::failed;
    }
    int bin_pos = key < keys[pos] ? static_cast<int>(pos) : static_cast<int>(pos + 1);
    return remove_model_or_bin(key, bin_pos);
}

template<class key_t, class val_t>
result_t AidelModel<key_t, val_t>::remove_model_or_bin(const key_t &key, const int bin_pos) {
    memory_fence();
    if (!mobs) return result_t::failed;
    model_or_bin_t *mob = mobs[static_cast<size_t>(bin_pos)];
    if (!mob) return result_t::failed;

    result_t res = result_t::failed;
    if (mob->isbin) {
        res = static_cast<Result>(mob->mob.lb->remove(key));
    } else {
        res = mob->mob.ai->remove(key);
    }
    return res;
}

template<class key_t, class val_t>
int AidelModel<key_t, val_t>::scan(const key_t &key, const size_t n, std::vector<std::pair<key_t, val_t>> &result) {
    if (n == 0 || capacity == 0) return 0;

    size_t remaining = n;
    size_t pos = predict(key);
    pos = locate_in_levelbin(key, pos);

    while (remaining > 0 && pos <= capacity) {
        if (pos < capacity && keys[pos] >= key) {
            result.emplace_back(keys[pos], vals[pos]);
            if (--remaining == 0) break;
        }
        if (mobs && mobs[pos] != nullptr) {
            model_or_bin_t *mob = mobs[pos];
            if (mob->isbin) {
                remaining = mob->mob.lb->scan(key, remaining, result);
            } else {
                remaining = mob->mob.ai->scan(key, remaining, result);
            }
        }
        ++pos;
    }
    return static_cast<int>(remaining);
}

template<class key_t, class val_t>
void AidelModel<key_t, val_t>::resort(std::vector<key_t> &out_keys, std::vector<val_t> &out_vals) {
    if (!levelbins) return;
    typename levelbin_type::iterator it;
    for (size_t i = 0; i <= capacity; i++) {
        if (levelbins[i]) {
            for (it = levelbins[i]->begin(); it != levelbins[i]->end(); it++) {
                out_keys.push_back(it.key());
                out_vals.push_back(it.data());
            }
        }
    }
}

template<class key_t, class val_t>
inline size_t AidelModel<key_t, val_t>::predict(const key_t &key) const {
    size_t pos = model->predict(key);   
    if (pos >= get_capacity()) pos = get_capacity() - 1;
    return pos;
}

template<class key_t, class val_t>
inline size_t AidelModel<key_t, val_t>::locate_in_levelbin(
    const key_t &key, const size_t pos, size_t extra_radius,
    size_t *correction_comparisons) {
    assert(capacity > 0);
    if (correction_comparisons) *correction_comparisons = 0;
    size_t index_pos = pos;
    size_t upbound = capacity - 1;
    const size_t radius = extra_radius > std::numeric_limits<size_t>::max() - maxErr
        ? std::numeric_limits<size_t>::max() : maxErr + extra_radius;

    size_t begin, end, mid;
    if (key > keys[index_pos]) {
        begin = (index_pos + 1 < upbound) ? (index_pos + 1) : upbound;
        end   = (radius < upbound - begin) ? (begin + radius) : upbound;
    } else {
        end   = index_pos;
        begin = (end > radius) ? (end - radius) : 0;
    }

    assert(begin <= end);
    while (begin != end) {
        if (correction_comparisons) ++*correction_comparisons;
        mid = (end + begin + 2) / 2;
        if (keys[mid] <= key) {
            begin = mid;
        } else {
            end = mid - 1;
        }
    }
    return begin;
}

template<class key_t, class val_t>
inline size_t AidelModel<key_t, val_t>::predict_public(const key_t &key) const{
    return predict(key); 
}

}  // namespace aidel

#endif  // __AIDEL_MODEL_IMPL_H__
