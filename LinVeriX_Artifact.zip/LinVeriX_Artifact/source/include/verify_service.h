#pragma once
#include <atomic>
#include <cstdint>
#include <vector>
#include <thread>
#include <chrono>
#include <random>
#include <functional>
#include <cassert>
#include <memory>
#include "linverix_adapter.h"
#include "merklesum_tree.h"

struct VerifyEvent {
  enum Type : uint8_t { Write } type;
  uint64_t key;
  uint64_t new_val;
};

class SPSCQueue {
public:
  explicit SPSCQueue(size_t cap) : buf_(cap), cap_(cap) {}

  SPSCQueue(const SPSCQueue&) = delete;
  SPSCQueue& operator=(const SPSCQueue&) = delete;
  SPSCQueue(SPSCQueue&&) = delete;
  SPSCQueue& operator=(SPSCQueue&&) = delete;

  bool try_push(const VerifyEvent& e) {
    size_t h = head_.load(std::memory_order_acquire);
    size_t t = tail_.load(std::memory_order_relaxed);
    if (t - h >= cap_) return false; // full
    buf_[t % cap_] = e;
    tail_.store(t + 1, std::memory_order_release);
    return true;
  }

  bool try_pop(VerifyEvent& out) {
    size_t h = head_.load(std::memory_order_relaxed);
    size_t t = tail_.load(std::memory_order_acquire);
    if (h == t) return false; // empty
    out = buf_[h % cap_];
    head_.store(h + 1, std::memory_order_release);
    return true;
  }

  size_t size() const {
    size_t h = head_.load(std::memory_order_acquire);
    size_t t = tail_.load(std::memory_order_acquire);
    return t - h;
  }

private:
  std::vector<VerifyEvent> buf_;
  const size_t cap_;
  std::atomic<size_t> head_{0}, tail_{0};
};

class VerifyService {
public:
  struct Config {
    size_t num_workers = 1;
    size_t queue_cap = 1 << 16;
    size_t batch_max = 4096;
    int    batch_interval_ms = 2;
    double point_proof_sample = 0.01;
  };

  VerifyService(IIndexAdapter* adapter, const Config& cfg)
    : adapter_(adapter), cfg_(cfg)
  {
    queues_.reserve(cfg_.num_workers);
    for (size_t i=0;i<cfg_.num_workers;++i) {
      queues_.emplace_back(std::make_unique<SPSCQueue>(cfg_.queue_cap));
    }
  }

  inline void enqueue_write(int worker_id, uint64_t key, uint64_t new_val) {
    if (worker_id < 0 || (size_t)worker_id >= queues_.size()) return;
    VerifyEvent e{VerifyEvent::Write, key, new_val};
    (void)queues_[worker_id]->try_push(e);
  }

  void start() {
    stop_.store(false, std::memory_order_release);
    worker_ = std::thread([this]{ run(); });
  }

  void stop() {
    stop_.store(true, std::memory_order_release);
    if (worker_.joinable()) worker_.join();
  }

  ~VerifyService(){ stop(); }

private:
  void run() {
    std::mt19937_64 rng(12345);
    std::uniform_real_distribution<double> u01(0.0,1.0);

    std::vector<VerifyEvent> batch;
    batch.reserve(cfg_.batch_max);

    while (!stop_.load(std::memory_order_acquire)) {
      batch.clear();

      for (size_t w = 0; w < queues_.size() && batch.size() < cfg_.batch_max; ++w) {
        VerifyEvent ev;
        while (batch.size() < cfg_.batch_max && queues_[w]->try_pop(ev)) {
          batch.push_back(ev);
        }
      }

      if (batch.empty()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(cfg_.batch_interval_ms));
        continue;
      }

      for (const auto& ev : batch) {
        if (ev.type == VerifyEvent::Write) {
          adapter_->mst_update_by_key(ev.key, ev.new_val);
          if (u01(rng) < cfg_.point_proof_sample) {
            auto proof = adapter_->mst_range_proof(ev.key, ev.key);
            bool ok = mks::MerkleSum().verify(proof, adapter_->mst_root_hash());
            (void)ok;
          }
        }
      }
    }
  }

  IIndexAdapter* adapter_;
  Config cfg_;
  std::vector<std::unique_ptr<SPSCQueue>> queues_;
  std::atomic<bool> stop_{false};
  std::thread worker_;
};