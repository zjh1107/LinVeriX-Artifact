#pragma once
#include <string>
#include <vector>
#include <cstdio>

struct WindowLog {
  int64_t time_ms{};
  int window_id{};
  std::string policy;     // "linucb" / "threshold"
  size_t budget_B{};
  double tps_before{}, tps_after{};
  double p99_before{}, p99_after{};
  double gain_tps{}, gain_p99{}, gain_norm{};
  double cost_total_ms{};
  std::string selected_ids_csv;
  double retrain_ms{}, mst_update_ms{}, proof_gen_us{}, proof_ver_us{};
  int threads{};
  size_t size{};
  std::string dist;       // "uniform"/"zipf"/"lognorm"
};

class CsvLogger {
public:
  explicit CsvLogger(const std::string& path){
    f_ = std::fopen(path.c_str(), "w");
    if (f_) {
      std::fputs("time_ms,window_id,policy,budget_B,tps_before,tps_after,p99_before,p99_after,"
                 "gain_tps,gain_p99,gain_norm,cost_total_ms,selected_ids,retrain_ms,mst_update_ms,"
                 "proof_gen_us,proof_ver_us,threads,size,dist\n", f_);
      std::fflush(f_);
    }
  }
  ~CsvLogger(){ if (f_) std::fclose(f_); }
  void write(const WindowLog& w){
    if (!f_) return;
    std::fprintf(f_,
      "%lld,%d,%s,%zu,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%s,%.6f,%.6f,%.6f,%.6f,%d,%zu,%s\n",
      (long long)w.time_ms, w.window_id, w.policy.c_str(), w.budget_B,
      w.tps_before, w.tps_after, w.p99_before, w.p99_after,
      w.gain_tps, w.gain_p99, w.gain_norm, w.cost_total_ms,
      w.selected_ids_csv.c_str(), w.retrain_ms, w.mst_update_ms,
      w.proof_gen_us, w.proof_ver_us, w.threads, w.size, w.dist.c_str());
    std::fflush(f_);
  }
private:
  std::FILE* f_{nullptr};
};