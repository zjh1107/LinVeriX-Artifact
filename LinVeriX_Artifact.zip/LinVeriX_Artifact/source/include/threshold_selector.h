#pragma once
#include <vector>
#include <cstdint>
#include <algorithm>
#include "linucb_controller.h" // 复用 ArmContext

struct ThresholdParam {
  double tau = 0.1;       // 绝对阈值（用于 u_i）
  size_t budget_B = 4;
  int u_index = 0;        // 上下文向量中作为阈值信号的索引（如误差上界）
};

inline std::vector<uint32_t> select_by_threshold(const std::vector<ArmContext>& arms,
                                                 const ThresholdParam& P){
  struct Cand { uint32_t id; double score; };
  std::vector<Cand> cs; cs.reserve(arms.size());
  for (auto& a: arms){
    double u = (P.u_index >=0 && P.u_index < (int)a.x.size()) ? a.x[P.u_index] : 0.0;
    if (u <= P.tau) continue;
    double cost = std::max(a.est_cost, 1e-9);
    cs.push_back({a.arm_id, u / cost});
  }
  std::sort(cs.begin(), cs.end(), [](auto& A, auto& B){ return A.score > B.score; });
  std::vector<uint32_t> out;
  for (size_t i=0; i<cs.size() && i<P.budget_B; ++i) out.push_back(cs[i].id);
  return out;
}