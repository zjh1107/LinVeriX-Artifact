#pragma once
#include <vector>
#include <cstdint>
#include <utility>
#include <memory>
#include <mutex>
#include <algorithm>
#include <stdexcept>

#include "aidel.h"
#include "aidel_impl.h"

#include "merklesum_tree.h"  


using key_type = uint64_t;
using val_type = uint64_t;

class AidelAdapter {
public:
  struct Config {

  };

  explicit AidelAdapter(aidel::AIDEL<key_type, val_type>* ai, Config = {})
  : ai_(ai) {}


  bool has_mst() const { return mst_built_; }


  void rebuild_mst_from_vectors(const std::vector<key_type>& keys,
                                const std::vector<val_type>& vals) {
    if (keys.size() != vals.size())
      throw std::invalid_argument("keys.size() != vals.size()");

    std::vector<std::pair<uint64_t,uint64_t>> kv;
    kv.reserve(keys.size());
    for (size_t i = 0; i < keys.size(); ++i) {
      kv.emplace_back(keys[i], vals[i]);
    }

    std::sort(kv.begin(), kv.end(),
              [](const auto& a, const auto& b){ return a.first < b.first; });

    std::lock_guard<std::mutex> lk(mtx_);
    mst_ = std::make_unique<mks::MerkleSum>();
    mst_->build(kv);
    mst_built_ = true;

    if (!kv.empty()) {
      min_key_ = kv.front().first;
      max_key_ = kv.back().first;
    } else {
      min_key_ = max_key_ = 0;
    }
    root_ = mst_->root_hash();
  }


  void rebuild_mst_from_ai() {
   
    throw std::runtime_error("rebuild_mst_from_ai() not implemented; please call rebuild_mst_from_vectors(keys, vals).");
  }


  key_type min_key() const { return min_key_; }
  key_type max_key() const { return max_key_; }


  uint64_t mst_root_hash() const { return root_; }

  mks::RangeProof mst_range_proof(key_type l, key_type r) const {
    std::lock_guard<std::mutex> lk(mtx_);
    if (!mst_built_ || !mst_) return mks::RangeProof{};

    if (l > r) std::swap(l, r);
    return mst_->range_proof(l, r);
  }

  void on_write(uint32_t /*thread_id*/, key_type k, val_type v) {
    std::lock_guard<std::mutex> lk(mtx_);
    if (!mst_built_ || !mst_) return;
    mst_->update_by_key(k, v);
    root_ = mst_->root_hash();
    if (k < min_key_) min_key_ = k;
    if (k > max_key_) max_key_ = k;
  }

private:
  aidel::AIDEL<key_type, val_type>* ai_{nullptr};

  mutable std::mutex mtx_;
  bool mst_built_{false};
  std::unique_ptr<mks::MerkleSum> mst_{};
  uint64_t root_{0};

  key_type min_key_{0};
  key_type max_key_{0};
};