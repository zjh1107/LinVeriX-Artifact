#pragma once

// Thin exact-lookup adapter for the official PGM-index implementation.
// Each scheduler shard owns one PGM model over its sorted keys. Queries use
// PGM's predicted position and guaranteed error interval, then perform exact
// correction inside the interval. Synthetic prediction drift widens and shifts
// that interval while preserving exact lookup semantics.
#include "pgm/pgm_index.hpp"
#include "function.h"
#include <algorithm>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>

template <class Key, class Value> class PgmCompat {
  using index_type = pgm::PGMIndex<Key, 64, 4, double>;
  index_type index_;
  std::vector<Key> keys_;
  std::vector<Value> values_;
  size_t max_error_ = 64;

  void rebuild_() { index_ = index_type(keys_.begin(), keys_.end()); }

  bool locate_(const Key &key, size_t lo, size_t hi, size_t *comparisons,
               size_t &position) const {
    auto first = keys_.begin() + static_cast<std::ptrdiff_t>(lo);
    auto last = keys_.begin() + static_cast<std::ptrdiff_t>(hi);
    size_t base = lo;
    while (first < last) {
      if (comparisons) ++*comparisons;
      auto mid = first + (last - first) / 2;
      if (*mid < key) {
        first = mid + 1;
        base = static_cast<size_t>(first - keys_.begin());
      } else {
        last = mid;
      }
    }
    if (first == keys_.end() || *first != key) return false;
    position = static_cast<size_t>(first - keys_.begin());
    return true;
  }

public:
  void train(const std::vector<Key> &keys, const std::vector<Value> &vals,
             size_t max_error) {
    if (keys.size() != vals.size())
      throw std::invalid_argument("invalid PGM training sample");
    std::vector<std::pair<Key, Value>> pairs;
    pairs.reserve(keys.size());
    for (size_t i = 0; i < keys.size(); ++i) pairs.emplace_back(keys[i], vals[i]);
    std::sort(pairs.begin(), pairs.end(), [](const auto &a, const auto &b) {
      return a.first == b.first ? a.second < b.second : a.first < b.first;
    });
    keys_.clear();
    values_.clear();
    keys_.reserve(pairs.size());
    values_.reserve(pairs.size());
    for (const auto &p : pairs) {
      keys_.push_back(p.first);
      values_.push_back(p.second);
    }
    max_error_ = max_error;
    rebuild_();
  }

  result_t find(const Key &key, Value &value) {
    if (keys_.empty()) return Result::failed;
    const auto range = index_.search(key);
    size_t position = 0;
    if (!locate_(key, range.lo, range.hi, nullptr, position))
      return Result::failed;
    value = values_[position];
    return Result::ok;
  }

  result_t find_with_prediction_bias(const Key &key, Value &value,
                                     int64_t prediction_bias,
                                     size_t *correction_comparisons = nullptr) {
    if (correction_comparisons) *correction_comparisons = 0;
    if (keys_.empty()) return Result::failed;
    const auto range = index_.search(key);
    const size_t n = keys_.size();
    const size_t predicted = std::min(n - 1, range.pos);
    const uint64_t bias = prediction_bias < 0
        ? static_cast<uint64_t>(-(prediction_bias + 1)) + 1
        : static_cast<uint64_t>(prediction_bias);
    size_t shifted = predicted;
    if (prediction_bias > 0)
      shifted += static_cast<size_t>(std::min<uint64_t>(bias, n - 1 - shifted));
    else if (prediction_bias < 0)
      shifted = bias >= shifted ? 0 : shifted - static_cast<size_t>(bias);

    const size_t native_radius = std::max(predicted - range.lo,
        range.hi > predicted ? range.hi - 1 - predicted : size_t{0});
    const size_t radius = bias > std::numeric_limits<size_t>::max() - native_radius
        ? std::numeric_limits<size_t>::max()
        : native_radius + static_cast<size_t>(bias);
    const size_t lo = radius >= shifted ? 0 : shifted - radius;
    const size_t hi = radius >= n - shifted ? n : shifted + radius + 1;
    size_t position = 0;
    if (!locate_(key, lo, hi, correction_comparisons, position))
      return Result::failed;
    value = values_[position];
    return Result::ok;
  }

  result_t insert(const Key &key, const Value &value) {
    auto it = std::lower_bound(keys_.begin(), keys_.end(), key);
    if (it != keys_.end() && *it == key) return Result::failed;
    const auto pos = static_cast<size_t>(it - keys_.begin());
    keys_.insert(it, key);
    values_.insert(values_.begin() + static_cast<std::ptrdiff_t>(pos), value);
    rebuild_();
    return Result::ok;
  }

  result_t update(const Key &key, const Value &value) {
    auto it = std::lower_bound(keys_.begin(), keys_.end(), key);
    if (it == keys_.end() || *it != key) return Result::failed;
    values_[static_cast<size_t>(it - keys_.begin())] = value;
    return Result::ok;
  }

  result_t remove(const Key &key) {
    auto it = std::lower_bound(keys_.begin(), keys_.end(), key);
    if (it == keys_.end() || *it != key) return Result::failed;
    const auto pos = static_cast<size_t>(it - keys_.begin());
    keys_.erase(it);
    values_.erase(values_.begin() + static_cast<std::ptrdiff_t>(pos));
    rebuild_();
    return Result::ok;
  }

  void self_check() {
    for (size_t i = 0; i < keys_.size(); ++i) {
      Value got{};
      if (find(keys_[i], got) != Result::ok || got != values_[i])
        throw std::runtime_error("PGM self-check failed");
    }
  }

  size_t model_size() { return index_.size_in_bytes(); }
  size_t predict(const Key &key) const {
    if (keys_.empty()) return 0;
    return std::min(keys_.size() - 1, index_.search(key).pos);
  }
};
