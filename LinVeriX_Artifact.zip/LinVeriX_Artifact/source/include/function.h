#pragma once
#include "util.h"
#include <getopt.h>
#include <random>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cerrno>

typedef uint64_t key_type;
typedef uint64_t val_type;

extern std::vector<key_type> exist_keys;
extern std::vector<key_type> non_exist_keys;

inline void load_data();
inline void parse_args(int, char **);

void uniform_data();
void normal_data();
void lognormal_data();
void timestamp_data();
void documentid_data();
void lognormal_data_with_insert_factor();
void skew_data();
void facebook_sample_data();
void sosd_sample_data();
void load_ycsb(const char *path);
void run_ycsb(const char *path);
std::vector<int> read_data(const char *path);
template<typename key_typeT>
std::vector<key_typeT> read_timestamp(const char *path);
template<typename key_typeT>
std::vector<key_typeT> read_document(const char *path);

typedef struct operation_item {
    key_type key;
    int32_t  range{0};
    uint8_t  op{0};   // 0 READ 1 INSERT 2 UPDATE 3 REMOVE 4 SCAN
} operation_item;

// parameters
struct config{
    double read_ratio   = 1;
    double insert_ratio = 0;
    double update_ratio = 0;
    double delete_ratio = 0;
    size_t item_num  = 2000000;
    size_t exist_num = 1000000;
    size_t runtime   = 10;
    size_t thread_num= 1;
    size_t benchmark = 0;
    size_t insert_factor = 1;
    double skewness  = 0.05;
    std::string policy = "off";
    size_t budget_B  = 0;
    int win_sec      = 2;
    double alpha     = 1.0;
    double lambda    = 1e-3;
    double tau       = 0.0;
    double tau_quantile = -1.0;
    std::string verify_layer = "hash";
    double proof_rate = 0.0;
    double neg_read_ratio = 0.0;
    std::string csv_log = "";
    int maxErr = 32;
    uint64_t seed = 1;
};

extern config Config;

struct {
    size_t operate_num = 10000000;              // 最大上限
    operation_item* operate_queue = nullptr;
}YCSBconfig;

enum LongOnlyOpt {
  OPT_POLICY = 1000,
  OPT_BUDGET_B,
  OPT_WIN_SEC,
  OPT_ALPHA,
  OPT_LAMBDA,
  OPT_TAU,
  OPT_TAU_Q,
  OPT_VERIFY_LAYER,
  OPT_PROOF_RATE,
  OPT_NEG_READ_RATIO,
  OPT_CSV_LOG,
  OPT_MAX_ERR,
  OPT_SEED
};

// =============== parse_args (原逻辑保持) ===================================
inline void parse_args(int argc, char **argv) {
  struct option long_options[] = {
      {"read",           required_argument, 0, 'a'},
      {"insert",         required_argument, 0, 'b'},
      {"remove",         required_argument, 0, 'c'},
      {"update",         required_argument, 0, 'd'},
      {"item_num",       required_argument, 0, 'e'},
      {"runtime",        required_argument, 0, 'f'},
      {"thread_num",     required_argument, 0, 'g'},
      {"benchmark",      required_argument, 0, 'h'},
      {"insert_factor",  required_argument, 0, 'i'},
      {"skewness",       required_argument, 0, 'j'},
      {"exist_num",      required_argument, 0, 'k'},
      {"policy",         required_argument, 0, OPT_POLICY},
      {"budget_B",       required_argument, 0, OPT_BUDGET_B},
      {"win_sec",        required_argument, 0, OPT_WIN_SEC},
      {"alpha",          required_argument, 0, OPT_ALPHA},
      {"lambda",         required_argument, 0, OPT_LAMBDA},
      {"tau",            required_argument, 0, OPT_TAU},
      {"tau_quantile",   required_argument, 0, OPT_TAU_Q},
      {"verify_layer",   required_argument, 0, OPT_VERIFY_LAYER},
      {"proof_rate",     required_argument, 0, OPT_PROOF_RATE},
      {"neg_read_ratio", required_argument, 0, OPT_NEG_READ_RATIO},
      {"csv_log",        required_argument, 0, OPT_CSV_LOG},
      {"maxErr",         required_argument, 0, OPT_MAX_ERR},
      {"seed",           required_argument, 0, OPT_SEED},
      {0, 0, 0, 0}
  };
  std::string ops = "a:b:c:d:e:f:g:h:i:j:k:";
  int option_index = 0;

  while (1) {
    int c = getopt_long(argc, argv, ops.c_str(), long_options, &option_index);
    if (c == -1) break;
    switch (c) {
      case 'a': Config.read_ratio   = strtod(optarg, NULL); break;
      case 'b': Config.insert_ratio = strtod(optarg, NULL); break;
      case 'c': Config.delete_ratio = strtod(optarg, NULL); break;
      case 'd': Config.update_ratio = strtod(optarg, NULL); break;
      case 'e': Config.item_num   = strtoul(optarg, NULL, 10); break;
      case 'f': Config.runtime    = strtoul(optarg, NULL, 10); break;
      case 'g': Config.thread_num = strtoul(optarg, NULL, 10); break;
      case 'h': Config.benchmark  = strtoul(optarg, NULL, 10); break;
      case 'i': Config.insert_factor = strtoul(optarg, NULL, 10); break;
      case 'j': Config.skewness   = strtod(optarg, NULL); break;
      case 'k': Config.exist_num  = strtoul(optarg, NULL, 10); break;
      case OPT_POLICY: {
        Config.policy = std::string(optarg);
        if (Config.policy != "off" &&
            Config.policy != "linucb" &&
            Config.policy != "threshold" &&
            Config.policy != "naive" &&
            Config.policy != "periodic") {
          COUT_THIS("Unknown policy: " << Config.policy
                    << " (use off|linucb|threshold|naive|periodic)");
          abort();
        }
        break;
      }
      case OPT_BUDGET_B:  Config.budget_B = strtoul(optarg, NULL, 10); break;
      case OPT_WIN_SEC:   Config.win_sec  = (int)strtol(optarg, NULL, 10); break;
      case OPT_ALPHA:     Config.alpha    = strtod(optarg, NULL); break;
      case OPT_LAMBDA:    Config.lambda   = strtod(optarg, NULL); break;
      case OPT_TAU:       Config.tau      = strtod(optarg, NULL); break;
      case OPT_TAU_Q:     Config.tau_quantile = strtod(optarg, NULL); break;
      case OPT_VERIFY_LAYER: {
        Config.verify_layer = std::string(optarg);
        if (!(Config.verify_layer == "hash" || Config.verify_layer == "merklesum")) {
          COUT_THIS("Unknown verify_layer: " << Config.verify_layer);
          abort();
        }
        break;
      }
      case OPT_PROOF_RATE:     Config.proof_rate     = strtod(optarg, NULL); break;
      case OPT_NEG_READ_RATIO: Config.neg_read_ratio = strtod(optarg, NULL); break;
      case OPT_CSV_LOG:        Config.csv_log = std::string(optarg); break;
      case OPT_MAX_ERR:        Config.maxErr  = (int)strtol(optarg, NULL, 10); break;
      case OPT_SEED:           Config.seed    = strtoull(optarg, NULL, 10); break;
      default: abort();
    }
  }

  INVARIANT(Config.read_ratio >=0 && Config.read_ratio<=1);
  INVARIANT(Config.insert_ratio>=0 && Config.insert_ratio<=1);
  INVARIANT(Config.update_ratio>=0 && Config.update_ratio<=1);
  INVARIANT(Config.delete_ratio>=0 && Config.delete_ratio<=1);
  double ratio_sum = Config.read_ratio + Config.insert_ratio
                   + Config.update_ratio + Config.delete_ratio;
  INVARIANT(ratio_sum > 0.9999 && ratio_sum < 1.0001);

  COUT_THIS("[micro] Read:Insert:Update:Delete = "
            << Config.read_ratio << ":" << Config.insert_ratio << ":"
            << Config.update_ratio << ":" << Config.delete_ratio );
  COUT_VAR(Config.runtime);
  COUT_VAR(Config.thread_num);
  COUT_VAR(Config.benchmark);
  COUT_THIS("Policy: " << Config.policy
            << " | budget_B=" << Config.budget_B
            << " | win_sec=" << Config.win_sec);
  if (Config.policy == "linucb") {
    COUT_THIS("LinUCB: alpha=" << Config.alpha << " lambda=" << Config.lambda);
  } else if (Config.policy == "threshold") {
    COUT_THIS("Threshold: tau=" << Config.tau
              << " tau_quantile=" << Config.tau_quantile);
  }
  COUT_THIS("Verify: layer=" << Config.verify_layer
            << " proof_rate=" << Config.proof_rate);
  COUT_THIS("neg_read_ratio=" << Config.neg_read_ratio);
  if (!Config.csv_log.empty()) COUT_THIS("csv_log=" << Config.csv_log);
}

// ================== 数据加载 =============================================
inline void load_data(){
    switch (Config.benchmark) {
        case 0: normal_data(); break;
        case 1: lognormal_data(); break;
        case 2: timestamp_data(); break;
        case 3: documentid_data(); break;
        case 4: lognormal_data_with_insert_factor(); break;
        case 5: skew_data(); break;
        case 6: { // workloada
            const char* ybase = getenv("YCSB_HOME"); // *** MOD ***
            std::string base = (ybase && *ybase)? ybase : "ycsb";
            load_ycsb((base + "/workloada/load.10M").c_str());
            run_ycsb((base + "/workloada/run.10M").c_str());
            COUT_THIS("load workloada");
            break;
        }
        case 7: {
            const char* ybase = getenv("YCSB_HOME");
            std::string base = (ybase && *ybase)? ybase : "ycsb";
            load_ycsb((base + "/workloadb/load.10M").c_str());
            run_ycsb((base + "/workloadb/run.10M").c_str());
            COUT_THIS("load workloadb");
            break;
        }
        case 8: {
            const char* ybase = getenv("YCSB_HOME");
            std::string base = (ybase && *ybase)? ybase : "ycsb";
            load_ycsb((base + "/workloadc/load.10M").c_str());
            run_ycsb((base + "/workloadc/run.10M").c_str());
            COUT_THIS("load workloadc");
            break;
        }
        case 9: {
            const char* ybase = getenv("YCSB_HOME");
            std::string base = (ybase && *ybase)? ybase : "ycsb";
            load_ycsb((base + "/workloadd/load.10M").c_str());
            run_ycsb((base + "/workloadd/run.10M").c_str());
            COUT_THIS("load workloadd");
            break;
        }
        case 10: {
            const char* ybase = getenv("YCSB_HOME");
            std::string base = (ybase && *ybase)? ybase : "ycsb";
            load_ycsb((base + "/workloade/load.10M").c_str());
            run_ycsb((base + "/workloade/run.10M").c_str());
            COUT_THIS("load workloade");
            break;
        }
        case 11: {
            const char* ybase = getenv("YCSB_HOME");
            std::string base = (ybase && *ybase)? ybase : "ycsb";
            load_ycsb((base + "/workloadf/load.10M").c_str());
            run_ycsb((base + "/workloadf/run.10M").c_str());
            COUT_THIS("load workloadf");
            break;
        }
        case 12: uniform_data(); break;
        case 13: sosd_sample_data(); break; // generic SOSD sample; RQ6 logic unchanged
        default: abort();
    }

    COUT_THIS("[processing data]");
    std::sort(exist_keys.begin(), exist_keys.end());
    exist_keys.erase(std::unique(exist_keys.begin(), exist_keys.end()), exist_keys.end());
    std::sort(exist_keys.begin(), exist_keys.end());
    if (Config.benchmark == 13 && exist_keys.size() != Config.exist_num) {
        std::cerr << "Facebook sample must contain exactly " << Config.exist_num
                  << " unique uint64 keys, got " << exist_keys.size() << "\n";
        std::exit(2);
    }
    for(size_t i=1; i<exist_keys.size(); i++){
        assert(exist_keys[i]>=exist_keys[i-1]);
    }
    COUT_VAR(exist_keys.size());
    COUT_VAR(non_exist_keys.size());
}

// ================== 数据生成实现（保持原逻辑） ===========================
inline void uniform_data(){
    std::mt19937 gen((uint32_t)Config.seed);
    std::uniform_int_distribution<uint64_t> rand_uniform(0, Config.exist_num*100);
    exist_keys.reserve(Config.exist_num);
    for (size_t i = 0; i < Config.exist_num; ++i) exist_keys.push_back(i*100);
    if (Config.insert_ratio > 0) {
        non_exist_keys.reserve(Config.item_num);
        for (size_t i = 0; i < Config.item_num; ++i)
            non_exist_keys.push_back(rand_uniform(gen));
    }
}
inline void normal_data(){
    std::mt19937 gen((uint32_t)Config.seed);
    std::normal_distribution<double> rand_normal(4, 2);
    exist_keys.reserve(Config.exist_num);
    for (size_t i = 0; i < Config.exist_num; ) {
        double v = rand_normal(gen);
        if (v < 0) continue;
        exist_keys.push_back((key_type)(v*1e12));
        ++i;
    }
    if (Config.insert_ratio > 0) {
        non_exist_keys.reserve(Config.item_num);
        for (size_t i = 0; i < Config.item_num; ) {
            double v = rand_normal(gen);
            if (v < 0) continue;
            non_exist_keys.push_back((key_type)(v*1e12));
            ++i;
        }
    }
}
inline void lognormal_data(){
    std::mt19937 gen((uint32_t)Config.seed);
    std::lognormal_distribution<double> dist(0, 2);
    exist_keys.reserve(Config.exist_num);
    for (size_t i=0;i<Config.exist_num;i++)
        exist_keys.push_back((key_type)(dist(gen)*1e12));
    if (Config.insert_ratio > 0) {
        non_exist_keys.reserve(Config.item_num);
        for (size_t i=0;i<Config.item_num;i++)
            non_exist_keys.push_back((key_type)(dist(gen)*1e12));
    }
}
inline void timestamp_data(){
    auto read_keys = read_timestamp<key_type>("osm/osm_cellids_800M_uint64");
    size_t size = read_keys.size();
    std::mt19937 gen((uint32_t)Config.seed);
    std::uniform_int_distribution<size_t> rnd(0, size-1);
    if(Config.insert_ratio > 0) {
        size_t train_size = size/10;
        exist_keys.reserve(train_size);
        for(size_t i=0;i<train_size;i++)
            exist_keys.push_back(read_keys[rnd(gen)]);
        non_exist_keys = read_keys;
    } else {
        size_t num = std::min(Config.exist_num, size);
        exist_keys.reserve(num);
        for(size_t i=0;i<num;i++)
            exist_keys.push_back(read_keys[rnd(gen)]);
    }
}
inline void documentid_data(){
    const char *input_path = std::getenv("DOCUMENT_ID_DATA");
    if (!input_path || !*input_path) input_path = "data/document-id.sorted.10M";
    auto read_keys = read_timestamp<key_type>(input_path);
    size_t size = read_keys.size();
    std::mt19937 gen((uint32_t)Config.seed);
    std::uniform_int_distribution<size_t> rnd(0,size-1);
    if(Config.insert_ratio > 0) {
        size_t train = size/10;
        exist_keys.reserve(train);
        for(size_t i=0;i<train;i++) exist_keys.push_back(read_keys[rnd(gen)]);
        non_exist_keys = read_keys;
    } else {
        size_t num = std::min(Config.exist_num,size);
        exist_keys.reserve(num);
        for(size_t i=0;i<num;i++) exist_keys.push_back(read_keys[rnd(gen)]);
    }
}
inline void lognormal_data_with_insert_factor(){
    std::mt19937 gen((uint32_t)Config.seed);
    std::lognormal_distribution<double> dist(0,2);
    exist_keys.reserve(Config.exist_num);
    for(size_t i=0;i<Config.exist_num;i++){
        double v=dist(gen); if(v<=0){--i;continue;}
        exist_keys.push_back((key_type)(v*1e12));
    }
    int insert_num = (int)(Config.item_num*Config.insert_factor);
    non_exist_keys.reserve(insert_num);
    for(int i=0;i<insert_num;i++){
        double v=dist(gen); if(v<=0){--i;continue;}
        non_exist_keys.push_back((key_type)(v*1e12));
    }
}
inline void skew_data(){
    key_type maxdata = 987654321;
    std::mt19937 gen((uint32_t)Config.seed);
    std::uniform_int_distribution<key_type> rnd_all(0,maxdata);
    exist_keys.reserve(Config.exist_num);
    for(size_t i=0;i<Config.exist_num;i++)
        exist_keys.push_back(rnd_all(gen));
    key_type upbound = (key_type)(Config.skewness*maxdata);
    COUT_THIS("[skewness upbound:] " << upbound);
    std::uniform_int_distribution<key_type> rnd_skew(0,upbound);
    non_exist_keys.reserve(Config.item_num);
    for(size_t i=0;i<Config.item_num;i++)
        non_exist_keys.push_back(rnd_skew(gen));
}

// ============== SOSD Facebook sample loader ================================
// This loader is deliberately minimal: it only replaces the initial key set.
// RQ6 policies, temporal drift scheduler, LinUCB controller, budgets, threads,
// and workload execution remain in examples/linverix_aidel_benchmark.cc and
// are unchanged from the frozen RQ6 source.
inline void sosd_sample_data(){
    const char* path = std::getenv("SOSD_SAMPLE_FILE");
    if (!path || !*path) path = std::getenv("FACEBOOK_SAMPLE_FILE");
    if (!path || !*path) {
        std::cerr << "benchmark=13 requires SOSD_SAMPLE_FILE to point to "
                  << "a raw uint64 sample file\n";
        std::exit(2);
    }

    FILE* fin = std::fopen(path, "rb");
    if (!fin) {
        std::perror("sosd_sample_data fopen");
        std::exit(2);
    }

    exist_keys.clear();
    non_exist_keys.clear();
    exist_keys.resize(Config.exist_num);
    const size_t got = std::fread(exist_keys.data(), sizeof(key_type),
                                  Config.exist_num, fin);
    if (got != Config.exist_num) {
        std::cerr << "SOSD sample too short: expected " << Config.exist_num
                  << " uint64 keys, read " << got << "\n";
        std::fclose(fin);
        std::exit(2);
    }

    // Require an exact-size sample so that the Facebook run preserves the
    // original RQ6 existing-key cardinality rather than silently changing it.
    key_type extra = 0;
    if (std::fread(&extra, sizeof(key_type), 1, fin) == 1) {
        std::cerr << "SOSD sample contains more than Config.exist_num keys; "
                  << "use the provided SOSD sample preparation tool\n";
        std::fclose(fin);
        std::exit(2);
    }
    std::fclose(fin);

    const char* dataset = std::getenv("SOSD_DATASET");
    COUT_THIS("load SOSD sample dataset=" << (dataset && *dataset ? dataset : "unknown")
              << ": " << path);
}

inline void facebook_sample_data(){ sosd_sample_data(); }

// ============== YCSB 解析（最小必要增强） ==========================
inline void load_ycsb(const char *path) {
    std::cout << "Attempting to load YCSB data from: " << path << std::endl;
    FILE *ycsb = fopen(path, "r");
    if (!ycsb) { perror("Failed to open file"); exit(1); }

    char buf[1024];
    char key[1024];
    key_type dummy_key = 0;
    bool isConfigSection = true;
    size_t cnt=0;

    while (fgets(buf, sizeof(buf), ycsb)) {
        if (isConfigSection) {
            if (strncmp(buf, "INSERT", 6)==0 || strncmp(buf,"SCAN",4)==0)
                isConfigSection=false;
            else
                continue;
        }
        if (strncmp(buf,"INSERT",6)==0){
            int num=sscanf(buf,"INSERT usertable %s", key);
            if(num==1){
                char* kptr=key;
                while(*kptr && !isdigit(*kptr)) ++kptr;
                dummy_key = strtoull(kptr,nullptr,10);
                exist_keys.push_back(dummy_key);
                cnt++;
            }
        } else if (strncmp(buf,"SCAN",4)==0) {
            cnt++;
        }
    }
    std::cerr << "Loaded number of items: " << cnt << "\n";
    std::cerr << "Size of exist_keys   : " << exist_keys.size() << "\n";
    fclose(ycsb);
}

inline void run_ycsb(const char *path){
    FILE *ycsb = fopen(path,"r");
    if(!ycsb){ perror("run_ycsb open fail"); exit(1); }
    std::vector<operation_item> tmp;
    tmp.reserve(YCSBconfig.operate_num);

    char *buf=nullptr;
    size_t len=0;
    size_t query_i=0, insert_i=0, delete_i=0, update_i=0, scan_i=0;
    char table[128], key_token[256];
    auto parse_key = [](const char *token) -> key_type {
        const char *p = token;
        while (*p && !isdigit(static_cast<unsigned char>(*p))) ++p;
        return static_cast<key_type>(strtoull(p, nullptr, 10));
    };

    while(getline(&buf,&len,ycsb) != -1){
        operation_item oi;
        oi.range=0;
        if(strncmp(buf,"READ",4)==0){
            if (sscanf(buf, "READ %127s %255s", table, key_token) != 2) continue;
            oi.key = parse_key(key_token);
            oi.op  = 0; query_i++;
        } else if(strncmp(buf,"INSERT",6)==0){
            if (sscanf(buf, "INSERT %127s %255s", table, key_token) != 2) continue;
            oi.key = parse_key(key_token);
            oi.op  = 1; insert_i++;
        } else if(strncmp(buf,"UPDATE",6)==0){
            if (sscanf(buf, "UPDATE %127s %255s", table, key_token) != 2) continue;
            oi.key = parse_key(key_token);
            oi.op  = 2; update_i++;
        } else if(strncmp(buf,"REMOVE",6)==0 || strncmp(buf,"DELETE",6)==0){
            if (sscanf(buf, "%*s %127s %255s", table, key_token) != 2) continue;
            oi.key = parse_key(key_token);
            oi.op  = 3; delete_i++;
        } else if(strncmp(buf,"SCAN",4)==0){
            if (sscanf(buf, "SCAN %127s %255s %d", table, key_token, &oi.range) != 3) continue;
            oi.key = parse_key(key_token);
            oi.op    = 4; scan_i++;
        } else {
            continue;
        }
        tmp.push_back(oi);
    }
    fclose(ycsb);
    if(buf) free(buf);

    YCSBconfig.operate_num = tmp.size();           // *** MOD ***
    YCSBconfig.operate_queue = (operation_item*)malloc(tmp.size()*sizeof(operation_item));
    memcpy(YCSBconfig.operate_queue, tmp.data(), tmp.size()*sizeof(operation_item));

    std::cerr<<"YCSB parsed ops: "<<YCSBconfig.operate_num<<"\n";
    std::cerr<<"  read: "<<query_i<<"\n"
             <<"insert:"<<insert_i<<"\n"
             <<"update:"<<update_i<<"\n"
             <<"remove:"<<delete_i<<"\n"
             <<"scan: "<<scan_i<<"\n";
}

// ===== read raw binary/int files =======================================
#define BUF_SIZE 2048
inline std::vector<int> read_data(const char *path) {
    std::vector<int> vec;
    FILE *fin = fopen(path, "rb");
    if(!fin){ perror("read_data"); return vec; }
    int buf[BUF_SIZE];
    while (true) {
        size_t num_read = fread(buf, sizeof(int), BUF_SIZE, fin);
        for (size_t i = 0; i < num_read; i++) vec.push_back(buf[i]);
        if (num_read < BUF_SIZE) break;
    }
    fclose(fin);
    return vec;
}
template<typename key_typeT>
inline std::vector<key_typeT> read_timestamp(const char *path) {
    std::vector<key_typeT> vec;
    FILE *fin = fopen(path, "rb");
    if(!fin){ perror("read_timestamp"); return vec; }
    key_typeT buf[BUF_SIZE];
    while (true) {
        size_t num_read = fread(buf, sizeof(key_typeT), BUF_SIZE, fin);
        for (size_t i = 0; i < num_read; i++) vec.push_back(buf[i]);
        if (num_read < BUF_SIZE) break;
    }
    fclose(fin);
    return vec;
}
template<typename key_typeT>
inline std::vector<key_typeT> read_document(const char *path){
    std::vector<key_typeT> vec;
    std::ifstream fin(path);
    if(!fin){
        std::cout << "Error: " << strerror(errno) << std::endl;
        return vec;
    }
    key_typeT a;
    while(fin>>a) vec.push_back(a);
    return vec;
}
