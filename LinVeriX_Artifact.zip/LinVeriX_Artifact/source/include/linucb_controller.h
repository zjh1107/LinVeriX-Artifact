#pragma once
#include <vector>
#include <unordered_map>
#include <cstdint>
#include <algorithm>
#include <cmath>
#include <cassert>

struct ArmContext {
  uint32_t arm_id{};
  std::vector<double> x;
  double est_cost{1.0};
};

struct ArmFeedback {
  uint32_t arm_id{};
  std::vector<double> x;
  double reward{};
};

class LinUCBController {
public:
  struct Param {
    int d = 8;
    double alpha = 1.0;
    double lambda = 1e-3;
    size_t budget_B = 4;
    // Full LinVeriX keeps its original residual-aware cold-start prior.
    // Frozen-NoAdapt disables that hand-written shortcut and ranks with the
    // model learned during the common calibration prefix.
    bool use_residual_prior = true;
  };
  using Config = Param;  // 兼容老代码

  explicit LinUCBController(const Param& p);

  void ensure_arms_exist(const std::vector<uint32_t>& arm_ids);

  std::vector<uint32_t> select(const std::vector<ArmContext>& arms);
  inline std::vector<uint32_t> selectTopB(const std::vector<ArmContext>& arms) {
    return select(arms);
  }

  void update(const std::vector<ArmFeedback>& fbs);

  void observeReward(uint32_t arm_id, double reward);
  void observeReward(uint32_t arm_id, double reward, const std::vector<double>& x);
  double uncertainty(const std::vector<double>& x) const;
  double expected_reward(uint32_t arm_id, const std::vector<double>& x) const;

  inline void set_budget_B(size_t B) { P.budget_B = B; }

private:
  struct Model {
    std::vector<double> Ainv;   // d x d
    std::vector<double> theta;  // d
    std::vector<double> b;      // d
    bool initialized = false;
  };

  Param P;
  // The shared linear model transfers feedback across segments; per-arm reward
  // summaries retain measured differences between stable local segments.
  Model shared_model_;
  uint64_t feedback_count_ = 0;
  std::unordered_map<uint32_t, uint64_t> arm_feedback_counts_;
  std::unordered_map<uint32_t, double> arm_reward_sums_;
  std::unordered_map<uint32_t, std::vector<double>> last_x_;

  void init_model(Model& m);
  double ucb(uint32_t arm, const std::vector<double>& x) const;
  void rank_by_density(const std::vector<ArmContext>& arms, std::vector<uint32_t>& out) const;

  static void sm_update_Ainv(std::vector<double>& Ainv, const std::vector<double>& x);
  static double quad_form(const std::vector<double>& Ainv, const std::vector<double>& x);
  static inline double dot(const std::vector<double>& a, const std::vector<double>& b){
    assert(a.size()==b.size());
    double s=0; for (size_t i=0;i<a.size();++i) s+=a[i]*b[i]; return s;
  }
};
