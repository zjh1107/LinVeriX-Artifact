#pragma once
#include <vector>
#include <algorithm>
#include <cstdint>

namespace p99s {

// 计算 q 分位，输入样本单位：纳秒（uint32_t）
inline double percentile_ns(const std::vector<uint32_t>& ns_samples, double q){
  if (ns_samples.empty()) return 0.0;
  std::vector<uint32_t> v = ns_samples; // 拷贝避免修改原数据
  const size_t n = v.size();
  if (n == 1) return (double)v[0];
  const size_t idx = (size_t)(q * (n - 1));
  std::nth_element(v.begin(), v.begin()+idx, v.end());
  return (double)v[idx];
}

} // namespace p99s