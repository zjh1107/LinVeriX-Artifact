#ifndef __LEVEL_BIN_CON_H__
#define __LEVEL_BIN_CON_H__
#define MAX_LEVEL 6
#include "util.h"
#include <atomic>
#include <cassert>
#include <vector>
#include <random>
#include <shared_mutex>
#include <memory>
#include <iostream>
#include <thread>
#include <future>
#include <openssl/sha.h>
#include <sstream>

namespace aidel {

template<class _Key, class _Data, 
         class _Value = std::pair<_Key, _Data>,
         class _Compare = std::less<_Key>, 
         class _Alloc = std::allocator<_Value> >
class LevelBinCon {

public:
    typedef _Key key_type;
    typedef _Data data_type;
    typedef _Value value_type;
    typedef _Compare key_compare;
    typedef size_t size_type;     
    typedef std::pair<key_type, data_type> pair_type;   

    typedef enum {
        ok,
        failed,
        retrain
    } result_t;

public:
    static std::string compute_hash(const std::string& data) {
        unsigned char hash[SHA256_DIGEST_LENGTH];
        SHA256_CTX sha256;
        SHA256_Init(&sha256);
        SHA256_Update(&sha256, data.c_str(), data.size());
        SHA256_Final(hash, &sha256);

        std::stringstream ss;
        for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i) {
            ss << std::hex << (int)hash[i];
        }
        return ss.str();
    }

    struct skiplist_node {
        key_type key;
        data_type data;
        std::atomic<bool> is_deleted {false}; 
        std::vector<std::atomic<skiplist_node*>> forward;
        std::shared_mutex node_lock;  
        std::string hash_value;
        bool needs_hash_update {true}; 

        skiplist_node(int lvl, const key_type& k, const data_type& d) 
            : key(k), data(d), forward(lvl) {
            for (int i = 0; i < lvl; ++i) {
                forward[i].store(nullptr);
            }
            update_hash();
        }

        void update_hash() {
            if (needs_hash_update) {
                std::stringstream ss;
                ss << key << data;
                for (auto& fwd : forward) {
                    skiplist_node* next_node = fwd.load();
                    if (next_node) {
                        ss << next_node->hash_value;
                    }
                }
                hash_value = LevelBinCon::compute_hash(ss.str());
                needs_hash_update = false; 
            }
        }
    };

    // std::allocator keeps the benchmark self-contained and avoids relying on
    // a process-global Boost pool during concurrent teardown.
    typedef std::allocator<skiplist_node> node_allocator;
    std::vector<node_allocator> level_allocators;

    node_allocator& select_allocator(int level) {
        if (level_allocators.empty()) {
            for (int i = 0; i < MAX_LEVEL; ++i) {
                level_allocators.push_back(node_allocator());
            }
        }
        return level_allocators[level];
    }

    inline skiplist_node* allocate_skiplist_node(int level, const key_type& key, const data_type& value) {
        node_allocator& allocator = select_allocator(level);
        skiplist_node* new_node = allocator.allocate(1);
        new (new_node) skiplist_node(level, key, value);
        return new_node;
    }

    inline void deallocate_skiplist_node(skiplist_node* node, int level) {
        node_allocator& allocator = select_allocator(level);
        node->~skiplist_node();
        allocator.deallocate(node, 1);
    }

    int random_level() {
        static thread_local std::random_device rd;
        static thread_local std::mt19937 gen(rd());
        static thread_local std::uniform_real_distribution<> dis(0, 1);
        int lvl = 1;
        while (dis(gen) < 0.5 && lvl < MAX_LEVEL) {
            lvl++;
        }
        return lvl;
    }

public:
    class iterator {
    public:
        typedef typename LevelBinCon::key_type key_type;
        typedef typename LevelBinCon::data_type data_type;
        typedef iterator self;

    private:
        skiplist_node* cur_node;

    public:
        inline iterator() : cur_node(nullptr) {}
        inline iterator(skiplist_node* node) : cur_node(node) {}

        inline const key_type& key() const {
            return cur_node->key;
        }

        inline const data_type& data() const {
            return cur_node->data;
        }

        inline self& operator++() {
            if (cur_node) {
                cur_node = cur_node->forward[0].load();
            }
            return *this;
        }

        inline self operator++(int) {
            self tmp = *this;
            ++(*this);
            return tmp;
        }

        inline bool operator==(const self& x) const {
            return cur_node == x.cur_node;
        }

        inline bool operator!=(const self& x) const {
            return cur_node != x.cur_node;
        }
    };

public:
    explicit inline LevelBinCon() 
        : m_head(nullptr), m_size(0) 
    {
        m_head = allocate_skiplist_node(MAX_LEVEL, key_type(), data_type());
    }

    inline ~LevelBinCon() {
        clear();
    }

    inline iterator begin() {
        return iterator(m_head->forward[0].load());
    }

    inline iterator end() {
        return iterator(nullptr);
    }

private:
    void clear() {
        skiplist_node* node = m_head->forward[0].load();
        while (node != nullptr) {
            skiplist_node* next = node->forward[0].load();
            deallocate_skiplist_node(node, MAX_LEVEL);
            node = next;
        }
        m_head = allocate_skiplist_node(MAX_LEVEL, key_type(), data_type());
        m_size = 0;
    }

    inline bool key_less(const key_type &a, const key_type &b) const {
        return m_key_less(a, b);
    }

    inline bool key_equal(const key_type &a, const key_type &b) const {
        return !m_key_less(a, b) && !m_key_less(b, a);
    }

public:

    std::vector<pair_type> scan(const key_type& start_key, size_t n) const {
        std::vector<pair_type> result;
        result.reserve(n);

        skiplist_node* node = m_head;
        for (int level = MAX_LEVEL - 1; level >= 0; --level) {
            while (node->forward[level].load() &&
                   key_less(node->forward[level].load()->key, start_key)) {
                node = node->forward[level].load();
            }
        }
        node = node->forward[0].load();


        while (node && result.size() < n) {
            if (!node->is_deleted.load()) {
                result.emplace_back(node->key, node->data);
            }
            node = node->forward[0].load();
        }
        return result;
    }

    int scan_into(const key_type& start_key, size_t n, std::vector<pair_type>& out) const {
        size_t before = out.size();
        auto v = scan(start_key, n);
        out.insert(out.end(), v.begin(), v.end());
        return static_cast<int>(out.size() - before);
    }

    void update_hash_upward(skiplist_node* node) {
        while (node) {
            node->update_hash();
            node = node->forward.empty() ? nullptr : node->forward[0].load();
        }
    }

    bool verify_node(const key_type& key) {
        skiplist_node* node = find_node(key);
        if (!node) {
            return false; 
        }

        std::string computed_hash = node->hash_value;
        while (node) {
            computed_hash = compute_hash(computed_hash + (node->forward.empty() ? "" : node->forward[0].load()->hash_value));
            node = node->forward.empty() ? nullptr : node->forward[0].load();
        }
        return computed_hash == m_head->hash_value;
    }

    skiplist_node* find_node(const key_type &key) const {
        skiplist_node* node = m_head;
        for (int level = MAX_LEVEL - 1; level >= 0; --level) {
            while (node->forward[level].load() && node->forward[level].load()->key < key) {
                node = node->forward[level].load();
            }
        }
        node = node->forward[0].load();
        if (node && node->key == key && !node->is_deleted.load()) {
            return node;
        }
        return nullptr;
    }

    iterator find(const key_type &key) {
        skiplist_node* node = find_node(key);
        if (node) {
            return iterator(node);
        }
        return end();
    }

    result_t insert(const key_type& key, const data_type& value) {
        skiplist_node* update[MAX_LEVEL];
        skiplist_node* node = m_head;

        for (int level = MAX_LEVEL - 1; level >= 0; --level) {
            std::shared_lock<std::shared_mutex> node_lock(node->node_lock);
            while (node->forward[level].load() && node->forward[level].load()->key < key) {
                node = node->forward[level].load();
            }
            update[level] = node;
        }

        node = node->forward[0].load();
        if (node && node->key == key && !node->is_deleted.load()) {
            return result_t::failed;
        } else {
            int new_level = random_level();
            skiplist_node* new_node = allocate_skiplist_node(new_level, key, value);
            new_node->needs_hash_update = true;

            for (int i = 0; i < new_level; ++i) {
                std::unique_lock<std::shared_mutex> update_lock(update[i]->node_lock);
                new_node->forward[i].store(update[i]->forward[i].load());
                update[i]->forward[i].store(new_node);
            }

            m_size++;
            update_hash_upward(new_node);
            return result_t::ok;
        }
    }

    result_t update(const key_type &key, const data_type &value) {
        skiplist_node* node = find_node(key);
        if (node) {
            std::unique_lock<std::shared_mutex> lock(node->node_lock);
            node->data = value;
            node->needs_hash_update = true;
            update_hash_upward(node);
            return result_t::ok;
        }
        return result_t::failed;
    }

    result_t remove(const key_type &key) {
        skiplist_node* update[MAX_LEVEL];
        skiplist_node* node = m_head;

        for (int level = MAX_LEVEL - 1; level >= 0; --level) {
            std::shared_lock<std::shared_mutex> node_lock(node->node_lock);
            while (node->forward[level].load() && node->forward[level].load()->key < key) {
                node = node->forward[level].load();
            }
            update[level] = node;
        }

        node = node->forward[0].load();
        if (node && node->key == key && !node->is_deleted.load()) {
            node->is_deleted.store(true);
            for (int i = 0; i < MAX_LEVEL; ++i) {
                if (update[i]->forward[i].load() == node) {
                    std::unique_lock<std::shared_mutex> update_lock(update[i]->node_lock);
                    update[i]->forward[i].store(node->forward[i].load());
                    update[i]->needs_hash_update = true;
                }
            }

            deallocate_skiplist_node(node, MAX_LEVEL);
            m_size--;
            update_hash_upward(m_head);
            return result_t::ok;
        }
        return result_t::failed;
    }

    result_t con_find_retrain(const key_type &key, data_type &value) {
        skiplist_node* node = find_node(key);
        if (node) {
            std::shared_lock<std::shared_mutex> lock(node->node_lock);
            value = node->data;
            return result_t::ok;
        }
        return result_t::failed;
    }

    result_t con_insert_retrain(const key_type& key, const data_type& value) {
        return insert(key, value);  
    }

    void resort(const std::vector<key_type>& keys, const std::vector<data_type>& vals) {
        clear();
        for (size_t i = 0; i < keys.size(); i++) {
            insert(keys[i], vals[i]);
        }
    }

    void parallel_self_check() const {
        auto check_segment = [](skiplist_node* start) {
            skiplist_node* node = start;
            while (node && node->forward[0].load()) {
                assert(node->key < node->forward[0].load()->key);
                node = node->forward[0].load();
            }
        };

        std::vector<std::future<void>> futures;
        skiplist_node* node = m_head->forward[0].load();
        
        for (int i = 0; i < std::thread::hardware_concurrency(); ++i) {
            futures.push_back(std::async(std::launch::async, check_segment, node));
            for (int j = 0; j < 10 && node; ++j) {
                node = node->forward[0].load();
            }
        }

        for (auto& future : futures) {
            future.get();
        }
    }

    void self_check() const {
        parallel_self_check();
    }

private:
    skiplist_node* m_head;
    size_t m_size;
    key_compare m_key_less;
};

} // namespace aidel

#endif
