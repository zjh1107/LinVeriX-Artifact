#!/usr/bin/env python3
"""Reconcile RQ1 maintenance events, stage budgets, publication and query use."""
import argparse
import csv
import hashlib
import json
import re
import time
from collections import Counter, defaultdict
from pathlib import Path

KV = re.compile(r"([A-Za-z][A-Za-z0-9_]*)=([^\s]+)")


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as stream:
        fieldnames = list(dict.fromkeys(key for row in rows for key in row))
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def close_enough(actual, expected):
    return abs(actual - expected) <= max(0.05, 0.01 * max(abs(actual), abs(expected)))


def audit(run_dir, log_dir, out_dir):
    started = time.perf_counter()
    errors, events, ledgers, summaries = [], [], [], []
    csv_files = sorted(run_dir.glob("*_s*.csv"))
    if not csv_files:
        raise SystemExit(f"[AUDIT-FAIL] no RQ1 runs under {run_dir}")

    for csv_path in csv_files:
        stem = csv_path.stem
        log_path = log_dir / f"{stem}.log"
        if not log_path.is_file():
            errors.append(f"{stem}: missing event log {log_path}")
            continue
        rows = read_csv(csv_path)
        if not rows:
            errors.append(f"{stem}: empty run CSV")
            continue

        parsed_events, route_rows = [], []
        for line_no, line in enumerate(log_path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            if line.startswith("[MAINT_EVENT]"):
                event = {key: value for key, value in KV.findall(line)}
                event["run"] = stem
                event["log_line"] = line_no
                parsed_events.append(event)
            elif line.startswith("[MODEL_ROUTE]"):
                route = {key: value for key, value in KV.findall(line)}
                route["run"] = stem
                route_rows.append(route)

        ids = [e.get("event_id", "") for e in parsed_events]
        if any(not value for value in ids):
            errors.append(f"{stem}: maintenance event is missing event_id")
        elif len(ids) != len(set(ids)):
            errors.append(f"{stem}: duplicate event_id")

        counts = Counter()
        costs = defaultdict(float)
        by_window_segment = Counter()
        for event in parsed_events:
            try:
                window = int(event["window"])
                segment = int(event["segment"])
                cost = float(event["cost_ms"])
                status = event["status"]
                phase = event.get("phase", "baseline")
            except (KeyError, ValueError) as exc:
                errors.append(f"{stem}: malformed event at log line {event['log_line']}: {exc}")
                continue
            counts[(window, status)] += 1
            counts[(window, "phase:" + phase)] += 1
            costs[(window, "total")] += cost
            costs[(window, phase)] += cost
            by_window_segment[(window, segment)] += 1
            event.update(window_id=window, segment_id=segment, status=status,
                         phase=phase, cost_ms=cost)
            if status not in {"published", "rejected_stale", "training_failed"}:
                errors.append(f"{stem} window={window} segment={segment}: unknown status={status}")
            if status == "published":
                try:
                    before = int(event["model_version_before"])
                    after = int(event["model_version_after"])
                    if after != before + 1:
                        errors.append(f"{stem} window={window} segment={segment}: model version did not advance by one")
                except (KeyError, ValueError):
                    errors.append(f"{stem} window={window} segment={segment}: publish lacks model versions")
            elif status == "rejected_stale":
                if event.get("model_version_after") != event.get("model_version_before"):
                    errors.append(f"{stem} window={window} segment={segment}: stale publication changed model version")

        # A normal LinVeriX RQ1 run enables avoidance. A segment can consume
        # at most one slot in one window, even if both phases nominate it.
        if stem.startswith("linverix_"):
            for (window, segment), count in by_window_segment.items():
                if count > 1:
                    errors.append(f"{stem} window={window} segment={segment}: duplicate maintenance ({count} events)")

        route_index = defaultdict(list)
        for route in route_rows:
            try:
                key = (int(route["segment"]), int(route["model_version"]))
                route_index[key].append((int(route["window"]), int(route["query_count"])))
            except (KeyError, ValueError):
                errors.append(f"{stem}: malformed MODEL_ROUTE row {route}")

        route_registered = route_verified = 0
        for event in parsed_events:
            if event.get("status") != "published":
                continue
            try:
                segment = int(event["segment"])
                version = int(event["model_version_after"])
                event_window = int(event["window"])
                version_routes = route_index[(segment, version)]
                later_publish = min((int(other["window"]) for other in parsed_events
                                     if other.get("status") == "published"
                                     and int(other.get("segment", -1)) == segment
                                     and int(other.get("model_version_before", -1)) >= version),
                                    default=None)
                if later_publish is not None:
                    version_routes = [(w, q) for w, q in version_routes
                                      if w <= later_publish]
                registered = any(w >= event_window for w, _ in version_routes)
                observed = any(w >= event_window and q > 0 for w, q in version_routes)
                if not registered:
                    errors.append(f"{stem} window={event_window} segment={segment}: published version {version} is absent from query-route records")
                else:
                    route_registered += 1
                if observed:
                    route_verified += 1
            except (KeyError, ValueError):
                errors.append(f"{stem}: cannot match publication to query-route evidence")

        budget_path = run_dir / f"budget_{stem}" / "budget.csv"
        is_linverix = stem.startswith("linverix_")
        budget_rows = []
        if is_linverix:
            if not budget_path.is_file():
                errors.append(f"{stem}: missing LinVeriX phase budget ledger {budget_path}")
            else:
                budget_rows = read_csv(budget_path)
        budget_by_window = {int(row["window_id"]): row for row in budget_rows}

        run_published = run_rejected = run_failed = run_violations = run_phase_mismatches = 0
        run_matched_events = 0
        run_duplicate_maintenance = 0
        valid_windows = {int(float(row["window_id"])) for row in rows}
        for event in parsed_events:
            try:
                event_window = int(event["window"])
                if event_window not in valid_windows:
                    errors.append(f"{stem}: event {event.get('event_id')} has no matching CSV window {event_window}")
            except (KeyError, ValueError):
                pass
        for row in rows:
            window = int(float(row["window_id"]))
            budget = int(float(row["budget_B"]))
            used = int(float(row["budget_used"]))
            executed = int(float(row["retrain_exec_cnt"]))
            published = counts[(window, "published")]
            rejected = counts[(window, "rejected_stale")]
            failed = counts[(window, "training_failed")]
            seen = published + rejected + failed
            violation = used > budget or executed > budget or seen != executed or seen > used
            if violation:
                run_violations += 1
                errors.append(f"{stem} window={window}: B={budget} used={used} executed={executed} events={seen}")
            if seen == executed:
                run_matched_events += seen
            if not close_enough(costs[(window, "total")], float(row["retrain_cost_ms_sum"])):
                errors.append(f"{stem} window={window}: event costs do not match CSV retrain_cost_ms_sum")

            p1_events = counts[(window, "phase:phase1")]
            p2_events = counts[(window, "phase:phase2")]
            if is_linverix:
                ledger = budget_by_window.get(window)
                if ledger is None:
                    run_phase_mismatches += 1
                    errors.append(f"{stem} window={window}: missing phase ledger row")
                else:
                    b1, b2 = int(ledger["B1_alloc"]), int(ledger["B2_alloc"])
                    u1, u2 = int(ledger["B1_used"]), int(ledger["B2_used"])
                    if b1 + b2 != budget or u1 > b1 or u2 > b2 or u1 + u2 > budget:
                        run_violations += 1
                        errors.append(f"{stem} window={window}: invalid phase allocation/use B={budget} B1={b1}/{u1} B2={b2}/{u2}")
                    if (u1 != p1_events or u2 != p2_events or
                        u1 != int(float(row["usedB_phase1"])) or
                        u2 != int(float(row["usedB_phase2"]))):
                        run_phase_mismatches += 1
                        errors.append(f"{stem} window={window}: CSV, stage ledger and maintenance events disagree on phase counts")
                    run_duplicate_maintenance += sum(
                        max(0, count - 1) for (event_window, _), count in by_window_segment.items()
                        if event_window == window)
                    for phase, csv_key in (("phase1", "phase1_cost_ms_sum"),
                                           ("phase2", "phase2_cost_ms_sum")):
                        if not close_enough(costs[(window, phase)], float(row[csv_key])):
                            run_phase_mismatches += 1
                            errors.append(f"{stem} window={window}: {phase} event costs do not match CSV")
                    ledgers.append({"run": stem, "window_id": window, "budget_B": budget,
                                    "B1_alloc": b1, "B2_alloc": b2, "B1_used": u1,
                                    "B2_used": u2, "event_phase1": p1_events,
                                    "event_phase2": p2_events, "executed": executed,
                                    "budget_ok": int(not violation),
                                    "phase_counts_ok": int(u1 == p1_events and u2 == p2_events)})
            run_published += published
            run_rejected += rejected
            run_failed += failed

        events.extend(parsed_events)
        summaries.append({"run": stem, "windows": len(rows), "events": len(parsed_events),
                          "matched_events": run_matched_events,
                          "event_match_rate": (run_matched_events / len(parsed_events)
                                               if parsed_events else 1.0),
                          "published": run_published, "rejected_stale": run_rejected,
                          "training_failed": run_failed, "budget_violations": run_violations,
                          "phase_mismatches": run_phase_mismatches,
                          "duplicate_maintenance": run_duplicate_maintenance,
                          "published_versions_route_registered": route_registered,
                          "published_versions_seen_by_queries": route_verified,
                          "audit_pass": 0})

    # Export a hash chain for post-export tamper detection. It is not a signed
    # trust root and is not presented as an external timestamp.
    chain = "0" * 64
    chained = []
    for event in sorted(events, key=lambda e: (e.get("run", ""), int(e.get("window_id", 0)),
                                                int(e.get("segment_id", 0)), e.get("event_id", ""))):
        payload = json.dumps(event, sort_keys=True, separators=(",", ":"))
        chain = hashlib.sha256((chain + payload).encode()).hexdigest()
        chained.append({**event, "chain_sha256": chain})
    elapsed_ms = (time.perf_counter() - started) * 1000.0
    failed = bool(errors)
    for summary in summaries:
        summary["audit_elapsed_ms"] = elapsed_ms
        summary["audit_pass"] = int(not failed)
    out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(out_dir / "maintenance_events.csv", chained)
    write_csv(out_dir / "window_budget_ledger.csv", ledgers)
    write_csv(out_dir / "audit_summary.csv", summaries)
    (out_dir / "audit_root.sha256").write_text(chain + "\n", encoding="ascii")
    report = [f"runs={len(csv_files)}", f"maintenance_events={len(events)}",
              f"budget_windows={len(ledgers)}", f"audit_elapsed_ms={elapsed_ms:.3f}",
              f"published_versions_route_registered={sum(s['published_versions_route_registered'] for s in summaries)}",
              f"published_versions_seen_by_queries={sum(s['published_versions_seen_by_queries'] for s in summaries)}",
              f"audit_root_sha256={chain}", "result=" + ("FAIL" if failed else "PASS")]
    report.extend("failure=" + error for error in errors)
    (out_dir / "audit_report.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    if failed:
        raise SystemExit("[AUDIT-FAIL] " + "; ".join(errors[:6]))
    if not ledgers:
        raise SystemExit("[AUDIT-FAIL] no LinVeriX phase ledger rows found")
    print(f"[AUDIT-PASS] runs={len(csv_files)} events={len(events)} windows={len(ledgers)} "
          f"route_registered={sum(s['published_versions_route_registered'] for s in summaries)} "
          f"query_versions={sum(s['published_versions_seen_by_queries'] for s in summaries)} "
          f"elapsed_ms={elapsed_ms:.3f} root={chain}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dir", type=Path, help="RQ1 Books CSV directory")
    parser.add_argument("out_dir", type=Path)
    parser.add_argument("--log-dir", type=Path, help="RQ1 Books log directory; defaults to run_dir")
    args = parser.parse_args()
    audit(args.run_dir, args.log_dir or args.run_dir, args.out_dir)


if __name__ == "__main__":
    main()
