#!/usr/bin/env python3
"""Summarize four-policy formal runs for RQ1 and the PGM transfer experiment."""
from __future__ import annotations
import argparse, csv, math, statistics
from pathlib import Path

POLICIES = ("linverix", "greedy", "threshold", "periodic")
T95 = {2: 12.706, 3: 4.303, 4: 3.182, 5: 2.776, 6: 2.571}

def mean_ci(values: list[float]) -> tuple[float, float]:
    mean = statistics.fmean(values)
    ci = T95.get(len(values), 1.96) * statistics.stdev(values) / math.sqrt(len(values)) if len(values) > 1 else math.nan
    return mean, ci

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("run_root", type=Path)
    ap.add_argument("result_root", type=Path)
    ap.add_argument("--dataset", default="books")
    ap.add_argument("--warmup-windows", type=int, default=3)
    ap.add_argument("--window-sec", type=float, default=2.0)
    a = ap.parse_args()
    raw = {}
    for p in (a.run_root / a.dataset).glob("*.csv"):
        stem = p.stem
        name, seed_s = stem.rsplit("_s", 1)
        if name in POLICIES:
            with p.open(newline="", encoding="utf-8") as f:
                raw[(name, int(seed_s))] = list(csv.DictReader(f))
    seeds = sorted({s for _, s in raw})
    for seed in seeds:
        missing = [p for p in POLICIES if (p, seed) not in raw]
        if missing:
            raise SystemExit(f"incomplete seed={seed}: {missing}")
    per_seed = []
    for seed in seeds:
        warm = [float(r["p99_after_ms"]) for p in POLICIES for r in raw[(p, seed)]
                if int(float(r["window_id"])) <= a.warmup_windows and float(r["p99_after_ms"]) > 0]
        if not warm:
            raise SystemExit(f"missing shared warm-up p99 for seed={seed}")
        ref = statistics.fmean(warm)
        for policy in POLICIES:
            rows = [r for r in raw[(policy, seed)] if int(float(r["window_id"])) > a.warmup_windows]
            if not rows:
                raise SystemExit(f"no evaluated windows: {policy} seed={seed}")
            p99 = [float(r["p99_after_ms"]) for r in rows]
            auc = sum(max(0.0, v / ref - 1.0) * a.window_sec for v in p99)
            residual_key = "topk_sum_post_phase2_us"
            residual = [float(r[residual_key]) for r in rows]
            per_seed.append({
                "dataset": a.dataset, "policy": policy, "seed": seed, "active_windows": len(rows),
                "warmup_p99_ms": ref,
                "throughput_after_ops_s": statistics.fmean(float(r["tput_after"]) for r in rows),
                "p99_after_ms": statistics.fmean(p99), "p99_auc_s": auc,
                "mean_residual_us": statistics.fmean(residual),
                "peak_residual_us": max(float(r["peak_topk_sum_us"]) for r in rows),
                "retrain_ms_per_window": statistics.fmean(float(r["retrain_cost_ms_sum"]) for r in rows),
                "retrain_total_ms": sum(float(r["retrain_cost_ms_sum"]) for r in rows),
                "repairs_per_window": statistics.fmean(float(r["retrain_exec_cnt"]) for r in rows),
            })
    a.result_root.mkdir(parents=True, exist_ok=True)
    fields = list(per_seed[0])
    with (a.result_root / "per_seed.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(per_seed)
    aggregate = []
    metrics = fields[4:]
    for policy in POLICIES:
        rows = [r for r in per_seed if r["policy"] == policy]
        rec = {"policy": policy, "seeds": len(rows)}
        for metric in metrics:
            m, ci = mean_ci([float(r[metric]) for r in rows])
            rec[f"{metric}_mean"] = m; rec[f"{metric}_ci95"] = ci
        aggregate.append(rec)
    with (a.result_root / "aggregate.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(aggregate[0])); w.writeheader(); w.writerows(aggregate)
    for r in aggregate:
        print(f"{a.dataset:10s} {r['policy']:10s} P99={r['p99_after_ms_mean']*1000:.3f}us "
              f"AUC={r['p99_auc_s_mean']:.4f}s residual={r['mean_residual_us_mean']:.2f}us "
              f"throughput={r['throughput_after_ops_s_mean']:.1f} retrain={r['retrain_ms_per_window_mean']:.3f}ms/window")
    print(f"[PASS] wrote {a.result_root / 'per_seed.csv'} and {a.result_root / 'aggregate.csv'}")

if __name__ == "__main__":
    main()
