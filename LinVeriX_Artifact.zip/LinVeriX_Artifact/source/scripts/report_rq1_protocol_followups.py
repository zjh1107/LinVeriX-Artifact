#!/usr/bin/env python3
"""Summarize RQ2/RQ3/RQ5 runs using the RQ1-protocol CSV schema."""
import argparse, csv, json, math, statistics
from collections import defaultdict
from pathlib import Path

def avg(xs):
    return statistics.fmean(xs) if xs else math.nan

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('root',type=Path)
    ap.add_argument('--warmup',type=int,default=10)
    ap.add_argument('--window-sec',type=float,default=2.0)
    a=ap.parse_args()
    records=[]
    for folder in ('rq2','rq3','rq5'):
        for path in sorted((a.root/folder).glob('*_s*.csv')):
            case=path.stem.rsplit('_s',1)[0]
            seed=int(path.stem.rsplit('_s',1)[1])
            with path.open(newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
            if len(rows)<=a.warmup: raise SystemExit(f'no active windows: {path}')
            residual=('topk_sum_post_phase2_cmp_per_query' if 'topk_sum_post_phase2_cmp_per_query' in rows[0] else 'topk_sum_post_phase2_us')
            records.append((folder,case,seed,rows,residual))
    if not records: raise SystemExit(f'no result CSVs under {a.root}')
    baselines=defaultdict(list)
    for rq,case,seed,rows,_ in records:
        scenario=case.split('_')[0] if rq=='rq2' else 'all'
        baselines[(rq,seed,scenario)].extend(float(r['p99_after_ms']) for r in rows[:a.warmup] if float(r['p99_after_ms'])>0)
    out=[]
    for rq,case,seed,rows,residual in records:
        scenario=case.split('_')[0] if rq=='rq2' else 'all'
        warm=avg(baselines[(rq,seed,scenario)])
        if not math.isfinite(warm) or warm<=0: raise SystemExit(f'no common warm-up P99: {case} seed={seed}')
        active=rows[a.warmup:]
        p99=[float(r['p99_after_ms']) for r in active]
        out.append(dict(rq=rq,case=case,seed=seed,active_windows=len(active),
            warmup_p99_ms=warm,mean_p99_us=1000*avg(p99),
            p99_degradation_auc_s=sum(max(0,v/warm-1)*a.window_sec for v in p99),
            mean_topk_residual=avg([float(r[residual]) for r in active]),
            residual_unit='comparisons/query' if 'cmp_per_query' in residual else 'us',
            maintenance_ms_per_window=avg([float(r['retrain_cost_ms_sum']) for r in active]),
            retrains_per_window=avg([float(r['retrain_exec_cnt']) for r in active])))
    fields=list(out[0])
    with (a.root/'per_seed.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(out)
    groups=defaultdict(list)
    for r in out:groups[(r['rq'],r['case'])].append(r)
    agg=[]
    for (rq,case),rs in sorted(groups.items()):
        row=dict(rq=rq,case=case,seeds=len(rs),residual_unit=rs[0]['residual_unit'])
        for key in ('mean_p99_us','p99_degradation_auc_s','mean_topk_residual','maintenance_ms_per_window','retrains_per_window'):
            row[key+'_mean']=avg([float(r[key]) for r in rs])
            row[key+'_sd']=statistics.stdev([float(r[key]) for r in rs]) if len(rs)>1 else math.nan
        agg.append(row)
    with (a.root/'aggregate.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(agg[0]));w.writeheader();w.writerows(agg)
    for r in agg:
        print(f"{r['rq']:3s} {r['case']:22s} P99={r['mean_p99_us_mean']:.3f} us AUC={r['p99_degradation_auc_s_mean']:.3f} s residual={r['mean_topk_residual_mean']:.3f} {r['residual_unit']} retrains={r['retrains_per_window_mean']:.2f}/window")
    print(f'[PASS] summarized {len(out)} seed-cases at {a.root}')

if __name__=='__main__': main()
