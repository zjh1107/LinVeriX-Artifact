#!/usr/bin/env python3
"""Screen LinVeriX-only RQ2 recovery dynamics against the paper's targets."""
import csv
import json
import sys
from pathlib import Path


def main():
    formal = "--formal" in sys.argv[1:]
    args = [arg for arg in sys.argv[1:] if arg != "--formal"]
    if len(args) != 1:
        raise SystemExit("usage: gate_rq2_recovery.py RUN_DIRECTORY [--formal]")
    root = Path(args[0])
    path = root / "rq2_paper_target_events.csv"
    if not path.is_file():
        raise SystemExit(f"missing per-event RQ2 results: {path}")
    with path.open(newline="", encoding="utf-8") as stream:
        events = list(csv.DictReader(stream))
    if not events:
        raise SystemExit("RQ2 event table is empty")

    groups = {mode: [r for r in events if r["mode"] == mode]
              for mode in ("continuous", "spaced")}
    if not groups["continuous"] or not groups["spaced"]:
        raise SystemExit("RQ2 must contain both continuous and spaced LinVeriX runs")

    continuous_budget_hit = all(int(r["budget_target_reached"]) == 1
                                and int(r["budget_target_windows"]) == 0
                                for r in groups["continuous"])
    # Continuous drift injects again at the next control window, so it tests
    # the one-window budget target; full recovery is intentionally not expected.
    continuous_window_limited = all(r["full_recovery_status"] == "not_recovered_before_next_injection"
                                    for r in groups["continuous"])

    spaced_budget_hit = all(int(r["budget_target_reached"]) == 1
                            and int(r["budget_target_windows"]) == 0
                            for r in groups["spaced"])
    spaced_observable = [r for r in groups["spaced"]
                         if r["full_recovery_status"] != "right_censored_at_run_end"]
    spaced_censored = [r for r in groups["spaced"]
                       if r["full_recovery_status"] == "right_censored_at_run_end"]
    spaced_full_recovery = bool(spaced_observable) and all(
        int(r["full_recovery_reached"]) == 1
        and int(r["full_recovery_windows"]) == 2
        for r in spaced_observable)

    checks = {
        "continuous_budget_bound_reached_in_injection_window": continuous_budget_hit,
        "continuous_full_recovery_not_expected_before_next_injection": continuous_window_limited,
        "spaced_budget_bound_reached_in_injection_window": spaced_budget_hit,
        "all_observable_spaced_events_fully_recover_within_two_windows": spaced_full_recovery,
        "spaced_right_censored_events_recorded": bool(spaced_censored),
    }
    passed = all(checks.values())
    label = "FORMAL" if formal else "PRETEST"
    decision = {
        "status": f"{'PASS' if passed else 'FAIL'}_RQ2_{label}",
        "target": "LinVeriX recovery dynamics only; continuous drift tests one-window budget-bound attainment, spaced drift tests full residual recovery before the next shock.",
        "checks": checks,
        "event_counts": {mode: len(rows) for mode, rows in groups.items()},
        "spaced_observable_full_recovery_events": sum(
            int(r["full_recovery_reached"]) == 1 for r in spaced_observable),
        "spaced_observable_events": len(spaced_observable),
        "spaced_right_censored_events": len(spaced_censored),
        "note": "This is a design-screening gate, not a cross-policy superiority or statistical-significance test."
    }
    output = root / ("rq2_formal_decision.json" if formal else "rq2_recovery_decision.json")
    output.write_text(json.dumps(decision, indent=2), encoding="utf-8")
    print(f"RQ2 LinVeriX recovery {label.lower()}: {decision['status']}; wrote {output}")
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
