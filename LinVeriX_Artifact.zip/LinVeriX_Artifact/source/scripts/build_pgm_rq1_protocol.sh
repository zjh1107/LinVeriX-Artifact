#!/usr/bin/env bash
set -euo pipefail
repo_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$repo_root"
mkdir -p build
python3 - <<'PY'
from pathlib import Path

src = Path('examples/linverix_aidel_protocol.cc').read_text()
alias = 'using aidel_type = aidel::AIDEL<key_type, val_type>;'
if src.count(alias) != 1:
    raise SystemExit('expected exactly one AIDEL backend alias')
src = src.replace('#include "aidel_impl.h"', '#include "aidel_impl.h"\n#include "pgm_compat.h"', 1)
src = src.replace(alias, 'using aidel_type = PgmCompat<key_type, val_type>;', 1)
Path('build/linverix_pgm_rq1_protocol.cc').write_text(src)
PY
"${CXX:-/usr/bin/c++}" -O3 -DNDEBUG -std=gnu++17 -Wall -Wextra \
  -Wno-unused-parameter -Wno-deprecated-declarations \
  -I. -Iinclude -Iconfig -Iutil -Ithird_party/pgm/include \
  build/linverix_pgm_rq1_protocol.cc src/linucb_controller.cc \
  config/base_latency.cpp src/data_globals.cpp -pthread -lcrypto -lm -ldl \
  -o build/linverix_pgm_rq1_protocol
