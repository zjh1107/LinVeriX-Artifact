#!/usr/bin/env python3
"""Run paper-style LinVeriX recovery dynamics using the frozen RQ1 binary.

Only the drift cadence varies.  This script is deliberately separate from the
fixed RQ2 runner and never changes the scheduler source or binary.
"""
import argparse
import csv
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROTOCOL = json.loads((ROOT / "config/formal_experiment_protocol.json").read_text(encoding="utf-8"))
COMMON = PROTOCOL["common"]
EXPECTED_AIDEL_SHA256 = "9c6b2e63c84aac352ce1cca2c1ab3a6d6cf8a360e404193ad27a49fef7d47ded"
def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def runtime_path(path):
    resolved = path.resolve()
    try:
        return resolved.relative_to(ROOT).as_posix()
    except ValueError:
        return str(resolved)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", type=Path, default=Path("runs/rq2_recovery_formal"))
    ap.add_argument("--windows", type=int, default=COMMON["windows"])
    ap.add_argument("--warmup", type=int, default=COMMON["warmup_windows"])
    ap.add_argument("--seeds", type=int, nargs="+", default=COMMON["seeds"])
    ap.add_argument("--window-sec", type=int, default=COMMON["window_sec"])
    ap.add_argument("--threads", type=int, default=COMMON["threads"])
    ap.add_argument("--item-num", type=int, default=COMMON["item_num"])
    ap.add_argument("--exist-num", type=int, default=COMMON["exist_num"])
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--allow-rebuilt-binary", action="store_true",
                    help="accept a rebuilt executable and record its SHA-256 in the run manifest")
    args = ap.parse_args()
    if not args.out.is_absolute():
        args.out = ROOT / args.out
    if args.windows <= args.warmup + 3:
        ap.error("windows must leave at least three post-warmup windows")
    if args.window_sec != COMMON["window_sec"] or args.threads != COMMON["threads"]:
        ap.error("RQ2 must use the common RQ1 window duration and thread count")

    scheduler = ROOT / "examples/linverix_aidel_protocol.cc"
    binary = ROOT / "build/linverix_aidel_protocol"
    actual_source = sha256(scheduler)
    if actual_source != COMMON["scheduler_source_sha256"]:
        raise SystemExit(f"frozen scheduler source mismatch: {actual_source}")
    if not binary.is_file():
        raise SystemExit(f"frozen AIDEL binary is missing: {binary}")
    actual_binary = sha256(binary)
    if actual_binary != EXPECTED_AIDEL_SHA256 and not args.allow_rebuilt_binary:
        raise SystemExit(f"AIDEL binary differs from the recorded executable: {actual_binary}; pass --allow-rebuilt-binary to record a locally rebuilt binary")

    sample_root = Path(os.getenv("SOSD_SAMPLE_ROOT", "data/sosd_samples"))
    if not sample_root.is_absolute():
        sample_root = ROOT / sample_root
    source_value = os.getenv("BOOKS_SOURCE")
    source_data = Path(source_value) if source_value else None
    samples = {}
    for seed in args.seeds:
        sample = sample_root / "books" / f"books_{args.exist_num // 1000000}M_seed{seed}.uint64"
        if not sample.is_file() or sample.stat().st_size != 8 * args.exist_num:
            if source_data is None or not source_data.is_file():
                raise SystemExit(f"missing Books sample {sample}; set BOOKS_SOURCE to the SOSD Books file")
            subprocess.run(["bash", str(ROOT / "scripts/prepare_sosd_samples.sh"), str(source_data), "books",
                            str(sample.parent), str(args.exist_num), *map(str, args.seeds)], cwd=ROOT, check=True)
        samples[str(seed)] = {"path": sample.relative_to(sample_root).as_posix(), "sha256": sha256(sample)}

    modes = {
        "continuous": {"interval_sec": args.window_sec, "injections_per_window": True},
        "spaced": {"interval_sec": 3 * args.window_sec, "injections_per_window": False},
    }
    manifest = {
        "experiment": "RQ2_recovery_dynamics",
        "source_reference": "Experiment artifact runner uses DRIFT_INTERVAL_SEC=2 and 6",
        "varied_factor": "injection cadence only",
        "modes": modes,
        "protocol_id": PROTOCOL["protocol_id"],
        "common_settings": COMMON,
        "rq2_policy": "LinVeriX only; no cross-policy comparison or superiority claim",
        "injection_starts_after_clean_warmup": True,
        "recovery_window_observation": "post-injection windows until next scheduled shock; last event right-censored at run end",
        "reported_metrics": ["per-window post-repair Top-K residual", "per-window measured P99 as a secondary service trajectory", "per-event B-repair oracle target attainment", "full residual recovery to <=0.01 us", "P99 first return to <=105% of clean warmup baseline", "right-censored events"],
        "p99_metric": "shown alongside residual as a secondary LinVeriX-only service trajectory; it does not define the primary residual-recovery pass gate, and no universal P99-recovery claim is made",
        "windows": args.windows,
        "window_sec": args.window_sec,
        "warmup_windows": args.warmup,
        "seeds": args.seeds,
        "segments": COMMON["segments"],
        "budget_B": COMMON["budget_B"],
        "top_k": COMMON["top_k"],
        "threads": args.threads,
        "item_num": args.item_num,
        "exist_num": args.exist_num,
        "scheduler_source_sha256": actual_source,
        "aidel_binary_sha256": actual_binary,
        "samples": samples,
        "drift_shock": "fresh homogeneous K-segment recovery pulse: DRIFT_NO_ACCUM clears prior synthetic drift at each injection, then adds 250000 ns to a seed-shuffled cohort of K=6 segments",
        "note": "RQ2 follows the paper's continuous-versus-spaced LinVeriX residual-recovery objective. Its K-segment pulse is a recovery stimulus, not the RQ1 heterogeneous workload. The scheduler binary, AIDEL backend, budget, segment count, workload, and all other common settings remain frozen; only pulse cadence varies."
    }
    jobs = [(mode, seed) for seed in args.seeds for mode in ("continuous", "spaced")]
    if args.dry_run:
        for mode, seed in jobs:
            print(f"{mode} seed={seed} cadence={modes[mode]['interval_sec']}s, {args.windows} windows")
        return

    manifest_path = args.out / "manifest.json"
    if args.out.exists():
        if not manifest_path.is_file() or json.loads(manifest_path.read_text(encoding="utf-8")) != manifest:
            raise SystemExit(f"output exists with a different or missing manifest; choose a new --out: {args.out}")
    else:
        args.out.mkdir(parents=True)
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    for index, (mode, seed) in enumerate(jobs, 1):
        sample = sample_root / samples[str(seed)]["path"]
        destination = args.out / "rq2" / f"recovery_{mode}_s{seed}.csv"
        destination.parent.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        for key in ("LINUCB_PHASE1_MAX_B", "NO_PHASE2", "LINUCB_PHASE2_REWARD_WEIGHT",
                    "LINUCB_PHASE2_MAX_TARGETS", "RQ5_FAULT", "DRIFT_SIGNAL_MODE"):
            env.pop(key, None)
        sample_arg = runtime_path(sample)
        env.update(
            SOSD_SAMPLE_FILE=sample_arg, SOSD_DATASET="books",
            DRIFT_INTERVAL_SEC=str(modes[mode]["interval_sec"]),
            DRIFT_WARMUP_SEC=str(args.window_sec * args.warmup),
            DRIFT_K=str(COMMON["top_k"]),
            DRIFT_LAT_NS_PER_SEG=str(COMMON["drift"]["increment_ns_per_segment"]),
            DRIFT_WARMUP_WINDOWS=str(args.warmup), DRIFT_NO_ACCUM="1",
            DRIFT_HETERO="0", SIMULATED_DRIFT_WAIT="1",
            DRIFT_CAP_NS=str(COMMON["drift"]["cap_ns_per_segment"]),
            DRIFT_PREDICTION_BIAS_KEYS="0", DRIFT_PREDICTION_BIAS_CAP_KEYS="0",
            MIN_EXTRA_NS_FOR_RETRAIN="1", SEGMENT_COUNT=str(COMMON["segments"]),
            PERIODIC_EVERY_WINDOWS="1", MEASURED_FEEDBACK="0",
            LINUCB_PHASE1_RHO_SCALE=str(COMMON["linverix"]["phase1_rho_scale"]),
            LINUCB_PHASE1_STARVATION_WINDOWS=str(COMMON["linverix"]["phase1_starvation_windows"]),
            LINUCB_PHASE1_MAX_B=str(COMMON["budget_B"]), THRESHOLD_DRIFT_US="250")
        env.pop("DRIFT_TEMPORAL_HETERO", None)
        command = [str(binary), "--policy=linucb", f"--budget_B={COMMON['budget_B']}",
                   f"--win_sec={args.window_sec}", f"--runtime={args.windows * args.window_sec}",
                   f"--thread_num={args.threads}", "--benchmark=13", f"--item_num={args.item_num}",
                   f"--exist_num={args.exist_num}", f"--seed={seed}", "--verify_layer=hash",
                   "--proof_rate=0", f"--csv_log={runtime_path(destination)}"]
        log = destination.with_suffix(".log")
        print(f"[{index}/{len(jobs)}] RQ2 {mode} seed={seed}: cadence {modes[mode]['interval_sec']}s", flush=True)
        with log.open("w", encoding="utf-8") as stream:
            subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT, check=True)
        subprocess.run(["python3", str(ROOT / "scripts/validate_formal_runs.py"), str(destination),
                        "--windows", str(args.windows)], cwd=ROOT,
                       env={**env, "EXPECTED_WINDOWS": str(args.windows)}, check=True)

    subprocess.run(["python3", str(ROOT / "scripts/summarize_rq2_original_design.py"), str(args.out),
                    "--warmup", str(args.warmup), "--window-sec", str(args.window_sec)], cwd=ROOT, check=True)
    gate_command = ["python3", str(ROOT / "scripts/gate_rq2_recovery.py"), str(args.out)]
    if (args.windows == COMMON["windows"] and args.warmup == COMMON["warmup_windows"]
            and args.seeds == COMMON["seeds"]):
        gate_command.append("--formal")
    subprocess.run(gate_command, cwd=ROOT, check=True)
    subprocess.run(["python3", str(ROOT / "scripts/plot_rq2_recovery_dynamics.py"), str(args.out)], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
