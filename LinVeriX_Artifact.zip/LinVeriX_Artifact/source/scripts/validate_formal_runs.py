#!/usr/bin/env python3
"""Validate a run produced by the shared formal experiment protocol."""
import argparse, csv, math
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("csv", type=Path)
ap.add_argument("--windows", type=int, required=True)
a = ap.parse_args()
required = {"window_id", "p99_after_ms", "tput_after", "retrain_cost_ms_sum",
            "retrain_exec_cnt", "topk_sum_post_phase2_us", "peak_topk_sum_us",
            "budget_B", "budget_used", "usedB_phase1", "usedB_phase2"}
with a.csv.open(newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    missing = required - set(reader.fieldnames or ())
    if missing:
        raise SystemExit(f"{a.csv} missing columns: {sorted(missing)}")
    rows = list(reader)
if len(rows) != a.windows:
    raise SystemExit(f"{a.csv} has {len(rows)} rows, expected {a.windows}")
ids = [int(float(r["window_id"])) for r in rows]
if ids != list(range(1, a.windows + 1)):
    raise SystemExit(f"{a.csv} has invalid window IDs")
for row in rows:
    for col in required - {"window_id"}:
        value = float(row[col])
        if not math.isfinite(value):
            raise SystemExit(f"{a.csv} has non-finite {col}")
    budget = int(float(row["budget_B"]))
    used = int(float(row["budget_used"]))
    phase1 = int(float(row["usedB_phase1"]))
    phase2 = int(float(row["usedB_phase2"]))
    executed = int(float(row["retrain_exec_cnt"]))
    if used > budget:
        raise SystemExit(f"{a.csv} window {row['window_id']} exceeds budget: {used}>{budget}")
    if used != phase1 + phase2:
        raise SystemExit(f"{a.csv} window {row['window_id']} phase ledger mismatch: {used}!={phase1}+{phase2}")
    if used != executed:
        raise SystemExit(f"{a.csv} window {row['window_id']} execution mismatch: {used}!={executed}")
print(f"[PASS] validated RQ6-protocol CSV with {len(rows)} windows: {a.csv}")
