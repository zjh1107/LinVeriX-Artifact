#!/usr/bin/env python3
"""Create continuous-window and spaced-event LinVeriX recovery curves."""
import argparse
import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path
from xml.sax.saxutils import escape


T95 = {2: 12.706, 3: 4.303, 4: 3.182, 5: 2.776, 6: 2.571,
       7: 2.447, 8: 2.365, 9: 2.306, 10: 2.262}
COLORS = {"residual": "#d55e00", "p99_us": "#0072b2", "p99_ratio_pct": "#0072b2"}


def mean_ci(values):
    mean = statistics.fmean(values)
    if len(values) < 2:
        return mean, 0.0
    half = T95.get(len(values), 1.96) * statistics.stdev(values) / math.sqrt(len(values))
    return mean, half


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("root", type=Path)
    args = ap.parse_args()
    path = args.root / "rq2_paper_target_trajectory.csv"
    if not path.is_file():
        raise SystemExit(f"missing LinVeriX recovery trajectory: {path}")
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))

    first_window = {}
    p99_baseline_by_seed = {}
    for row in rows:
        p99_baseline_by_seed[row["seed"]] = float(row["p99_baseline_ms"]) * 1000.0
        if row["mode"] == "continuous":
            first_window[row["seed"]] = min(first_window.get(row["seed"], int(row["window_id"])),
                                             int(row["window_id"]))

    per_seed = defaultdict(lambda: {"residual": [], "p99_us": [], "p99_ratio_pct": []})
    event_keys = defaultdict(set)
    for row in rows:
        mode, seed = row["mode"], row["seed"]
        offset = (int(row["window_id"]) - first_window[seed]
                  if mode == "continuous" else int(row["windows_after_injection"]))
        key = (mode, seed, offset)
        per_seed[key]["residual"].append(float(row["topk_residual_us"]))
        p99_us = float(row["p99_after_ms"]) * 1000.0
        baseline_us = float(row["p99_baseline_ms"]) * 1000.0
        per_seed[key]["p99_us"].append(p99_us)
        per_seed[key]["p99_ratio_pct"].append(100.0 * p99_us / baseline_us)
        event_keys[(mode, offset)].add((seed, row["event"]))

    series = {metric: defaultdict(dict) for metric in ("residual", "p99_us", "p99_ratio_pct")}
    for (mode, seed, offset), values in sorted(per_seed.items()):
        for metric in ("residual", "p99_us", "p99_ratio_pct"):
            series[metric][mode].setdefault(offset, []).append(statistics.fmean(values[metric]))

    summary = []
    for metric in ("residual", "p99_us", "p99_ratio_pct"):
        for mode in ("continuous", "spaced"):
            for offset, seed_values in sorted(series[metric][mode].items()):
                mean, ci = mean_ci(seed_values)
                summary.append({"metric": metric, "mode": mode, "window_position": offset,
                                "position_definition": "successive_injection_windows" if mode == "continuous" else "windows_after_injection",
                                "seed_count": len(seed_values), "event_count": len(event_keys[(mode, offset)]),
                                "mean_across_seed_means": mean, "ci95_halfwidth": ci})
    summary_path = args.root / "rq2_paper_target_figure_summary.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)

    # Use the original per-window logs for the figure. Event-relative trajectory
    # summaries contain only three points per shock and are not the full run.
    window_per_seed = defaultdict(dict)
    for run_path in sorted((args.root / "rq2").glob("recovery_*_s*.csv")):
        parts = run_path.stem.split("_")
        mode = parts[1]
        seed = parts[2][1:]
        with run_path.open(newline="", encoding="utf-8") as stream:
            run_rows = list(csv.DictReader(stream))
        eval_rows = [row for row in run_rows if int(row["window_id"]) > 10]
        clean_rows = [row for row in run_rows if int(row["window_id"]) <= 10
                      and float(row["p99_after_ms"]) > 0.0]
        if not eval_rows:
            continue
        if not clean_rows:
            raise SystemExit(f"no warmup P99 baseline in {run_path}")
        baseline_us = statistics.fmean(float(row["p99_after_ms"]) for row in clean_rows) * 1000.0
        first_eval = min(int(row["window_id"]) for row in eval_rows)
        for row in eval_rows:
            position = int(row["window_id"]) - first_eval
            p99_us = float(row["p99_after_ms"]) * 1000.0
            window_per_seed[(mode, seed, position)] = {
                "residual": float(row["topk_sum_post_phase2_us"]),
                "p99_ratio_pct": 100.0 * p99_us / baseline_us,
                "p99_us": p99_us,
            }

    window_series = {metric: defaultdict(dict) for metric in ("residual", "p99_ratio_pct", "p99_us")}
    for (mode, seed, position), values in sorted(window_per_seed.items()):
        for metric in window_series:
            window_series[metric][mode].setdefault(position, []).append(values[metric])
    window_summary = []
    for metric in window_series:
        for mode in ("continuous", "spaced"):
            for position, seed_values in sorted(window_series[metric][mode].items()):
                mean, ci = mean_ci(seed_values)
                window_summary.append({"metric": metric, "mode": mode, "window_position": position,
                                       "time_after_warmup_s": position * 2, "seed_count": len(seed_values),
                                       "mean_across_seed_values": mean, "ci95_halfwidth": ci})
    window_summary_path = args.root / "rq2_window_figure_summary.csv"
    with window_summary_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(window_summary[0]))
        writer.writeheader()
        writer.writerows(window_summary)

    width, height = 1480, 760
    left, right, top = 102, 58, 190
    panel_h = 420
    gap = 115
    panel_w = (width - left - right - gap) / 2
    display_last_position = 15  # Continuous drift: first 30 measured seconds.
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
           '<rect width="100%" height="100%" fill="white"/>',
           '<style>text{font-family:Arial,Helvetica,sans-serif;fill:#1f2937}.axis{stroke:#475569;stroke-width:1.3}.grid{stroke:#e8edf2;stroke-width:1}.series{stroke-width:2.5;stroke-linejoin:round;stroke-linecap:round}</style>',
           f'<text x="{width/2}" y="35" text-anchor="middle" font-size="24" font-weight="bold">LinVeriX recovery under two drift schedules</text>',
           f'<text x="{width/2}" y="63" text-anchor="middle" font-size="14" fill="#52606d">Books · 5 seeds · 256 segments · B=2 · 300 windows (10 warmup + 290 measured) · 2 s/window</text>']
    # Metric color is consistent across the two drift panels.
    legend_y = 103
    for lx, color, label in ((width/2-190, "#0072b2", "Top-6 residual (μs)"),
                             (width/2+35, "#e68613", "Foreground P99 latency (μs)")):
        out.append(f'<line x1="{lx}" y1="{legend_y}" x2="{lx+40}" y2="{legend_y}" stroke="{color}" stroke-width="3"/>')
        out.append(f'<text x="{lx+50}" y="{legend_y+5}" font-size="13">{label}</text>')
    out.append(f'<text x="{width/2}" y="133" text-anchor="middle" font-size="12" fill="#555">Left: first 30 s of continuous drift. Right: average of spaced-drift events aligned at injection. Lower values are better.</text>')

    ymax = 1150.0
    yticks = [(0.0, "0"), (250.0, "250"), (500.0, "500"), (750.0, "750"), (1000.0, "1000")]
    for col, mode, title in ((0, "continuous", "Continuous drift · shock every 2 s"),
                             (1, "spaced", "Spaced drift · shock every 6 s")):
        x0 = left + col * (panel_w + gap)
        y0 = top
        x1, y1 = x0 + panel_w, y0 + panel_h
        last_position = display_last_position if mode == "continuous" else max(series["residual"][mode])
        xscale = lambda v: x0 + panel_w * v / last_position
        yscale = lambda v: y1 - panel_h * v / ymax
        out.append(f'<text x="{x0+panel_w/2}" y="{y0-25}" text-anchor="middle" font-size="16" font-weight="bold">{title}</text>')
        for value, label in yticks:
            py = yscale(value)
            out.append(f'<line class="grid" x1="{x0}" y1="{py:.1f}" x2="{x1}" y2="{py:.1f}"/>')
            out.append(f'<text x="{x0-12}" y="{py+5:.1f}" text-anchor="end" font-size="12">{label}</text>')
        x_ticks = [0, 3, 6, 9, 12, display_last_position] if mode == "continuous" else [0, 1, 2]
        for pos in x_ticks:
            px = xscale(pos)
            out.append(f'<line class="grid" x1="{px:.1f}" y1="{y0}" x2="{px:.1f}" y2="{y1}" stroke-opacity="0.35"/>')
            out.append(f'<text x="{px:.1f}" y="{y1+22}" text-anchor="middle" font-size="12">{pos*2}</text>')
        out.append(f'<defs><clipPath id="clip-{mode}"><rect x="{x0}" y="{y0}" width="{panel_w}" height="{panel_h}"/></clipPath></defs>')
        for metric, color in (("residual", "#0072b2"), ("p99_us", "#e68613")):
            points = []
            source = window_series[metric][mode] if mode == "continuous" else series[metric][mode]
            for pos, seed_values in sorted(source.items()):
                if mode == "continuous" and pos > display_last_position:
                    break
                mean, _ = mean_ci(seed_values)
                points.append((pos, mean))
            coords = " ".join(f"{xscale(pos):.1f},{yscale(value):.1f}" for pos, value in points)
            out.append(f'<polyline points="{coords}" fill="none" stroke="{color}" class="series" clip-path="url(#clip-{mode})"/>')
            for pos, value in points:
                out.append(f'<circle cx="{xscale(pos):.1f}" cy="{yscale(value):.1f}" r="2.2" fill="{color}" stroke="white" stroke-width="0.4" clip-path="url(#clip-{mode})"/>')
        out.append(f'<line class="axis" x1="{x0}" y1="{y0}" x2="{x0}" y2="{y1}"/>')
        out.append(f'<line class="axis" x1="{x0}" y1="{y1}" x2="{x1}" y2="{y1}"/>')
        x_label = "Time after warmup (s)" if mode == "continuous" else "Time after each injection (s)"
        out.append(f'<text x="{x0+panel_w/2}" y="{y1+47}" text-anchor="middle" font-size="12">{x_label}</text>')
    out.append(f'<text x="{width/2}" y="{height-20}" text-anchor="middle" font-size="12" fill="#555">Blue: post-maintenance Top-6 residual. Orange: foreground P99 latency. Full window data and event averages are retained in the companion CSVs.</text>')
    out.append('</svg>')
    output = args.root / "rq2_recovery_event_aligned.svg"
    svg_text = "\n".join(out)
    output.write_text(svg_text, encoding="utf-8")
    (args.root / "rq2_linverix_recovery.svg").write_text(svg_text, encoding="utf-8")
    print(f"Wrote two-panel LinVeriX residual/P99 recovery figure: {output}")
    print(f"Wrote event-relative summary: {summary_path}")
    print(f"Wrote per-window figure data: {window_summary_path}")


if __name__ == "__main__":
    main()
