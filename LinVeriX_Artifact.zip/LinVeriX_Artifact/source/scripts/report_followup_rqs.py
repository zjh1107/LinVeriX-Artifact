#!/usr/bin/env python3
"""Summarize RQ2--RQ6 from the original RQ1 benchmark CSV schema."""
import argparse
import csv
import json
import math
import re
import statistics
from collections import defaultdict
from pathlib import Path

def mean(values):return statistics.fmean(values) if values else 0.0

def write(path,rows):
    if not rows:raise ValueError(f'no rows: {path}')
    with path.open('w',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def report(root,warmup):
    manifest=json.loads((root/'manifest.json').read_text(encoding='utf8'))
    window_sec=float(manifest['window_sec'])
    records=[]
    for file in sorted(root.glob('rq*/*_s*.csv')):
        match=re.fullmatch(r'(.+)_s(\d+)\.csv',file.name)
        if not match:continue
        name,seed=match.group(1),int(match.group(2))
        with file.open(newline='',encoding='utf8') as f:rows=list(csv.DictReader(f))
        if len(rows)<=warmup:raise ValueError(f'no active windows: {file}')
        for row in rows:
            for key in ('p99_after_ms','topk_sum_post_phase2_cmp_per_query','topk_sum_post_injection_cmp_per_query','retrain_cost_ms_sum'):
                if not math.isfinite(float(row[key])):raise ValueError(f'{file}: invalid {key}')
        records.append((file.parent.name,name,seed,rows))
    if not records:raise ValueError(f'no valid CSVs: {root}')
    references=defaultdict(list)
    for rq,name,seed,rows in records:
        # RQ2's two scenarios have distinct injection profiles.  Each policy
        # group shares one warm-up reference for the same seed and scenario.
        scenario=name.split('_')[0] if rq=='rq2' else 'common'
        references[(rq,seed,scenario)].extend(float(r['p99_after_ms']) for r in rows[:warmup] if float(r['p99_after_ms'])>0)
    per_seed=[]
    for rq,name,seed,rows in records:
        scenario=name.split('_')[0] if rq=='rq2' else 'common'
        baseline=mean(references[(rq,seed,scenario)])
        if baseline<=0:raise ValueError(f'no warm-up baseline: {rq} {seed}')
        active=rows[warmup:]
        for counter in ('routed_reads_total','fallback_reads_total','checked_reads_total','invalidated_models_total','rejected_publications_total','actual_writes_total'):
            if counter not in rows[-1]:raise ValueError(f'{file}: missing foreground routing counter {counter}')
        def delta(counter):return int(rows[-1][counter])-int(rows[warmup-1][counter])
        rates=[]
        if rq=='rq2':
            # Drift is injected after the window's maintenance decision, so
            # measure its residual effect after the first subsequent repair.
            # Comparing values within the injection row falsely reports 0%.
            for index,row in enumerate(active):
                peak=float(row['topk_sum_post_injection_cmp_per_query'])
                if int(float(row.get('injection_flag',0)))!=1 or peak<=0:
                    continue
                repaired=next((candidate for candidate in active[index+1:]
                               if int(float(candidate.get('retrain_exec_cnt',0)))>0),None)
                if repaired is not None:
                    rates.append(1-float(repaired['topk_sum_post_phase2_cmp_per_query'])/peak)
        per_seed.append(dict(rq=rq,case=name,seed=seed,active_windows=len(active),
            shared_warmup_p99_ms=baseline,
            mean_p99_us=1000*mean([float(r['p99_after_ms']) for r in active]),
            p99_degradation_auc_s=sum(max(0,float(r['p99_after_ms'])/baseline-1)*window_sec for r in active),
            topk_residual_cmp_per_query=mean([float(r['topk_sum_post_phase2_cmp_per_query']) for r in active]),
            injection_window_residual_reduction=mean(rates) if rq=='rq2' and rates else float('nan'),
            maintenance_ms=sum(float(r['retrain_cost_ms_sum']) for r in active),
            retrains=sum(float(r['retrain_exec_cnt']) for r in active),
            proof_samples=sum(float(r['proof_samples']) for r in active),
            proof_failures=sum(float(r['proof_failures']) for r in active)))
        per_seed[-1].update(routed_reads=delta('routed_reads_total'),
            fallback_reads=delta('fallback_reads_total'),checked_reads=delta('checked_reads_total'),
            invalidated_models=delta('invalidated_models_total'),
            rejected_publications=delta('rejected_publications_total'),
            actual_writes=delta('actual_writes_total'))
    write(root/'per_seed.csv',per_seed)
    groups=defaultdict(list)
    for row in per_seed:groups[(row['rq'],row['case'])].append(row)
    aggregate=[]
    for (rq,case),group in sorted(groups.items()):
        result={'rq':rq,'case':case,'seeds':len({r['seed'] for r in group})}
        for key in ('mean_p99_us','p99_degradation_auc_s','topk_residual_cmp_per_query','injection_window_residual_reduction','maintenance_ms','retrains','proof_samples','proof_failures','routed_reads','fallback_reads','checked_reads','invalidated_models','rejected_publications','actual_writes'):
            values=[r[key] for r in group]
            result[key+'_mean']=mean(values)
            result[key+'_sd']=(statistics.stdev(values)
                               if len(values)>1 and all(math.isfinite(v) for v in values)
                               else float('nan'))
        aggregate.append(result)
    write(root/'aggregate.csv',aggregate)
    for row in aggregate:
        print(f"{row['rq']:3s} {row['case']:25s} P99={row['mean_p99_us_mean']:.3f} us "
              f"AUC={row['p99_degradation_auc_s_mean']:.4f} s "
              f"residual={row['topk_residual_cmp_per_query_mean']:.4f} comparisons/query "
              f"inj-reduction={'n/a' if math.isnan(row['injection_window_residual_reduction_mean']) else format(row['injection_window_residual_reduction_mean'], '.1%')} "
              f"maint={row['maintenance_ms_mean']:.2f} ms "
              f"routed={row['routed_reads_mean']:.0f} writes={row['actual_writes_mean']:.0f}")
    print('Wrote',root/'aggregate.csv')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    parser.add_argument('--warmup',type=int,default=20)
    args=parser.parse_args()
    report(args.root,args.warmup)
