#!/usr/bin/env python3
import csv
import glob
import math
import os
import sys


def fail(message):
    raise SystemExit(f"[FAIL] {message}")


root = sys.argv[1] if len(sys.argv) > 1 else "runs/rq6_real"
expected_windows = int(os.environ.get("EXPECTED_WINDOWS", "0"))
if os.path.isfile(root):
    files = [root]
else:
    files = sorted(glob.glob(os.path.join(root, "**", "*_s*.csv"), recursive=True))
if not files:
    fail(f"no CSV files found under {root}")

required = {
    "window_id", "baseline_tag", "budget_B", "budget_used",
    "retrain_cost_ms_sum", "retrain_exec_cnt", "p99_after_ms",
    "topk_sum_post_injection_cmp_per_query", "topk_sum_post_phase2_cmp_per_query",
    "root_correction_steps_per_routed_query", "prediction_bias_max_keys",
}

for path in files:
    with open(path, newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    if not rows:
        fail(f"{path} has no data rows")
    if expected_windows and len(rows) != expected_windows:
        fail(f"{path} has {len(rows)} windows; expected {expected_windows}")
    window_ids = [int(float(r.get("window_id", 0))) for r in rows]
    if window_ids != list(range(1, len(rows) + 1)):
        fail(f"{path} window_id values are not contiguous from 1")
    missing = required - set(rows[0])
    if missing:
        fail(f"{path} is missing columns: {sorted(missing)}")

    positive_p99 = False
    total_executed = 0
    for row in rows:
        budget = int(float(row["budget_B"]))
        used = int(float(row["budget_used"]))
        executed = int(float(row["retrain_exec_cnt"]))
        total_executed += executed
        cost = float(row["retrain_cost_ms_sum"])
        p99 = float(row["p99_after_ms"])
        post = float(row["topk_sum_post_phase2_cmp_per_query"])
        injected = float(row["topk_sum_post_injection_cmp_per_query"])
        correction_steps = float(row["root_correction_steps_per_routed_query"])
        prediction_bias = float(row["prediction_bias_max_keys"])

        if used > budget:
            fail(f"{path} window {row['window_id']} exceeds budget: {used}>{budget}")
        if executed > budget:
            fail(f"{path} window {row['window_id']} executes {executed}>{budget} retrains")
        if executed > 0 and not (math.isfinite(cost) and cost > 0):
            fail(f"{path} window {row['window_id']} reports retraining without measured cost")
        if post < -1e-9 or injected < -1e-9:
            fail(f"{path} window {row['window_id']} has negative residual")
        if not math.isfinite(correction_steps) or correction_steps < 0:
            fail(f"{path} window {row['window_id']} has invalid correction-work telemetry")
        if not math.isfinite(prediction_bias) or prediction_bias < 0:
            fail(f"{path} window {row['window_id']} has invalid prediction-bias telemetry")
        positive_p99 = positive_p99 or p99 > 0

    if not positive_p99:
        fail(f"{path} has no measured p99 latency")

    stem = os.path.basename(path).lower()
    no_retrain_expected = "naive" in stem
    opportunistic = any(tag in stem for tag in ("periodic", "threshold"))
    if "naive" in stem and total_executed != 0:
        fail(f"{path} is a no-retraining baseline but executed {total_executed} retrains")
    if not no_retrain_expected and not opportunistic and total_executed == 0:
        fail(f"{path} should exercise real retraining but executed none")
    if "periodic" in stem and total_executed == 0:
        fail(f"{path} uses per-window age-based Periodic but executed no maintenance")

print(f"[PASS] validated {len(files)} files")
