#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
bin="$root/build/linverix_aidel_protocol"
if [[ ! -x "$bin" ]]; then
  echo "Build first: bash build.sh && bash scripts/build_rq1_protocol.sh" >&2
  exit 2
fi
windows="${WINDOWS:-300}"
warmup="${WARMUP_WINDOWS:-10}"
seeds="${SEEDS:-113 114 115 116 117}"
datasets="${DATASETS:-books facebook wiki}"
sample_root="${SOSD_SAMPLE_ROOT:-data/sosd_samples}"
run_root="${RUN_ROOT:-runs/rq1_formal}"
result_root="${RESULT_ROOT:-results/rq1_formal}"
mkdir -p "$run_root" "$result_root"

export DRIFT_INTERVAL_SEC=2
export DRIFT_WARMUP_SEC=$((warmup * 2))
export DRIFT_WARMUP_WINDOWS="$warmup"
export DRIFT_K=6 DRIFT_LAT_NS_PER_SEG=250000 DRIFT_TEMPORAL_HETERO=1
export DRIFT_CAP_NS=2000000 DRIFT_NO_ACCUM=1 SIMULATED_DRIFT_WAIT=1
export DRIFT_PREDICTION_BIAS_KEYS=0 DRIFT_PREDICTION_BIAS_CAP_KEYS=0
export MEASURED_FEEDBACK=0 SEGMENT_COUNT=256 PERIODIC_EVERY_WINDOWS=1
export THRESHOLD_DRIFT_US=250 MIN_EXTRA_NS_FOR_RETRAIN=1
export LINUCB_PHASE1_RHO_SCALE=0.25 LINUCB_PHASE1_STARVATION_WINDOWS=8
unset DRIFT_SIGNAL_MODE

for dataset in $datasets; do
  mkdir -p "$run_root/$dataset" "$result_root/$dataset"
  for seed in $seeds; do
    sample="$sample_root/$dataset/${dataset}_1M_seed${seed}.uint64"
    [[ -s "$sample" ]] || { echo "Missing sample: $sample" >&2; exit 2; }
    # Alternate order across seeds to limit temperature/order confounding.
    if (( seed % 2 == 0 )); then
      matrix=("periodic|periodic|--periodic" "threshold|linucb|--threshold" "greedy|linucb|--greedy" "linverix|linucb|")
    else
      matrix=("linverix|linucb|" "greedy|linucb|--greedy" "threshold|linucb|--threshold" "periodic|periodic|--periodic")
    fi
    for item in "${matrix[@]}"; do
      IFS='|' read -r name policy flag <<< "$item"
      csv="$run_root/$dataset/${name}_s${seed}.csv"
      log="$run_root/$dataset/${name}_s${seed}.log"
      if [[ -s "$csv" ]]; then
        python3 scripts/validate_formal_runs.py "$csv" --windows "$windows" >/dev/null
        echo "[SKIP] $dataset $name $seed"
        continue
      fi
      echo "[RUN] $dataset $name seed=$seed"
      SOSD_SAMPLE_FILE="$sample" SOSD_DATASET="$dataset" \
        "$bin" ${flag:+$flag} --policy="$policy" --budget_B=2 \
        --win_sec=2 --runtime="$((windows * 2))" --thread_num=8 \
        --benchmark=13 --item_num=2000000 --exist_num=1000000 \
        --seed="$seed" --verify_layer=hash --proof_rate=0 \
        --csv_log="$csv" >"$log" 2>&1
      python3 scripts/validate_formal_runs.py "$csv" --windows "$windows"
    done
  done
  python3 scripts/summarize_formal_runs.py "$run_root" "$result_root/$dataset" \
    --dataset "$dataset" --warmup-windows "$warmup" --window-sec 2
done
