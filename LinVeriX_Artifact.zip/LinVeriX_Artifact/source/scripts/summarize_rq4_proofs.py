#!/usr/bin/env python3
"""Summarize RQ4 sampled-proof coverage, overhead, and injected-fault detection."""
import argparse
import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def mean(values):
    return statistics.fmean(values) if values else math.nan


def write_csv(path, rows):
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--warmup", type=int, default=10)
    args = parser.parse_args()
    files = sorted((args.root / "rq4").glob("*_s*.csv"))
    if not files:
        raise SystemExit(f"no RQ4 proof runs under {args.root / 'rq4'}")

    sampling, faults = defaultdict(list), defaultdict(list)
    for path in files:
        stem = path.stem
        rows = read_csv(path)
        if len(rows) <= args.warmup:
            raise SystemExit(f"not enough windows in {path}")
        if stem.startswith("proof_r"):
            rate = int(stem.split("_s", 1)[0].removeprefix("proof_r"))
            sampling[rate].append((path, rows))
        elif stem.startswith("fault_"):
            name, seed_text = stem.rsplit("_s", 1)
            _, fault, rate_text = name.split("_")
            faults[(int(rate_text.removeprefix("r")), fault)].append((path, rows, int(seed_text)))
        else:
            raise SystemExit(f"unrecognized RQ4 result name: {path.name}")

    expected_rates = {0, 5, 10, 25}
    if set(sampling) != expected_rates:
        raise SystemExit(f"sampling-rate cases are {sorted(sampling)}, expected {sorted(expected_rates)}")
    expected_faults = {(rate, fault) for rate in (10, 25)
                       for fault in ("omission", "modification", "replay")}
    if set(faults) != expected_faults:
        raise SystemExit(f"fault cases missing or extra: {sorted(set(faults) ^ expected_faults)}")

    sample_summary = []
    for rate in sorted(sampling):
        case_rows = [row for _, rows in sampling[rate] for row in rows]
        sample_count = sum(int(float(row["proof_samples"])) for row in case_rows)
        opportunities = len(case_rows)
        weighted_gen = sum(float(row["proof_gen_avg_us"]) * int(float(row["proof_samples"]))
                           for row in case_rows)
        weighted_ver = sum(float(row["proof_ver_avg_us"]) * int(float(row["proof_samples"]))
                           for row in case_rows)
        clean_failures = sum(int(float(row["proof_failures"])) for row in case_rows)
        false_positives = sum(int(float(row["false_positives"])) for row in case_rows)
        active = [row for _, rows in sampling[rate] for row in rows[args.warmup:]]
        residual_key = ("topk_sum_post_phase2_cmp_per_query"
                        if "topk_sum_post_phase2_cmp_per_query" in active[0]
                        else "topk_sum_post_phase2_us")
        record = {
            "proof_rate_percent": rate,
            "seeds": len(sampling[rate]),
            "window_opportunities": opportunities,
            "sampled_proofs": sample_count,
            "observed_sample_rate": sample_count / opportunities if opportunities else 0.0,
            "proof_generation_us_per_proof": weighted_gen / sample_count if sample_count else 0.0,
            "proof_verification_us_per_proof": weighted_ver / sample_count if sample_count else 0.0,
            "proof_failures": clean_failures,
            "false_positives": false_positives,
            "mean_p99_us": 1000.0 * mean([float(row["p99_after_ms"]) for row in active]),
            "mean_throughput": mean([float(row["tput_after"]) for row in active]),
            "mean_topk_residual": mean([float(row[residual_key]) for row in active]),
            "residual_unit": "comparisons/query" if "cmp_per_query" in residual_key else "us",
        }
        if rate > 0 and sample_count == 0:
            raise SystemExit(f"no proofs sampled at configured rate {rate}%")
        if clean_failures or false_positives:
            raise SystemExit(f"clean proof run has failures at rate {rate}%")
        sample_summary.append(record)

    fault_summary = []
    for (rate, fault), runs in sorted(faults.items()):
        attempts = sum(int(float(row["fault_attempts"])) for _, rows, _ in runs for row in rows)
        detected = sum(int(float(row["fault_detected"])) for _, rows, _ in runs for row in rows)
        false_positives = sum(int(float(row["false_positives"])) for _, rows, _ in runs for row in rows)
        proof_count = sum(int(float(row["proof_samples"])) for _, rows, _ in runs for row in rows)
        record = {"proof_rate_percent": rate, "fault_mode": fault, "seeds": len(runs),
                  "sampled_proofs": proof_count, "fault_attempts": attempts,
                  "faults_detected": detected,
                  "detection_rate": detected / attempts if attempts else 0.0,
                  "false_positives": false_positives}
        if attempts == 0 or detected != attempts:
            raise SystemExit(f"fault detection incomplete for {fault} at {rate}%: {detected}/{attempts}")
        if false_positives:
            raise SystemExit(f"false positive in {fault} run at {rate}%")
        fault_summary.append(record)

    write_csv(args.root / "rq4_proof_sampling.csv", sample_summary)
    write_csv(args.root / "rq4_fault_detection.csv", fault_summary)
    for row in sample_summary:
        print(f"RQ4 rate={row['proof_rate_percent']:2d}% proofs={row['sampled_proofs']} "
              f"gen={row['proof_generation_us_per_proof']:.3f}us "
              f"verify={row['proof_verification_us_per_proof']:.3f}us "
              f"clean_fp={row['false_positives']}")
    for row in fault_summary:
        print(f"RQ4 fault={row['fault_mode']} rate={row['proof_rate_percent']}% "
              f"detected={row['faults_detected']}/{row['fault_attempts']} "
              f"false_positive={row['false_positives']}")
    print(f"[PASS] RQ4 proof audit summaries written under {args.root}")


if __name__ == "__main__":
    main()
