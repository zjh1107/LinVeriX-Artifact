#!/usr/bin/env python3
"""Summarize LinVeriX-only residual and P99 recovery for continuous/spaced drift."""
import argparse
import csv
import math
import statistics
from pathlib import Path


def number(row, key, default=0.0):
    try:
        return float(row.get(key, default) or default)
    except (TypeError, ValueError):
        return default


def flag(row, key):
    return int(number(row, key)) == 1


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("root", type=Path)
    ap.add_argument("--warmup", type=int, default=10)
    ap.add_argument("--window-sec", type=float, default=2.0)
    ap.add_argument("--full-recovery-tol-us", type=float, default=0.01)
    ap.add_argument("--p99-limit-ratio", type=float, default=1.05)
    args = ap.parse_args()

    files = sorted((args.root / "rq2").glob("recovery_*_s*.csv"))
    if not files:
        raise SystemExit(f"no RQ2 CSVs under {args.root / 'rq2'}")
    trajectories, events = [], []

    for path in files:
        with path.open(newline="", encoding="utf-8") as stream:
            rows = list(csv.DictReader(stream))
        if len(rows) <= args.warmup:
            raise SystemExit(f"incomplete run: {path} has {len(rows)} windows")
        seed = path.stem.rsplit("_s", 1)[1]
        mode = path.stem[len("recovery_"):].rsplit("_s", 1)[0]
        injections = [i for i, row in enumerate(rows)
                      if flag(row, "injection_flag") or flag(row, "mid_inject_flag")
                      or flag(row, "late_inject_flag")]
        if not injections:
            raise SystemExit(f"no injection flags in {path}")
        baseline_samples = [number(row, "p99_after_ms") for row in rows[:args.warmup]
                            if number(row, "p99_after_ms") > 0]
        if not baseline_samples:
            raise SystemExit(f"no clean warmup P99 samples in {path}")
        p99_baseline = statistics.fmean(baseline_samples)
        p99_limit = p99_baseline * args.p99_limit_ratio

        for event_index, start in enumerate(injections):
            end = injections[event_index + 1] if event_index + 1 < len(injections) else len(rows)
            event_rows = rows[start:end]
            injection = rows[start]
            target = number(injection, "budget_oracle_topk_target_us", math.nan)
            if not math.isfinite(target):
                raise SystemExit(f"missing B-repair oracle target in {path}, window {injection.get('window_id')}")
            residuals = [number(row, "topk_sum_post_phase2_us") for row in event_rows]
            target_index = next((i for i, value in enumerate(residuals)
                                 if value <= target + 0.01), None)
            full_index = next((i for i, value in enumerate(residuals)
                               if value <= args.full_recovery_tol_us), None)
            p99_values = [number(row, "p99_after_ms") for row in event_rows]
            first_bad = next((i for i, value in enumerate(p99_values) if value > p99_limit), None)
            first_return = (next((i for i in range(first_bad, len(p99_values))
                                  if p99_values[i] <= p99_limit), None)
                           if first_bad is not None else None)

            if mode == "continuous":
                full_status = "not_recovered_before_next_injection" if full_index is None else "recovered"
                right_censored = 0
            elif full_index is not None:
                full_status, right_censored = "recovered", 0
            elif event_index + 1 < len(injections):
                full_status, right_censored = "not_recovered_before_next_injection", 0
            else:
                full_status, right_censored = "right_censored_at_run_end", 1

            injection_window = int(number(injection, "window_id"))
            for offset, row in enumerate(event_rows):
                p99_ms = number(row, "p99_after_ms")
                trajectories.append({
                    "policy": "LinVeriX", "mode": mode, "seed": seed,
                    "event": event_index + 1, "injection_window": injection_window,
                    "window_id": int(number(row, "window_id")),
                    "windows_after_injection": offset,
                    "topk_residual_us": number(row, "topk_sum_post_phase2_us"),
                    "budget_oracle_target_us": target,
                    "budget_target_reached": int(target_index is not None and offset >= target_index),
                    "full_recovery_reached": int(full_index is not None and offset >= full_index),
                    "p99_after_ms": p99_ms,
                    "p99_baseline_ms": p99_baseline,
                    "p99_percent_of_baseline": 100.0 * p99_ms / p99_baseline,
                    "p99_limit_percent": 100.0 * args.p99_limit_ratio,
                    "budget_used": int(number(row, "budget_used")),
                })

            events.append({
                "policy": "LinVeriX", "mode": mode, "seed": seed,
                "event": event_index + 1, "injection_window": injection_window,
                "observation_windows": len(event_rows),
                "post_repair_residual_in_injection_window_us": residuals[0],
                "post_repair_residual_at_observation_end_us": residuals[-1],
                "budget_oracle_target_us": target,
                "budget_target_reached": int(target_index is not None),
                "budget_target_windows": "" if target_index is None else target_index,
                "full_recovery_reached": int(full_index is not None),
                "full_recovery_windows": "" if full_index is None else full_index,
                "full_recovery_status": full_status,
                "full_recovery_right_censored": right_censored,
                "p99_baseline_ms": p99_baseline,
                "p99_limit_ms": p99_limit,
                "p99_degraded": int(first_bad is not None),
                "p99_first_return_windows_after_degradation": "" if first_return is None or first_bad is None else first_return - first_bad,
                "p99_first_return_sec_after_degradation": "" if first_return is None or first_bad is None else (first_return - first_bad) * args.window_sec,
            })

    outputs = (
        ("rq2_paper_target_events.csv", events),
        ("rq2_paper_target_trajectory.csv", trajectories),
    )
    for filename, data in outputs:
        with (args.root / filename).open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(data[0]))
            writer.writeheader()
            writer.writerows(data)

    summary_path = args.root / "rq2_paper_target_summary.csv"
    fields = ["policy", "mode", "events", "budget_target_rate",
              "full_recovery_reached_events", "full_recovery_right_censored_events",
              "full_recovery_rate_observable", "full_recovery_windows_mean",
              "p99_degraded_events", "p99_first_return_events",
              "p99_first_return_windows_mean"]
    with summary_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for mode in ("continuous", "spaced"):
            group = [event for event in events if event["mode"] == mode]
            observable = [event for event in group if event["full_recovery_status"] != "right_censored_at_run_end"]
            full = [int(event["full_recovery_windows"]) for event in observable
                    if event["full_recovery_reached"]]
            p99_returns = [float(event["p99_first_return_windows_after_degradation"])
                           for event in group if event["p99_first_return_windows_after_degradation"] != ""]
            writer.writerow({
                "policy": "LinVeriX", "mode": mode, "events": len(group),
                "budget_target_rate": statistics.fmean(int(event["budget_target_reached"]) for event in group),
                "full_recovery_reached_events": sum(int(event["full_recovery_reached"]) for event in group),
                "full_recovery_right_censored_events": sum(int(event["full_recovery_right_censored"]) for event in group),
                "full_recovery_rate_observable": (statistics.fmean(int(event["full_recovery_reached"]) for event in observable)
                                                  if mode == "spaced" and observable else "N/A"),
                "full_recovery_windows_mean": statistics.fmean(full) if full else "N/A",
                "p99_degraded_events": sum(int(event["p99_degraded"]) for event in group),
                "p99_first_return_events": len(p99_returns),
                "p99_first_return_windows_mean": statistics.fmean(p99_returns) if p99_returns else "N/A",
            })
    print(f"Wrote LinVeriX-only residual/P99 event and trajectory summaries under {args.root}")


if __name__ == "__main__":
    main()
