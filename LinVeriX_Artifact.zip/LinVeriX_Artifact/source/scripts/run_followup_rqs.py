#!/usr/bin/env python3
"""RQ2--RQ6 matrix using the scheduler from the RQ1 AIDEL source."""
import argparse
import csv
import json
import hashlib
import os
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PROTOCOL=json.loads((ROOT/'config/formal_experiment_protocol.json').read_text(encoding='utf8'))
COMMON=PROTOCOL['common']
POLICIES={'linverix':('linucb',[]),'greedy':('linucb',['--greedy']),
          'periodic':('periodic',['--periodic']),'threshold':('linucb',['--threshold'])}

def jobs_for(rq):
    if rq=='rq2':
        return [(f'recovery_{policy}',policy,2,'recovery',-1,[])
                for policy in POLICIES]
    if rq=='rq3':
        return [(name,'linverix',2,name,-1,[])
                for name in ('full','no_phase2','no_avoid','no_topk')]
    if rq=='rq4':
        # RQ4 adopts the paper's sampled-proof audit: clean runs at 0/5/10/25%,
        # plus omission/modification/replay injections at 10% and 25%.
        jobs=[(f'proof_r{int(rate*100)}','linverix',2,'clean',rate,[])
              for rate in (0.0,0.05,0.10,0.25)]
        jobs.extend((f'fault_{fault}_r{int(rate*100)}','linverix',2,fault,rate,[])
                    for rate in (0.10,0.25)
                    for fault in ('omission','modification','replay'))
        return jobs
    if rq=='rq5':
        return [(f'B{budget}','linverix',budget,'full',-1,[])
                for budget in (1,2,4,6)]
    if rq=='rq6':
        return [(policy,policy,2,'heterogeneous',-1,[]) for policy in POLICIES]
    raise ValueError(rq)

def load_rows(path):
    with path.open(newline='',encoding='utf8') as stream:
        return list(csv.DictReader(stream))

def runtime_path(path):
    resolved=path.resolve()
    try:return resolved.relative_to(ROOT).as_posix()
    except ValueError:return str(resolved)

def run(args):
    rq=args.rq
    scheduler_source=ROOT/'examples/linverix_aidel_protocol.cc'
    actual_scheduler_sha=hashlib.sha256(scheduler_source.read_bytes()).hexdigest()
    expected_scheduler_sha=COMMON['scheduler_source_sha256']
    if actual_scheduler_sha!=expected_scheduler_sha:
        raise ValueError(f"scheduler source differs from frozen formal protocol: {actual_scheduler_sha} != {expected_scheduler_sha}; do not mix results from different algorithm revisions")
    queue=[]
    for selected in (['rq2','rq3','rq4','rq5','rq6'] if rq=='all' else [rq]):
        jobs=jobs_for(selected)
        if selected in ('rq2','rq6'):
            # Counterbalance execution order across seeds. Running every
            # LinVeriX trial first and every Threshold trial last confounds
            # strategy with thermal/load drift on a single workstation.
            policy_order=['linverix','greedy','threshold','periodic']
            by_policy={job[1]:job for job in jobs}
            for seed_index,seed in enumerate(args.seeds):
                if len(args.seeds)==2 and seed_index==1:
                    rotated=list(reversed(policy_order))
                else:
                    rotation=seed_index % len(policy_order)
                    rotated=policy_order[rotation:]+policy_order[:rotation]
                for policy in rotated:
                    name,job_policy,budget,scenario,rate,flags=by_policy[policy]
                    queue.append((selected,name,job_policy,budget,scenario,rate,flags,seed))
        elif selected=='rq3':
            # Counterbalance ablation variants across seeds so a variant is
            # not systematically measured at the same point in machine load.
            names=[job[0] for job in jobs]
            by_name={job[0]:job for job in jobs}
            for seed_index,seed in enumerate(args.seeds):
                if len(args.seeds)==2 and seed_index==1:
                    ordered=list(reversed(names))
                else:
                    rotation=seed_index % len(names)
                    ordered=names[rotation:]+names[:rotation]
                for name in ordered:
                    job_name,policy,budget,scenario,rate,flags=by_name[name]
                    queue.append((selected,job_name,policy,budget,scenario,rate,flags,seed))
        elif selected=='rq5':
            # Rotate tested budgets across seeds to reduce order/thermal bias.
            budgets=[job[2] for job in jobs]
            by_budget={job[2]:job for job in jobs}
            for seed_index,seed in enumerate(args.seeds):
                if len(args.seeds)==2 and seed_index==1:
                    ordered=list(reversed(budgets))
                else:
                    rotation=seed_index % len(budgets)
                    ordered=budgets[rotation:]+budgets[:rotation]
                for budget in ordered:
                    name,policy,job_budget,scenario,rate,flags=by_budget[budget]
                    queue.append((selected,name,policy,job_budget,scenario,rate,flags,seed))
        else:
            for name,policy,budget,scenario,rate,flags in jobs:
                for seed in args.seeds:
                    queue.append((selected,name,policy,budget,scenario,rate,flags,seed))
    includes_rq4=any(row[0]=='rq4' for row in queue)
    print(f'{len(queue)} runs, at least {len(queue)*args.windows*args.window_sec/3600:.2f} runtime hours, excluding data preparation',flush=True)
    if includes_rq4:
        print('RQ4 runs proof-sampling levels 0/5/10/25% and fault modes at 10/25%',flush=True)
    if args.dry_run:
        for row in queue:print(*row)
        return
    source_value=os.getenv('BOOKS_SOURCE')
    source=Path(source_value) if source_value else None
    sample_root=Path(os.getenv('SOSD_SAMPLE_ROOT','data/sosd_samples'))
    if not sample_root.is_absolute():sample_root=ROOT/sample_root
    for seed in args.seeds:
        sample=sample_root/'books'/f'books_{args.exist_num//1000000}M_seed{seed}.uint64'
        if not sample.is_file() or sample.stat().st_size!=8*args.exist_num:
            if source is None or not source.is_file():
                raise FileNotFoundError('SOSD source is required to prepare samples; set BOOKS_SOURCE or prepare the samples in SOSD_SAMPLE_ROOT')
            subprocess.run(['bash',str(ROOT/'scripts/prepare_sosd_samples.sh'),str(source),'books',str(sample.parent),str(args.exist_num),*[str(s) for s in args.seeds]],cwd=ROOT,check=True)
            break
    aidel=ROOT/'build/linverix_aidel_protocol'
    pgm_rq1=ROOT/'build/linverix_pgm_rq1_protocol'
    if not aidel.exists() or aidel.stat().st_mtime<(ROOT/'examples/linverix_aidel_protocol.cc').stat().st_mtime:
        subprocess.run(['bash',str(ROOT/'scripts/build_rq1_protocol.sh')],cwd=ROOT,check=True)
    if any(j[0]=='rq6' for j in queue):
        if not pgm_rq1.exists() or pgm_rq1.stat().st_mtime<max((ROOT/'examples/linverix_aidel_protocol.cc').stat().st_mtime,(ROOT/'include/pgm_compat.h').stat().st_mtime,(ROOT/'scripts/build_pgm_rq1_protocol.sh').stat().st_mtime):
            subprocess.run(['bash',str(ROOT/'scripts/build_pgm_rq1_protocol.sh')],cwd=ROOT,check=True)
    phase1_rho_scale=os.getenv('LINUCB_PHASE1_RHO_SCALE','0.25')
    phase1_starvation_windows=os.getenv('LINUCB_PHASE1_STARVATION_WINDOWS','8')
    backend_binary=pgm_rq1 if any(j[0]=='rq6' for j in queue) else aidel
    scheduler_revision='RQ1 final protocol source with PGM exact-lookup adapter'
    manifest={'protocol_id':PROTOCOL['protocol_id'],'protocol_common':COMMON,'source':'RQ1 aligned read-only foreground with heterogeneous per-segment latency drift and exact correction search','rq6_backend':'pgm','rq6_backend_source':'official PGM-index','pgm_revision':'c6fcf3d34e55eb0061b01e2f49dfcbdb711f1407','scheduler_revision':scheduler_revision,'phase1_rho_scale':float(phase1_rho_scale),'phase1_starvation_windows':int(phase1_starvation_windows),'warmup_maintenance':False,'jobs':[list(job) for job in queue],'windows':args.windows,'window_sec':args.window_sec,'warmup':args.warmup,'threads':args.threads,'item_num':args.item_num,'seeds':args.seeds,'segments':args.segments,'exist_num':args.exist_num,'budget_default':2,
        'drift_mode':'controlled_heterogeneous_segment_latency_drift','drift_increment_ns_per_segment':250000,'drift_cap_ns':2000000,'drift_accumulation':False,'query_workload':'read_only_seeded_random_permutation_of_same_dataset_keys_cycled_per_worker','synthetic_drift_wait_ns':250000,
        'rq2_recovery_rule':{'residual_target':'post-repair top-K residual no greater than the per-window B-repair oracle remainder plus 0.01 excess comparisons/query','p99_target':'at most 105% of the shared pre-drift P99 baseline for two consecutive windows','service_recovery_is_reported_only_if_degradation_occurs':True},
        'prediction_bias_keys_per_injection':0,
        'prediction_bias_cap_keys':0,
        'check_routed_reads':os.getenv('CHECK_ROUTED_READS','0'),
        'rq4_proof_audit':{'sampling_rates':[0.0,0.05,0.10,0.25],
                           'fault_rates':[0.10,0.25],
                           'fault_modes':['clean','omission','modification','replay'],
                           'proof_unit':'one point-proof opportunity per control-window boundary',
                           'fault_variable':'RQ5_FAULT'},
        # Record policy-affecting environment overrides so diagnostic runs
        # cannot be mistaken for the default full LinVeriX configuration.
        'scheduler_env_overrides':{
            key:os.getenv(key) for key in (
                'LINUCB_PHASE1_MAX_B','LINUCB_PHASE1_RHO_SCALE','LINUCB_PHASE1_STARVATION_WINDOWS','LINUCB_PHASE2_MAX_TARGETS',
                'NO_PHASE2','LINUCB_PHASE2_REWARD_WEIGHT','RQ5_FAULT')
            if os.getenv(key) is not None},
        'rq1_reference_source_sha256':hashlib.sha256((ROOT/'examples/linverix_aidel_protocol.cc').read_bytes()).hexdigest(),
        'rq6_scheduler_source_file':'build/linverix_pgm_rq1_protocol.cc',
        'rq6_scheduler_source_sha256':hashlib.sha256((ROOT/'build/linverix_pgm_rq1_protocol.cc').read_bytes()).hexdigest(),
        'aidel_binary_sha256':hashlib.sha256(aidel.read_bytes()).hexdigest(),
        'rq6_backend_binary_sha256':hashlib.sha256(backend_binary.read_bytes()).hexdigest() if backend_binary.exists() else None,
        'samples':{str(seed):{'path':f"books/books_{args.exist_num//1000000}M_seed{seed}.uint64",'sha256':hashlib.sha256((sample_root/'books'/f'books_{args.exist_num//1000000}M_seed{seed}.uint64').read_bytes()).hexdigest()} for seed in args.seeds}}
    manifest_file=args.out/'manifest.json'
    if manifest_file.exists():
        if json.loads(manifest_file.read_text(encoding='utf8'))!=manifest:
            raise ValueError('existing output uses different sources, binaries, samples or settings; choose a new --out')
    else:
        if args.out.exists():raise ValueError('output directory exists without a manifest; choose a new --out')
        args.out.mkdir(parents=True)
        manifest_file.write_text(json.dumps(manifest,indent=2),encoding='utf8')
    for seq,(selected,name,policy,budget,scenario,rate,flags,seed) in enumerate(queue,1):
        destination=args.out/selected/f'{name}_s{seed}.csv'
        destination.parent.mkdir(parents=True,exist_ok=True)
        if destination.exists():
            existing_cmd=['python3',str(ROOT/'scripts/validate_formal_runs.py'),str(destination),'--windows',str(args.windows)]
            checked=subprocess.run(existing_cmd,cwd=ROOT,
                env={**os.environ,'EXPECTED_WINDOWS':str(args.windows)},capture_output=True)
            if checked.returncode:
                raise ValueError(f'existing CSV did not validate: {destination}; inspect before retrying')
            print(f'[{seq}/{len(queue)}] SKIP validated {selected} {name} seed={seed}',flush=True)
            continue
        sample=sample_root/'books'/f'books_{args.exist_num//1000000}M_seed{seed}.uint64'
        env=os.environ.copy()
        # Do not inherit experiment-only scheduler switches from an earlier
        # diagnostic shell. RQ3 enables its ablation explicitly below.
        for key in ('LINUCB_PHASE1_MAX_B','NO_PHASE2','LINUCB_PHASE2_REWARD_WEIGHT',
                    'LINUCB_PHASE2_MAX_TARGETS','RQ5_FAULT'):
            env.pop(key,None)
        sample_arg=runtime_path(sample)
        env.update(SOSD_SAMPLE_FILE=sample_arg,SOSD_DATASET='books',
                   DRIFT_INTERVAL_SEC=str(args.window_sec),
                   DRIFT_WARMUP_SEC=str(args.window_sec*args.warmup),
                   DRIFT_K=str(COMMON['top_k']),DRIFT_LAT_NS_PER_SEG=str(COMMON['drift']['increment_ns_per_segment']),DRIFT_WARMUP_WINDOWS=str(args.warmup),
                   DRIFT_NO_ACCUM='1',DRIFT_TEMPORAL_HETERO='1',SIMULATED_DRIFT_WAIT='1',
                   DRIFT_CAP_NS=str(COMMON['drift']['cap_ns_per_segment']),DRIFT_PREDICTION_BIAS_KEYS=str(COMMON['drift']['prediction_bias_keys']),
                   DRIFT_PREDICTION_BIAS_CAP_KEYS='0',MIN_EXTRA_NS_FOR_RETRAIN='1',
                   SEGMENT_COUNT=str(args.segments),PERIODIC_EVERY_WINDOWS='1')
        # Match the confirmed RQ1 protocol: the segment latency drift itself
        # is the scheduler signal; do not substitute the v40 correction-excess
        # detector or prediction-bias injection used by older follow-up runs.
        env.pop('DRIFT_SIGNAL_MODE',None)
        env.update(MEASURED_FEEDBACK='0',THRESHOLD_DRIFT_US='250')
        env['LINUCB_PHASE1_RHO_SCALE']=phase1_rho_scale
        env['LINUCB_PHASE1_STARVATION_WINDOWS']=phase1_starvation_windows
        if policy=='linverix':
            env['LINUCB_PHASE1_MAX_B']=str(budget)
        else:
            env.pop('LINUCB_PHASE1_MAX_B',None)
        if selected=='rq2':
            env['DRIFT_INTERVAL_SEC']='0'
        extra=list(flags)
        if selected=='rq2' and scenario=='recovery':
            midpoint=args.warmup
            extra+=['--scenario','midlate','--K-start','0','--K-mid','6','--mid-time',str(args.window_sec*midpoint)]
        if selected=='rq3':
            if scenario=='no_phase2':env.update(NO_PHASE2='1')
            if scenario=='no_avoid':extra.append('--no-avoid')
            if scenario=='no_topk':extra.append('--no-topk')
        if selected=='rq4':
            env['RQ5_FAULT']=scenario
        base,policy_flags=POLICIES[policy]
        proof='merklesum' if rate>=0 else 'hash'
        cmd=[str(backend_binary if selected=='rq6' else aidel),*policy_flags,*extra,
             f'--policy={base}',f'--budget_B={budget}',f'--win_sec={args.window_sec}',
             f'--runtime={args.windows*args.window_sec}',f'--thread_num={args.threads}',
             '--benchmark=13',f'--item_num={args.item_num}',f'--exist_num={args.exist_num}',
             f'--seed={seed}',f'--verify_layer={proof}',f'--proof_rate={max(rate,0)}',
             f'--csv_log={runtime_path(destination)}']
        log=destination.with_suffix('.log')
        print(f'[{seq}/{len(queue)}] {selected} {name} seed={seed}',flush=True)
        with log.open('w') as output:
            subprocess.run(cmd,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT,check=True)
        validation_cmd=['python3',str(ROOT/'scripts/validate_formal_runs.py'),str(destination),'--windows',str(args.windows)]
        subprocess.run(validation_cmd,cwd=ROOT,
                       env={**env,'EXPECTED_WINDOWS':str(args.windows)},check=True)
    if rq=='rq2':
        subprocess.run(['python3',str(ROOT/'scripts/summarize_rq2_rq1_protocol.py'),str(args.out),
                        '--warmup',str(args.warmup),'--window-sec',str(args.window_sec)],cwd=ROOT,check=True)
    if includes_rq4:
        subprocess.run(['python3',str(ROOT/'scripts/summarize_rq4_proofs.py'),
                        str(args.out),'--warmup',str(args.warmup)],cwd=ROOT,check=True)
    if rq=='rq4':
        return
    if rq=='rq6':
        summary=ROOT/'results'/args.out.name
        subprocess.run(['python3',str(ROOT/'scripts/summarize_formal_runs.py'),str(args.out),str(summary),
                        '--dataset','rq6','--warmup-windows',str(args.warmup),'--window-sec',str(args.window_sec)],cwd=ROOT,check=True)
    else:
        report_script='report_followup_rqs.py' if rq=='rq6' else 'report_rq1_protocol_followups.py'
        subprocess.run(['python3',str(ROOT/'scripts'/report_script),str(args.out),'--warmup',str(args.warmup)],cwd=ROOT,check=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('rq',choices=['rq2','rq3','rq4','rq5','rq6','all'])
    p.add_argument('--out',type=Path,default=Path('runs/followup'))
    p.add_argument('--windows',type=int,default=COMMON['windows'])
    p.add_argument('--window-sec',type=int,default=COMMON['window_sec'])
    p.add_argument('--warmup',type=int,default=COMMON['warmup_windows'])
    p.add_argument('--seeds',type=int,nargs='+',default=COMMON['seeds'])
    p.add_argument('--segments',type=int,default=COMMON['segments'])
    p.add_argument('--threads',type=int,default=COMMON['threads'])
    p.add_argument('--item-num',type=int,default=COMMON['item_num'])
    p.add_argument('--exist-num',type=int,default=COMMON['exist_num'])
    p.add_argument('--rq1-run-root',type=Path,default=ROOT/'runs/rq1_full_300w')
    p.add_argument('--rq1-log-root',type=Path,default=ROOT/'logs/rq1_full_300w')
    p.add_argument('--dry-run',action='store_true')
    a=p.parse_args()
    if not a.out.is_absolute():a.out=ROOT/a.out
    if not (a.windows>a.warmup+2 and a.window_sec>=1 and a.exist_num>=1000):p.error('invalid windows/warmup/window-sec/exist-num')
    run(a)
