#!/usr/bin/env bash
set -euo pipefail
repo_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$repo_root"
mkdir -p build
${CXX:-/usr/bin/c++} -O3 -DNDEBUG -std=gnu++17 -Wall -Wextra \
  -Wno-unused-parameter -I. -Iinclude -Iconfig -Iutil \
  examples/linverix_aidel_protocol.cc \
  -o build/linverix_aidel_protocol \
  build/liblinverix_ucb.a /usr/lib/x86_64-linux-gnu/libcrypto.so \
  -lm -ldl build/libdata_globals.a -pthread
