"""Create the RQ2 dual-panel residual and foreground-P99 recovery figure.

The PDF is built from the five-seed formal RQ2 summaries in
``formal_results/RQ2_Recovery``. Both panels use the same microsecond scale.
Requires ReportLab.
"""

import argparse
import csv
from pathlib import Path

from reportlab.graphics import renderPDF
from reportlab.graphics.shapes import Circle, Drawing, Group, Line, PolyLine, Rect, String
from reportlab.lib.colors import HexColor


WIDTH, HEIGHT = 520, 250
BLUE = HexColor("#0072B2")
ORANGE = HexColor("#E69F00")
INK = HexColor("#252A30")
MUTED = HexColor("#626D78")
GRID = HexColor("#D9DEE4")
AXIS = HexColor("#727D88")
VALUE_MAX = 1100.0
PLOT_BOTTOM = 49
PLOT_HEIGHT = 151
PANEL_WIDTH = 198


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def select(rows, metric, mode, mean_field, max_position=None):
    selected = [row for row in rows if row["metric"] == metric and row["mode"] == mode]
    if max_position is not None:
        selected = [row for row in selected if int(row["window_position"]) <= max_position]
    selected.sort(key=lambda row: int(row["window_position"]))
    return [
        (int(row["window_position"]) * 2,
         float(row[mean_field]),
         float(row["ci95_halfwidth"]))
        for row in selected
    ]


def add_text(drawing: Drawing, x: float, y: float, value: object,
             size: float = 8.5, color=INK, bold=False, anchor="start") -> None:
    drawing.add(String(x, y, str(value),
                       fontName="Helvetica-Bold" if bold else "Helvetica",
                       fontSize=size, fillColor=color, textAnchor=anchor))


def add_line(drawing: Drawing, x0: float, y0: float, x1: float, y1: float,
             color=INK, width: float = 0.8) -> None:
    drawing.add(Line(x0, y0, x1, y1, strokeColor=color, strokeWidth=width))


def add_error_bar(drawing: Drawing, x: float, y0: float, y1: float, color,
                  cap: float = 2.5) -> None:
    add_line(drawing, x, y0, x, y1, color, 0.9)
    add_line(drawing, x - cap, y0, x + cap, y0, color, 0.9)
    add_line(drawing, x - cap, y1, x + cap, y1, color, 0.9)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--out-dir", type=Path)
    args = parser.parse_args()

    artifact_root = Path(__file__).resolve().parents[2]
    run_dir = args.run_dir or artifact_root / "formal_results" / "RQ2_Recovery"
    output_dir = args.out_dir or artifact_root / "generated_figures"
    output_dir.mkdir(parents=True, exist_ok=True)
    window_rows = read_rows(run_dir / "rq2_window_figure_summary.csv")
    event_rows = read_rows(run_dir / "rq2_paper_target_figure_summary.csv")

    continuous = {
        "residual": select(window_rows, "residual", "continuous", "mean_across_seed_values", 15),
        "p99": select(window_rows, "p99_us", "continuous", "mean_across_seed_values", 15),
    }
    spaced = {
        "residual": select(event_rows, "residual", "spaced", "mean_across_seed_means"),
        "p99": select(event_rows, "p99_us", "spaced", "mean_across_seed_means"),
    }
    if [len(continuous["residual"]), len(continuous["p99"]),
            len(spaced["residual"]), len(spaced["p99"])] != [16, 16, 3, 3]:
        raise ValueError("RQ2 formal summaries have an unexpected number of windows")

    drawing = Drawing(WIDTH, HEIGHT)
    drawing.add(Rect(0, 0, WIDTH, HEIGHT, fillColor=HexColor("#FFFFFF"), strokeColor=None))

    # One compact legend; line colors identify the two quantities.
    legend_y = HEIGHT - 18
    add_line(drawing, 151, legend_y, 176, legend_y, BLUE, 1.8)
    drawing.add(Circle(163.5, legend_y, 2.5, fillColor=BLUE, strokeColor=BLUE))
    add_text(drawing, 182, legend_y - 3, "Top-6 residual", 8.5)
    add_line(drawing, 286, legend_y, 311, legend_y, ORANGE, 1.8)
    drawing.add(Rect(296.5, legend_y - 2.5, 5, 5, fillColor=ORANGE, strokeColor=ORANGE))
    add_text(drawing, 317, legend_y - 3, "Foreground P99", 8.5)

    panels = [
        (58, "Continuous drift", continuous, 30,
         [0, 6, 12, 18, 24, 30], "Elapsed time (s)"),
        (304, "Spaced drift", spaced, 4,
         [0, 2, 4], "Time since injection (s)"),
    ]
    for panel_x, title, series, xmax, xticks, xlabel in panels:
        panel_right = panel_x + PANEL_WIDTH
        add_text(drawing, panel_x + PANEL_WIDTH / 2, HEIGHT - 37,
                 title, 10, bold=True, anchor="middle")

        def px(time_s: int) -> float:
            return panel_x + PANEL_WIDTH * time_s / xmax

        def py(value: float) -> float:
            return PLOT_BOTTOM + PLOT_HEIGHT * value / VALUE_MAX

        for tick in (0, 250, 500, 750, 1000):
            yy = py(tick)
            add_line(drawing, panel_x, yy, panel_right, yy, GRID, 0.65)
            add_text(drawing, panel_x - 6, yy - 2.8, tick, 8,
                     color=MUTED, anchor="end")
        add_line(drawing, panel_x, PLOT_BOTTOM, panel_x, PLOT_BOTTOM + PLOT_HEIGHT, AXIS, 0.85)
        add_line(drawing, panel_x, PLOT_BOTTOM, panel_right, PLOT_BOTTOM, AXIS, 0.85)
        for tick in xticks:
            xx = px(tick)
            add_line(drawing, xx, PLOT_BOTTOM, xx, PLOT_BOTTOM - 3.5, AXIS, 0.75)
            add_text(drawing, xx, PLOT_BOTTOM - 15, tick, 8, color=MUTED, anchor="middle")
        add_text(drawing, panel_x + PANEL_WIDTH / 2, 11, xlabel, 8.5, anchor="middle")

        for key, color, marker in (("residual", BLUE, "circle"), ("p99", ORANGE, "square")):
            points = [(px(t), py(v)) for t, v, _ in series[key]]
            flat = [coordinate for point in points for coordinate in point]
            drawing.add(PolyLine(points=flat, strokeColor=color, strokeWidth=1.8, fillColor=None))
            for (t, value, ci), (xx, yy) in zip(series[key], points):
                if ci > 0:
                    low = py(max(0, value - ci))
                    high = py(min(VALUE_MAX, value + ci))
                    add_error_bar(drawing, xx, low, high, color)
                if marker == "circle":
                    drawing.add(Circle(xx, yy, 2.8, fillColor=color,
                                       strokeColor=HexColor("#FFFFFF"), strokeWidth=0.7))
                else:
                    drawing.add(Rect(xx - 2.6, yy - 2.6, 5.2, 5.2, fillColor=color,
                                     strokeColor=HexColor("#FFFFFF"), strokeWidth=0.7))

    # Shared y-axis title, rotated so it does not compete with either panel.
    ylabel = Group()
    ylabel.add(String(0, 0, "P99 / residual (µs)",
                      fontName="Helvetica", fontSize=8.5, fillColor=INK,
                      textAnchor="middle"))
    ylabel.transform = [0, 1, -1, 0, 18, HEIGHT / 2]
    drawing.add(ylabel)

    output_path = output_dir / "rq2_recovery.pdf"
    renderPDF.drawToFile(drawing, str(output_path))
    print(f"Wrote {output_path}")


if __name__ == "__main__":
    main()
