#!/usr/bin/env bash
set -euo pipefail
repo_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$repo_root"

source_file="${1:?usage: $0 SOURCE_UINT64 DATASET OUT_DIR [TARGET_KEYS] [SEED ...]}"
dataset="${2:?usage: $0 SOURCE_UINT64 DATASET OUT_DIR [TARGET_KEYS] [SEED ...]}"
out_dir="${3:?usage: $0 SOURCE_UINT64 DATASET OUT_DIR [TARGET_KEYS] [SEED ...]}"
target="${4:-1000000}"
shift 4 || true
if (( $# == 0 )); then set -- 1 2 3 4 5; fi

mkdir -p build "$out_dir"
echo "[BUILD] preparing $dataset SOSD samples"
"${CXX:-g++}" -O3 -std=c++17 tools/prepare_sosd_samples.cpp \
  -o build/prepare_sosd_samples

sampler_source="$source_file"
temporary_source=""
cleanup() {
  if [[ -n "$temporary_source" && -f "$temporary_source" ]]; then
    rm -f -- "$temporary_source"
  fi
}
trap cleanup EXIT
if [[ "$source_file" == *.zst ]]; then
  if ! command -v zstd >/dev/null 2>&1; then
    echo "[ERROR] $source_file is zstd-compressed, but zstd is not installed" >&2
    echo "Install zstd with your distribution's package manager (for Ubuntu: sudo apt-get install zstd)" >&2
    exit 2
  fi
  mkdir -p data/.sample_tmp
  temporary_source="$(mktemp "data/.sample_tmp/${dataset}.XXXXXX.uint64")"
  echo "[DECOMPRESS] $source_file"
  zstd -dc -- "$source_file" > "$temporary_source"
  sampler_source="$temporary_source"
fi
SAMPLE_LABEL="$dataset" SAMPLE_SOURCE_NAME="${source_file##*/}" build/prepare_sosd_samples \
  "$sampler_source" "$out_dir" "$target" "$@"
sha256sum "$out_dir/${dataset}_"*M_seed*.uint64 > "$out_dir/SHA256SUMS.txt"
echo "[DONE] $dataset samples are in $out_dir"
