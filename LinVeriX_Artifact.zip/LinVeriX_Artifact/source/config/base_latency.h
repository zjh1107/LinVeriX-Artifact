#pragma once
#include <cstdint>   
// 全局基线延迟（纳秒）
extern std::uint64_t g_base_latency_ns;

// 从环境变量 BASE_LAT_NS 读取，缺省=0
void init_base_latency_from_env();