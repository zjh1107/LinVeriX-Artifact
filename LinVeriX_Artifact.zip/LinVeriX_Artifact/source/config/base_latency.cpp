#include "config/base_latency.h"
#include <cstdlib>
#include <iostream>

std::uint64_t g_base_latency_ns = 0;

void init_base_latency_from_env() {
    if (const char* v = std::getenv("BASE_LAT_NS")) {
        g_base_latency_ns = strtoull(v, nullptr, 10);
    }
    std::cerr << "[init] BASE_LAT_NS=" << g_base_latency_ns << "\n";
}