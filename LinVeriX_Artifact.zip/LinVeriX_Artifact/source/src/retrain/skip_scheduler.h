#pragma once

struct DriftSummary {
    int drift_segments = 0;          // 本窗口标记为漂移的段数量
    double expected_gain_us = 0.0;   // 预计 tail 改善总和 (μs)
};

class SkipScheduler {
public:
    bool shouldSkip(const DriftSummary& s) {
        // 判定一个“干净窗口”
        bool clean = (s.drift_segments < MIN_DRIFT_SEGMENTS) ||
                     (s.expected_gain_us < MIN_EXPECTED_GAIN_US);
        if (clean) {
            clean_streak_++;
            if (clean_streak_ >= CLEAN_GRACE_WINDOWS) {
                // 达到连续干净窗口阈值 → 跳过
                return true;
            }
        } else {
            clean_streak_ = 0;
        }
        return false;
    }
    void reset() { clean_streak_ = 0; }
private:
    int clean_streak_ = 0;
    static constexpr int MIN_DRIFT_SEGMENTS = 2;     // <2 段漂移视作干净
    static constexpr int CLEAN_GRACE_WINDOWS = 2;    // 连续 2 个干净窗口后 skip
    static constexpr double MIN_EXPECTED_GAIN_US = 1.0; // 预计收益 <1 μs 视为空
};