#pragma once
#include <vector>
#include <algorithm>

struct SegmentStats {
    double baseline_p99_us = 0.0;
    double current_p99_us  = 0.0;
    double inflation_us    = 0.0;
    bool   drift_flag      = false;
};

inline void update_segment_stats(std::vector<SegmentStats>& segs, double pct_thresh = 5.0) {
    for (auto& s : segs) {
        if (s.baseline_p99_us <= 0) s.baseline_p99_us = s.current_p99_us;
        s.inflation_us = s.current_p99_us - s.baseline_p99_us;
        double pct = s.baseline_p99_us > 0 ? (s.inflation_us * 100.0 / s.baseline_p99_us) : 0.0;
        s.drift_flag = (pct >= pct_thresh);
    }
}

inline DriftSummary summarize(const std::vector<SegmentStats>& segs) {
    DriftSummary d;
    for (auto& s : segs) {
        if (s.drift_flag) {
            d.drift_segments++;
            d.expected_gain_us += std::max(0.0, s.inflation_us);
        }
    }
    return d;
}