#include "function.h"

config Config;
std::vector<key_type> exist_keys;
std::vector<key_type> non_exist_keys;