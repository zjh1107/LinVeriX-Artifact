#include "linucb_controller.h"

LinUCBController::LinUCBController(const Param& p): P(p) {}

void LinUCBController::init_model(Model& m){
  if (m.initialized) return;
  const int d = P.d;
  m.Ainv.assign(d*d, 0.0);
  m.theta.assign(d, 0.0);
  m.b.assign(d, 0.0);
  const double c = 1.0 / P.lambda;
  for (int i=0;i<d;i++) m.Ainv[i*d+i] = c;
  m.initialized = true;
}

void LinUCBController::ensure_arms_exist(const std::vector<uint32_t>& arm_ids){
  (void)arm_ids;
  init_model(shared_model_);
}

double LinUCBController::quad_form(const std::vector<double>& Ainv, const std::vector<double>& x){
  const int d = (int)x.size();
  double s=0.0;
  for (int i=0;i<d;i++){
    double tmp=0.0;
    for (int j=0;j<d;j++) tmp += Ainv[i*d+j]*x[j];
    s += x[i]*tmp;
  }
  return s;
}

void LinUCBController::sm_update_Ainv(std::vector<double>& Ainv, const std::vector<double>& x){
  const int d = (int)x.size();
  std::vector<double> Ainvx(d, 0.0);
  for (int i=0;i<d;i++){
    double s=0.0;
    for (int j=0;j<d;j++) s += Ainv[i*d+j]*x[j];
    Ainvx[i]=s;
  }
  double denom = 1.0;
  for (int i=0;i<d;i++) denom += x[i]*Ainvx[i];
  for (int i=0;i<d;i++){
    for (int j=0;j<d;j++){
      Ainv[i*d+j] -= (Ainvx[i]*Ainvx[j]) / denom;
    }
  }
}

double LinUCBController::ucb(uint32_t arm, const std::vector<double>& x) const{
  (void)arm;
  const auto& m = shared_model_;
  assert(m.initialized);
  double mean = dot(m.theta, x);
  double unc  = std::sqrt(quad_form(m.Ainv, x));
  return mean + P.alpha * unc;
}

double LinUCBController::uncertainty(const std::vector<double>& x) const{
  const auto& m = shared_model_;
  assert(m.initialized);
  return std::sqrt(std::max(0.0, quad_form(m.Ainv, x)));
}

double LinUCBController::expected_reward(uint32_t arm_id,
                                         const std::vector<double>& x) const{
  const auto& m = shared_model_;
  assert(m.initialized);
  const double contextual_mean = std::tanh(dot(m.theta, x));
  const auto count_it = arm_feedback_counts_.find(arm_id);
  const uint64_t count = count_it == arm_feedback_counts_.end() ? 0 : count_it->second;
  const auto reward_it = arm_reward_sums_.find(arm_id);
  const double local_mean = count > 0 && reward_it != arm_reward_sums_.end()
      ? reward_it->second / static_cast<double>(count) : contextual_mean;
  // Shrink sparse segment-specific observations toward the shared contextual
  // estimate. The result is an exploitation estimate for Phase 2; unlike the
  // Phase-1 UCB score, it deliberately contains no uncertainty bonus.
  const double local_weight = static_cast<double>(count) /
                              (static_cast<double>(count) + 2.0);
  return std::clamp((1.0 - local_weight) * contextual_mean +
                    local_weight * local_mean, -1.0, 1.0);
}

void LinUCBController::rank_by_density(const std::vector<ArmContext>& arms,
                                       std::vector<uint32_t>& out) const{
  struct Cand{ uint32_t id; double score; bool observed; };
  std::vector<Cand> cs; cs.reserve(arms.size());
  std::vector<double> costs;
  costs.reserve(arms.size());
  for (const auto &a : arms)
    costs.push_back(std::max(0.05, a.est_cost));
  double median_cost = 1.0;
  if (!costs.empty())
  {
    const size_t mid = costs.size() / 2;
    std::nth_element(costs.begin(), costs.begin() + mid, costs.end());
    median_cost = std::max(0.05, costs[mid]);
  }
  for (auto& a: arms){
    const double contextual_ucb = ucb(a.arm_id, a.x);
    const double unc = uncertainty(a.x);
    // x[7] is the normalized current residual/recent slope. Keep it as an
    // immediate-value prior while measured post-publication feedback gradually
    // earns more weight; dropping it after the first observation made one noisy
    // reward able to displace high-residual candidates for the rest of a run.
    const double residual_prior = a.x.size() > 7 ? std::max(0.0, a.x[7]) : 0.0;
    const double normalized_uncertainty = unc / (1.0 + unc);
    const auto count_it = arm_feedback_counts_.find(a.arm_id);
    const uint64_t arm_feedback_count = count_it == arm_feedback_counts_.end()
        ? 0 : count_it->second;
    const auto reward_it = arm_reward_sums_.find(a.arm_id);
    const double arm_mean_reward = arm_feedback_count && reward_it != arm_reward_sums_.end()
        ? reward_it->second / static_cast<double>(arm_feedback_count) : 0.0;
    const double arm_exploration_bonus = P.alpha /
        std::sqrt(1.0 + static_cast<double>(arm_feedback_count));
    // Phase 1 receives only a small fraction of a B=2 window budget, spread
    // across many segments. Requiring eight observations before measured
    // reward can materially affect ranking overwhelms the feedback signal;
    // use one prior pseudo-observation so sparse post-publication evidence is
    // incorporated promptly while the shared contextual model still pools
    // feedback across segments.
    const double learned_weight = P.use_residual_prior
        ? static_cast<double>(arm_feedback_count) /
              (static_cast<double>(arm_feedback_count) + 1.0)
        : 1.0;
    // Keep a local reward estimate for stable segment differences while the
    // shared contextual model still transfers evidence across segments.
    const double learned_benefit = std::max(0.0, std::tanh(
        contextual_ucb + arm_mean_reward + arm_exploration_bonus));
    const double cold_start_bonus = (1.0 - learned_weight) *
        0.25 * normalized_uncertainty * std::max(1.0, residual_prior);
    const double predicted_benefit = (1.0 - learned_weight) * residual_prior +
        learned_weight * learned_benefit + cold_start_bonus;
    const double relative_cost = std::clamp(
        std::max(0.05, a.est_cost) / median_cost, 0.5, 2.0);
    // A repair can improve service only when the segment receives foreground
    // traffic. Weight exploration by the unsaturated QPS context while keeping
    // a 25% floor so cold segments remain discoverable.
    const double normalized_qps = a.x.size() > 1
        ? std::clamp(a.x[1], 0.0, 1.0) : 0.0;
    const double service_exposure = 0.25 + 0.75 * normalized_qps;
    // Rank expected service benefit per square-root normalized retraining cost.
    const double score = predicted_benefit * service_exposure /
                         std::sqrt(relative_cost);
    cs.push_back({a.arm_id, score, arm_feedback_count > 0});
  }
  std::stable_sort(cs.begin(), cs.end(), [](const Cand& A, const Cand& B){
    if (A.observed != B.observed) return !A.observed;
    return A.score > B.score;
  });
  out.clear();
  const size_t B = P.budget_B;
  for (size_t i=0; i<cs.size() && i<B; ++i) out.push_back(cs[i].id);
}

std::vector<uint32_t> LinUCBController::select(const std::vector<ArmContext>& arms){
  std::vector<uint32_t> ids; ids.reserve(arms.size());
  for (auto& a: arms) ids.push_back(a.arm_id);
  ensure_arms_exist(ids);

  std::vector<uint32_t> chosen;
  rank_by_density(arms, chosen);

  last_x_.clear();
  last_x_.reserve(chosen.size());
  for (auto id : chosen){
    for (auto& a : arms){
      if (a.arm_id == id) { last_x_[id] = a.x; break; }
    }
  }
  return chosen;
}

void LinUCBController::update(const std::vector<ArmFeedback>& fbs){
  for (auto& fb: fbs){
    ++feedback_count_;
    ++arm_feedback_counts_[fb.arm_id];
    arm_reward_sums_[fb.arm_id] += fb.reward;
    init_model(shared_model_);
    auto& m = shared_model_;
    assert((int)fb.x.size() == (int)m.theta.size());
    sm_update_Ainv(m.Ainv, fb.x);
    for (size_t i=0;i<m.b.size();++i) m.b[i] += fb.reward * fb.x[i];
    const int d = (int)m.theta.size();
    for (int i=0;i<d;i++){
      double s=0.0;
      for (int j=0;j<d;j++) s += m.Ainv[i*d+j] * m.b[j];
      m.theta[i]=s;
    }
  }
}

void LinUCBController::observeReward(uint32_t arm_id, double reward){
  auto itx = last_x_.find(arm_id);
  if (itx == last_x_.end()) return;
  ArmFeedback fb{arm_id, itx->second, reward};
  update(std::vector<ArmFeedback>{fb});
}

void LinUCBController::observeReward(uint32_t arm_id, double reward, const std::vector<double>& x){
  ArmFeedback fb{arm_id, x, reward};
  update(std::vector<ArmFeedback>{fb});
}
