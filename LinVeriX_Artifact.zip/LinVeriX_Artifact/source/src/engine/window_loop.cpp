#include "retrain/skip_scheduler.h"
#include "retrain/drift_features.h"
extern SkipScheduler g_skip;
extern std::vector<SegmentStats> g_segments;

// 伪接口：返回 top-B 的段 ID（已有 LinUCB 逻辑）
std::vector<int> select_top_B(int B); 
double retrain_one_segment(int seg_id); // 返回 ms

void process_window(int win_id, int B_budget) {
    // (1) 更新各段统计
    update_segment_stats(g_segments);

    // (2) 汇总漂移
    DriftSummary summary = summarize(g_segments);

    // (3) 跳过逻辑
    if (g_skip.shouldSkip(summary)) {
        int retrain_cnt_win = 0;
        double retrain_cost_ms = 0.0;
        log_window(win_id, /*p99 等已有字段*/, retrain_cnt_win, retrain_cost_ms, /*selected_ids=*/"");
        return;
    }

    // (4) 构造候选：只对 drift_flag=true 的段进行评分
    std::vector<int> candidates;
    for (int i=0;i<(int)g_segments.size();++i)
        if (g_segments[i].drift_flag)
            candidates.push_back(i);
    if (candidates.empty()) {
        int retrain_cnt_win = 0;
        double retrain_cost_ms = 0.0;
        log_window(win_id, /*...*/, retrain_cnt_win, retrain_cost_ms, "");
        return;
    }

    // (5) 在 candidates 中做 LinUCB/打分选 top B（请使用你已有策略）
    auto top = select_top_B(std::min(B_budget, (int)candidates.size()));

    // (6) 执行重训
    double retrain_cost_ms = 0.0;
    for (int seg : top) retrain_cost_ms += retrain_one_segment(seg); // 或 seg * 固定 5ms
    int retrain_cnt_win = (int)top.size();

    // (7) 记录
    // selected_ids 可写成 "1|7|25"
    std::string sel;
    for (size_t i=0;i<top.size();++i) {
        if (i) sel.push_back('|');
        sel += std::to_string(top[i]);
    }
    log_window(win_id, /*p99*/ retrain_cnt_win, retrain_cost_ms, sel,
               summary.drift_segments, summary.expected_gain_us);
}