#include "util/busy_wait.h"
extern uint64_t g_base_latency_ns; // 由参数或环境注入

Status handle_request(const Request& r) {
    // ... 原有逻辑前
    busy_wait_ns(g_base_latency_ns);
    // ... 真实访问/索引查找
    return Status::OK();
}