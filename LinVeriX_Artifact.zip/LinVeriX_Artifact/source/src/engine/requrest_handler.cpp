#include "util/busy_wait.h"
#include "config/base_latency.h"

// 示例函数
Status handle_request(const Request& r) {
    static bool inited = false;
    if (!inited) { init_base_latency_from_env(); inited = true; }
    busy_wait_ns(g_base_latency_ns);
    // TODO: 原有键查找 / 写入 / 验证逻辑
    return Status::OK();
}