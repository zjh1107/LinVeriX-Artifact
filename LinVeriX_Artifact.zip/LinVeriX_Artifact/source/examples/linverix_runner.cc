#include <iostream>
#include <thread>
#include <chrono>
#include "linucb_controller.h"
#include "metrics_collector.h"
#include "merklesum_tree.h"
#include "linverix_ctx_utils.h"  

struct FakeDB {
  std::vector<SegmentStats> stats;
  mks::MerkleSum mst;
  FakeDB(){
    const int segments = 8;
    stats.resize(segments);
    for (int i=0;i<segments;++i){
      stats[i].seg_id=i; stats[i].max_err=50; stats[i].qps=1e5/(i+1); stats[i].mean_read_ms=10+i;
      stats[i].write_ratio=0.1*(i%3); stats[i].size_mb=50; stats[i].est_cost_ms=80; stats[i].last_retrain_sec=60*i;
    }
    std::vector<std::pair<uint64_t,uint64_t>> leaves; leaves.reserve(100000);
    for (uint64_t k=1;k<=100000;++k) leaves.emplace_back(k, 1);
    mst.build(leaves);
  }
  void retrain_segment(int seg){
    double old_mean_read_ms = stats[seg].mean_read_ms;
    double old_err = stats[seg].max_err;
    std::this_thread::sleep_for(std::chrono::milliseconds(30)); // 模拟成本
    stats[seg].mean_read_ms = std::max(1.0, old_mean_read_ms - 2.0);
    stats[seg].max_err = std::max(0.0, old_err - 5.0);
    stats[seg].last_retrain_sec = 0.0;
  }
};

int main(){
  FakeDB db;
  // 使用 metrics_collector.h 提供的 make_context 来确定特征维度
  LinUCBController::Config cfg; cfg.d=(int)make_context(db.stats[0]).size(); cfg.budget_B=3; cfg.alpha=1.0;
  LinUCBController ctrl(cfg);

  // 运行3个epoch
  for (int epoch=0; epoch<3; ++epoch){
    // 1) 由 metrics_collector.h 提供的 contexts_from_stats 得到 {seg_id -> x}
    auto feat_map = contexts_from_stats(db.stats);
    // 2) 适配为 vector<ArmContext>，并带上每段估计成本（从 db.stats 取）
    auto ctxs = build_arm_contexts_from_map(feat_map, db.stats, /*default_cost_ms=*/80.0);
    // 3) 选择 top-B
    auto pick = ctrl.selectTopB(ctxs);

    for (int seg : pick){
      double p99_before = db.stats[seg].mean_read_ms;
      double err_before = db.stats[seg].max_err;
      auto t0 = std::chrono::high_resolution_clock::now();
      db.retrain_segment(seg);
      auto t1 = std::chrono::high_resolution_clock::now();
      double cost_ms = std::chrono::duration<double,std::milli>(t1-t0).count();

      // compose_reward 已在 metrics_collector.h 定义：传入“新-旧”的差值
      double reward = compose_reward(db.stats[seg].mean_read_ms - p99_before,
                                     db.stats[seg].max_err - err_before, cost_ms);
      ctrl.observeReward(seg, reward);
    }
    std::cout << "Epoch " << epoch << " picked:";
    for (int s: pick) std::cout << " " << s;
    std::cout << "\n";
  }

  // 范围 SUM 证明/验证
  uint64_t l=100, r=9999;
  auto proof = db.mst.range_proof(l, r);
  uint64_t sum = db.mst.range_sum(l, r); // O(log n)
  bool ok = db.mst.verify(proof, db.mst.root_hash());
  std::cout << "RangeSum ["<<l<<","<<r<<"] = " << sum
            << ", proof_ok=" << std::boolalpha << ok << "\n";
  return 0;
}