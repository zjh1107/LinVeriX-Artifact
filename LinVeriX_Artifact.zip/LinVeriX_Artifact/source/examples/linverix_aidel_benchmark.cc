#include <iostream>
#include <pthread.h>
#include <atomic>
#include <vector>
#include <random>
#include <chrono>
#include <mutex>
#include <shared_mutex>
#include <unordered_set>
#include <algorithm>
#include <unordered_map>
#include <sstream>
#include <iomanip>
#include <unistd.h>
#include <cmath>
#include <fstream>
#include <filesystem>
#include <cstring>
#include <cstdlib>
#include <memory>
#include <map>
#include <optional>
#include <thread>
#include <limits>
#include <stdexcept>

#include "function.h"
#include "aidel.h"
#include "aidel_impl.h"
#include "linverix_adapter.h"
#include "linverix_runtime.h"
#include "metrics_collector.h"
#include "merklesum_tree.h"
#include "verify_service.h"
#include "aidel_metrics.h"
#include "p99_sampler.h"
#include "util/busy_wait.h"
#include "util/CsvLogger.h"
#include "config/base_latency.h"

#ifndef CACHELINE_SIZE
#define CACHELINE_SIZE 64
#endif

using aidel_type = aidel::AIDEL<key_type, val_type>;
// Foreground reads, writes, and publication of a replacement share one lock.
// A published model is a complete snapshot of its segment at one generation.
static std::shared_mutex g_aidel_crud_mu;
static bool g_measured_feedback = false;
static std::chrono::steady_clock::time_point g_workload_started;
static int g_write_warmup_sec = 20;
static int g_active_window_id = 0;
static thread_local const char *g_active_maintenance_phase = "baseline";
static std::atomic<uint64_t> g_maintenance_event_sequence{0};
#ifdef ROUTE_TEST_HOOKS
static std::atomic<bool> g_route_test_pre_publish{false};
static std::atomic<bool> g_route_test_release_publish{true};
#endif

struct ClaimsScenario
{
  struct Bucket
  {
    int count;
    uint32_t extra_ns;
  };
  std::vector<Bucket> longtail;
  bool enable_midlate = false;
  int K_start = 0, K_mid = 0, K_late = 0;
  double mid_time_s = 0.0, late_time_s = 0.0;
  int mid_global_sec = -1, late_global_sec = -1;
  bool mid_injected = false, late_injected = false;
  bool tail_enable = false;
  double tail_retention_factor = 0.2;
  double tail_decay_us = 10.0;
  bool disable_topk = false;
  bool disable_avoid = false;
  bool fair_static = false;
  bool greedy_static = false;
  bool static_dp = false;
  bool static_dp_limited = false;
    bool periodic_static = false;
    bool threshold_static = false;
  double proof_rate_override = -1.0;
  int proof_batch_override = -1;
  bool active() const
  {
    return !longtail.empty() || enable_midlate || tail_enable ||
           disable_topk || disable_avoid || fair_static || greedy_static ||
           static_dp || static_dp_limited ||
           proof_rate_override >= 0.0 || K_start > 0 || K_mid > 0 || K_late > 0;
  }
} gScenario;

static thread_local bool g_in_linucb_midwindow = false;
static bool g_drift_enabled = true;
static std::unordered_set<int> g_retrained_segments_this_window;

static bool g_flag_single_phase = false;
static bool g_flag_disable_runtime = false;
static bool g_flag_disable_adapt = false;
static bool g_flag_use_max_only = false;
static bool g_flag_select_random = false;
static bool g_flag_no_phase2 = false;
static bool g_flag_output_debug = false;

static const char *active_policy_name()
{
  if (gScenario.greedy_static) return "greedy";
  if (gScenario.static_dp_limited) return "staticdp_limited";
  if (gScenario.static_dp) return "staticdp";
  if (gScenario.periodic_static) return "periodic";
  if (gScenario.threshold_static) return "threshold";
  if (g_flag_single_phase) return "greedy";
  if (Config.policy == "naive") return "naive";
  if (Config.policy == "off") return "off";
  return "linverix";
}

static const char *active_maintenance_reason()
{
  if (std::string(g_active_maintenance_phase) == "phase1") return "contextual_exploration";
  if (std::string(g_active_maintenance_phase) == "phase2") return "residual_relative_cost_repair";
  if (gScenario.periodic_static) return "maintenance_age_desc";
  if (gScenario.static_dp || gScenario.static_dp_limited) return "residual_cost_knapsack";
  if (gScenario.greedy_static || g_flag_single_phase) return "residual_cost_greedy";
  return "baseline_policy";
}

static bool g_dbg_master = false;
static bool g_dbg_phase1 = false;
static bool g_dbg_phase2 = false;

struct SegmentFeedbackCursor
{
  uint64_t model_version = 0;
  int window_id = 0;
  double read_ns = 0.0;
  uint64_t read_count = 0;
  uint64_t correction_steps = 0;
  uint64_t correction_queries = 0;
  uint64_t latency_samples = 0;
  std::vector<uint64_t> latency_hist;
};

struct SegmentFeedbackWindow
{
  int window_id = 0;
  double read_ns = 0.0;
  uint64_t read_count = 0;
  uint64_t correction_steps = 0;
  uint64_t correction_queries = 0;
  uint64_t latency_samples = 0;
  std::vector<uint64_t> latency_hist;
};

static uint64_t g_phase2_total_repairs = 0;
static uint64_t g_phase2_redundant_repairs = 0;

static std::vector<int> g_start_injected_segments;
static std::vector<int> g_mid_injected_segments;
static std::vector<int> g_late_injected_segments;

struct WindowAgg
{
  uint64_t proof_gen_ns_sum = 0;
  uint64_t proof_ver_ns_sum = 0;
  uint64_t proof_cnt = 0;
  uint64_t proof_fail = 0;
  uint64_t retrain_cnt = 0;
  double retrain_cost_ms_sum = 0.0;
    std::vector<double> retrain_cost_ms_samples;
  void reset()
  {
    proof_gen_ns_sum = proof_ver_ns_sum = proof_cnt = proof_fail = 0;
    retrain_cnt = 0;
    retrain_cost_ms_sum = 0.0;
        retrain_cost_ms_samples.clear();
  }
} g_win;
struct CorrectionCoverage
{
  uint64_t min_queries = 0;
  double min_comparisons_per_query = 0.0;
};
static double last_proof_gen_us = 0.0;
static double last_proof_ver_us = 0.0;

static inline bool env_on(const char *k)
{
  if (const char *v = getenv(k))
    return (*v == 0) || strcmp(v, "0") != 0;
  return false;
}
static inline bool use_correction_excess_signal()
{
  const char *mode = getenv("DRIFT_SIGNAL_MODE");
  return mode && std::string(mode) == "correction_excess";
}
static inline void init_avoid_debug_flags()
{
  bool trace = env_on("SHOW_AVOID_TRACE");
  bool dbg = env_on("SHOW_AVOID_DEBUG");
  bool p1 = env_on("SHOW_AVOID_PHASE1");
  bool p2 = env_on("SHOW_AVOID_PHASE2");
  g_dbg_master = trace || dbg;
  g_dbg_phase1 = g_dbg_master || p1;
  g_dbg_phase2 = g_dbg_master || p2;
}
static inline void dbg_p1(const std::string &s)
{
  if (g_dbg_phase1)
    std::cerr << s << "\n";
}
static inline void dbg_p2(const std::string &s)
{
  if (g_dbg_phase2)
    std::cerr << s << "\n";
}

static void detect_drift_enabled_once()
{
  auto gl = [](const char *k, long long d) -> long long
  {
    if (const char *v = getenv(k))
    {
      try
      {
        return std::stoll(v);
      }
      catch (...)
      {
      }
    }
    return d;
  };
  long long interval = gl("DRIFT_INTERVAL_SEC", 0);
  long long K = gl("DRIFT_K", 0);
  long long lat = gl("DRIFT_LAT_NS_PER_SEG", 0);
  long long p99 = gl("DRIFT_P99_MS", 0);
  long long err = gl("DRIFT_ERR", 0);
  bool periodic = (interval > 0) && (K > 0 || lat > 0 || p99 > 0 || err > 0);
  bool staged = (!gScenario.longtail.empty()) || gScenario.K_start > 0 ||
                gScenario.K_mid > 0 || gScenario.K_late > 0 || gScenario.enable_midlate ||
                gScenario.tail_enable;
  g_drift_enabled = g_measured_feedback || periodic || staged;
  std::cerr << "[init] drift_enabled=" << g_drift_enabled
            << " measured_feedback=" << g_measured_feedback
            << " periodic=" << periodic
            << " staged=" << staged << "\n";
}

class AidelAdapter : public IIndexAdapter
{
public:
  explicit AidelAdapter(aidel_type *ai, const std::vector<key_type> &keys, size_t segments = 256)
      : ai_(ai), segments_(segments), keys_snapshot_(keys)
  {
    if (segments_ == 0)
      throw std::invalid_argument("segments must be greater than zero");
    segment_keys_.resize(segments_);
    segment_vals_.resize(segments_);
    installed_segment_models_.resize(segments_);
    model_versions_.assign(segments_, 0);
    prediction_bias_keys_.assign(segments_, 0);
    live_values_.resize(segments_);
    if (keys_snapshot_.empty())
      throw std::invalid_argument("cannot partition an empty index");
    if (!std::is_sorted(keys_snapshot_.begin(), keys_snapshot_.end()))
      throw std::invalid_argument("training keys must be sorted");
    // Stable quantile boundaries define contiguous key ranges. Insertions use
    // these same boundaries rather than rehashing an unrelated key cohort.
    segment_boundaries_.reserve(segments_ - 1);
    for (size_t s = 1; s < segments_; ++s)
    {
      const size_t pos = std::min(keys_snapshot_.size() - 1,
                                 s * keys_snapshot_.size() / segments_);
      segment_boundaries_.push_back(keys_snapshot_[pos]);
    }
    generations_.resize(segments_, 0);
    clean_generations_.resize(segments_, 0);
    deltas_.resize(segments_);
    overlay_exceeded_.assign(segments_, false);
    base_read_ns_.assign(segments_, 0.0);
    base_read_count_.assign(segments_, 0);
    window_read_ns_.assign(segments_, 0.0);
    window_read_count_.assign(segments_, 0);
    completed_read_ns_.assign(segments_, 0.0);
    completed_read_count_.assign(segments_, 0);
    cumulative_read_count_.assign(segments_, 0);
    completed_correction_steps_.assign(segments_, 0);
    completed_correction_queries_.assign(segments_, 0);
    clean_correction_steps_.assign(segments_, 0);
    clean_correction_queries_.assign(segments_, 0);
    clean_correction_window_.assign(segments_, -1);
    observed_residual_.assign(segments_, 0.0);
    segment_correction_steps_.reset(new std::atomic<uint64_t>[segments_]);
    segment_correction_queries_.reset(new std::atomic<uint64_t>[segments_]);
    model_route_hits_.reset(new std::atomic<uint64_t>[segments_]);
    segment_latency_hist_.reset(new std::atomic<uint64_t>[segments_ * kLatencyBuckets]);
    completed_latency_hist_.assign(segments_ * kLatencyBuckets, 0);
    clean_latency_hist_.assign(segments_ * kLatencyBuckets, 0);
    completed_latency_samples_.assign(segments_, 0);
    clean_latency_samples_.assign(segments_, 0);
    for (size_t s = 0; s < segments_; ++s)
    {
      segment_correction_steps_[s].store(0, std::memory_order_relaxed);
      segment_correction_queries_[s].store(0, std::memory_order_relaxed);
      model_route_hits_[s].store(0, std::memory_order_relaxed);
      for (size_t b = 0; b < kLatencyBuckets; ++b)
        segment_latency_hist_[s * kLatencyBuckets + b].store(0, std::memory_order_relaxed);
    }
    for (const auto &k : keys_snapshot_)
    {
      const size_t s = segment_of_key_(k);
      segment_keys_[s].push_back(k);
      segment_vals_[s].push_back(static_cast<val_type>(k));
      live_values_[s][k] = static_cast<val_type>(k);
    }
    std::vector<std::pair<uint64_t, uint64_t>> kv;
    if (Config.verify_layer == "merklesum" && Config.proof_rate > 0.0)
    {
      kv.reserve(keys.size());
      for (const auto &k : keys)
        kv.emplace_back(static_cast<uint64_t>(k), static_cast<uint64_t>(k));
    }
    mst_.build(kv);
    stats_.resize(segments_);
    ema_mean_read_ms_.assign(segments_, 5.0);
    max_err_.assign(segments_, g_measured_feedback ? 0.0 : 50.0);
    qps_.assign(segments_, 0.0);
    write_ratio_.assign(segments_, g_measured_feedback ? 0.0 : 0.1);
    size_mb_.assign(segments_, 0.0);
    last_rt_sec_.assign(segments_, 60.0);
    maintenance_age_sec_.assign(segments_, 60.0);
    est_cost_ms_.assign(segments_, 0.001);
    for (size_t s = 0; s < segments_; ++s)
    {
      size_mb_[s] = std::max(1e-6,
          segment_keys_[s].size() * (sizeof(key_type) + sizeof(val_type)) /
              (1024.0 * 1024.0));
      // Initial estimate is proportional to actual training-set size; it is
      // replaced by measured wall-clock training cost after the first repair.
      est_cost_ms_[s] = std::max(0.001, segment_keys_[s].size() * 0.0001);
    }
    // Publish the same initial per-segment models before any measured window.
    // Otherwise the first scheduled maintenance would conflate repairing a
    // segment with deploying its first foreground model.
    for (size_t s = 0; s < segments_; ++s)
    {
      if (segment_keys_[s].empty())
        continue;
      auto initial = std::make_unique<aidel_type>();
      initial->train(segment_keys_[s], segment_vals_[s], Config.maxErr);
      installed_segment_models_[s] = std::move(initial);
      model_versions_[s] = 1;
    }
    drift_.assign(segments_, 0.0);
    last_drift_observed_.assign(segments_, 0.0);
    drift_slope_ema_.assign(segments_, 0.0);
    seg_extra_ns_.reset(new std::atomic<uint32_t>[segments_]);
    tail_active_.assign(segments_, 0);
    for (size_t i = 0; i < segments_; ++i)
      seg_extra_ns_[i].store(0, std::memory_order_relaxed);
    last_snapshot_ = std::chrono::steady_clock::now();
    for (size_t s = 0; s < segments_; ++s)
      stats_[s].seg_id = (int)s;
    if (const char *m = getenv("DRIFT_RESET_MODE"))
      if (std::string(m) == "never")
        drift_reset_mode_ = 1;
  }
  std::vector<SegmentStats> collect_all_stats() override
  {
    std::shared_lock<std::shared_mutex> crud_guard(g_aidel_crud_mu);
    std::lock_guard<std::mutex> lk(mu_);
    decay_qps_locked();
    if (gScenario.tail_enable && gScenario.tail_decay_us > 0)
    {
      uint32_t dec_ns = (uint32_t)(gScenario.tail_decay_us * 1000.0);
      for (size_t i = 0; i < segments_; ++i)
      {
        if (!tail_active_[i])
          continue;
        uint32_t cur = seg_extra_ns_[i].load(std::memory_order_relaxed);
        if (cur > dec_ns)
          seg_extra_ns_[i].store(cur - dec_ns, std::memory_order_relaxed);
        else
        {
          seg_extra_ns_[i].store(0, std::memory_order_relaxed);
          tail_active_[i] = 0;
        }
      }
    }
    for (size_t s = 0; s < segments_; ++s)
    {
      stats_[s].seg_id = (int)s;
      stats_[s].max_err = max_err_[s];
      const bool dirty = generations_[s] > clean_generations_[s];
      const double observed_read_ns = window_read_count_[s]
          ? window_read_ns_[s] / window_read_count_[s] : 0.0;
      // A measured candidate requires actual writes and enough queries both
      // before and after those writes. No invented repair benefit is assigned
      // when latency has not deteriorated relative to the read-only warm-up.
      double cur_drift = 0.0;
      if (use_correction_excess_signal())
      {
        // Calibrate from actual clean foreground queries during the declared
        // warm-up. The scheduler never reads the injected bias magnitude.
        int warmup_windows = 0;
        if (const char *v = getenv("DRIFT_WARMUP_WINDOWS"))
          warmup_windows = std::max(0, std::atoi(v));
        // g_active_window_id is one-based for the window currently being
        // scheduled. completed_* holds the immediately preceding window, so
        // the first completed warm-up window is index 0 (not 1).
        const int observed_window = std::max(0, g_active_window_id - 2);
        if (observed_window < warmup_windows &&
            completed_correction_queries_[s] >= 32 &&
            clean_correction_window_[s] != observed_window)
        {
          clean_correction_steps_[s] += completed_correction_steps_[s];
          clean_correction_queries_[s] += completed_correction_queries_[s];
          clean_correction_window_[s] = observed_window;
        }
        const double observed_steps_per_query = completed_correction_queries_[s]
            ? static_cast<double>(completed_correction_steps_[s]) /
                  completed_correction_queries_[s]
            : 0.0;
        const double clean_steps_per_query = clean_correction_queries_[s]
            ? static_cast<double>(clean_correction_steps_[s]) /
                  clean_correction_queries_[s]
            : 0.0;
        cur_drift = clean_correction_queries_[s] >= 32 &&
                    completed_correction_queries_[s] >= 32
            ? std::max(0.0, observed_steps_per_query - clean_steps_per_query)
            : 0.0;
      }
      else if (g_measured_feedback)
      {
        cur_drift = dirty && base_read_count_[s] >= 32 && window_read_count_[s] >= 32
            ? std::max(0.0, (observed_read_ns - base_read_ns_[s]) / 1000.0)
            : 0.0;
      }
      else
      {
        cur_drift = static_cast<double>(seg_extra_ns_[s].load(std::memory_order_relaxed)) / 1000.0;
      }
      observed_residual_[s] = cur_drift;
      const double delta = cur_drift - last_drift_observed_[s];
      // collect_all_stats() may be called several times in one window.  Keep
      // the most recent real change instead of overwriting the slope with 0.
      if (std::abs(delta) > 1e-9)
      {
        drift_slope_ema_[s] = 0.70 * drift_slope_ema_[s] + 0.30 * delta;
        last_drift_observed_[s] = cur_drift;
      }
      stats_[s].err_slope = drift_slope_ema_[s];
      stats_[s].qps = qps_[s];
      stats_[s].write_ratio = write_ratio_[s];
      stats_[s].mean_read_ms = completed_read_count_[s]
          ? completed_read_ns_[s] / completed_read_count_[s] / 1.0e6
          : ema_mean_read_ms_[s];
      stats_[s].correction_steps_per_query = completed_correction_queries_[s]
          ? static_cast<double>(completed_correction_steps_[s]) /
                completed_correction_queries_[s]
          : 0.0;
      stats_[s].correction_queries = completed_correction_queries_[s];
      const size_t latency_offset = s * kLatencyBuckets;
      auto p99_from_histogram = [](const std::vector<uint64_t> &hist, size_t offset,
                                   uint64_t samples) -> double
      {
        if (!samples) return 0.0;
        const uint64_t target = static_cast<uint64_t>(std::ceil(samples * 0.99));
        uint64_t seen = 0;
        for (size_t b = 0; b < kLatencyBuckets; ++b)
        {
          seen += hist[offset + b];
          if (seen >= target)
            return (static_cast<double>(b) + 0.5) * kLatencyBucketNs / 1.0e6;
        }
        return static_cast<double>(kLatencyBuckets) * kLatencyBucketNs / 1.0e6;
      };
      stats_[s].p99_read_ms = p99_from_histogram(
          completed_latency_hist_, latency_offset, completed_latency_samples_[s]);
      stats_[s].warmup_p99_read_ms = p99_from_histogram(
          clean_latency_hist_, latency_offset, clean_latency_samples_[s]);
      stats_[s].tail_latency_samples = completed_latency_samples_[s];
      stats_[s].warmup_tail_latency_samples = clean_latency_samples_[s];
      stats_[s].size_mb = size_mb_[s];
      stats_[s].last_retrain_sec = last_rt_sec_[s];
      stats_[s].maintenance_age_sec = maintenance_age_sec_[s];
      stats_[s].est_cost_ms = est_cost_ms_[s];
      stats_[s].drift = cur_drift;
    }
    return stats_;
  }
  void begin_observation_window()
  {
    std::lock_guard<std::mutex> lk(mu_);
    completed_window_id_ = g_active_window_id;
    completed_read_ns_ = window_read_ns_;
    completed_read_count_ = window_read_count_;
    for (size_t s = 0; s < segments_; ++s)
    {
      completed_correction_steps_[s] =
          segment_correction_steps_[s].exchange(0, std::memory_order_acq_rel);
      completed_correction_queries_[s] =
          segment_correction_queries_[s].exchange(0, std::memory_order_acq_rel);
      completed_latency_samples_[s] = 0;
      const size_t latency_offset = s * kLatencyBuckets;
      int warmup_windows = 0;
      if (const char *v = getenv("DRIFT_WARMUP_WINDOWS"))
        warmup_windows = std::max(0, std::atoi(v));
      const bool clean_warmup_window = g_active_window_id <= warmup_windows;
      for (size_t b = 0; b < kLatencyBuckets; ++b)
      {
        const uint64_t n = segment_latency_hist_[latency_offset + b].exchange(0, std::memory_order_acq_rel);
        completed_latency_hist_[latency_offset + b] = n;
        completed_latency_samples_[s] += n;
        if (clean_warmup_window)
          clean_latency_hist_[latency_offset + b] += n;
      }
      if (clean_warmup_window)
        clean_latency_samples_[s] += completed_latency_samples_[s];
    }
    std::fill(window_read_ns_.begin(), window_read_ns_.end(), 0.0);
    std::fill(window_read_count_.begin(), window_read_count_.end(), 0);
    window_biased_root_queries_.store(0, std::memory_order_relaxed);
    window_biased_root_steps_.store(0, std::memory_order_relaxed);
  }
  std::vector<double> current_correction_residuals() const
  {
    std::vector<uint64_t> clean_steps(segments_, 0), clean_queries(segments_, 0);
    {
      std::lock_guard<std::mutex> lk(mu_);
      clean_steps = clean_correction_steps_;
      clean_queries = clean_correction_queries_;
    }
    std::vector<double> residuals(segments_, 0.0);
    for (size_t s = 0; s < segments_; ++s)
    {
      const uint64_t queries = segment_correction_queries_[s].load(std::memory_order_relaxed);
      if (queries < 32 || clean_queries[s] < 32)
        continue;
      const uint64_t steps = segment_correction_steps_[s].load(std::memory_order_relaxed);
      const double current = static_cast<double>(steps) / queries;
      const double clean = static_cast<double>(clean_steps[s]) / clean_queries[s];
      residuals[s] = std::max(0.0, current - clean);
    }
    return residuals;
  }
  CorrectionCoverage current_correction_coverage() const
  {
    CorrectionCoverage coverage;
    uint64_t minimum_queries = std::numeric_limits<uint64_t>::max();
    double minimum_comparisons = std::numeric_limits<double>::infinity();
    for (size_t s = 0; s < segments_; ++s)
    {
      const uint64_t queries = segment_correction_queries_[s].load(std::memory_order_relaxed);
      const uint64_t comparisons = segment_correction_steps_[s].load(std::memory_order_relaxed);
      minimum_queries = std::min(minimum_queries, queries);
      if (queries > 0)
        minimum_comparisons = std::min(minimum_comparisons,
            static_cast<double>(comparisons) / static_cast<double>(queries));
    }
    coverage.min_queries = minimum_queries == std::numeric_limits<uint64_t>::max()
        ? 0 : minimum_queries;
    coverage.min_comparisons_per_query = std::isfinite(minimum_comparisons)
        ? minimum_comparisons : 0.0;
    return coverage;
  }
  uint64_t minimum_cumulative_read_observations() const
  {
    std::lock_guard<std::mutex> lk(mu_);
    uint64_t minimum_queries = std::numeric_limits<uint64_t>::max();
    for (uint64_t queries : cumulative_read_count_)
      minimum_queries = std::min(minimum_queries, queries);
    return minimum_queries == std::numeric_limits<uint64_t>::max()
        ? 0 : minimum_queries;
  }
  double biased_root_correction_steps_per_query() const
  {
    const uint64_t queries = window_biased_root_queries_.load(std::memory_order_relaxed);
    const uint64_t steps = window_biased_root_steps_.load(std::memory_order_relaxed);
    return queries ? static_cast<double>(steps) / queries : 0.0;
  }
  uint64_t max_prediction_bias_keys() const
  {
    std::lock_guard<std::mutex> lk(mu_);
    uint64_t maximum = 0;
    for (int64_t bias : prediction_bias_keys_)
    {
      const uint64_t magnitude = bias < 0
          ? static_cast<uint64_t>(-(bias + 1)) + 1
          : static_cast<uint64_t>(bias);
      maximum = std::max(maximum, magnitude);
    }
    return maximum;
  }
  SegmentFeedbackCursor snapshot_query_feedback(int seg) const
  {
    std::shared_lock<std::shared_mutex> crud_guard(g_aidel_crud_mu);
    std::lock_guard<std::mutex> lk(mu_);
    const size_t s = static_cast<size_t>(seg);
    SegmentFeedbackCursor cursor;
    cursor.model_version = model_versions_[s];
    cursor.window_id = g_active_window_id;
    cursor.read_ns = window_read_ns_[s];
    cursor.read_count = window_read_count_[s];
    cursor.correction_steps = segment_correction_steps_[s].load(std::memory_order_relaxed);
    cursor.correction_queries = segment_correction_queries_[s].load(std::memory_order_relaxed);
    cursor.latency_hist.resize(kLatencyBuckets);
    const size_t offset = s * kLatencyBuckets;
    for (size_t b = 0; b < kLatencyBuckets; ++b)
    {
      cursor.latency_hist[b] = segment_latency_hist_[offset + b].load(std::memory_order_relaxed);
      cursor.latency_samples += cursor.latency_hist[b];
    }
    return cursor;
  }
  bool published_query_window(int seg, const SegmentFeedbackCursor &cursor,
                              SegmentFeedbackWindow &out) const
  {
    std::shared_lock<std::shared_mutex> crud_guard(g_aidel_crud_mu);
    std::lock_guard<std::mutex> lk(mu_);
    const size_t s = static_cast<size_t>(seg);
    if (!installed_segment_models_[s] ||
        model_versions_[s] != cursor.model_version ||
        generations_[s] != clean_generations_[s] ||
        cursor.latency_hist.size() != kLatencyBuckets ||
        completed_window_id_ < cursor.window_id)
      return false;
    const bool same_window = completed_window_id_ == cursor.window_id;
    if (same_window && (completed_read_count_[s] < cursor.read_count ||
         completed_read_ns_[s] < cursor.read_ns ||
         completed_correction_queries_[s] < cursor.correction_queries ||
         completed_correction_steps_[s] < cursor.correction_steps ||
         completed_latency_samples_[s] < cursor.latency_samples))
      return false;
    out.window_id = completed_window_id_;
    out.read_ns = same_window
        ? completed_read_ns_[s] - cursor.read_ns : completed_read_ns_[s];
    out.read_count = same_window
        ? completed_read_count_[s] - cursor.read_count : completed_read_count_[s];
    out.correction_steps = same_window
        ? completed_correction_steps_[s] - cursor.correction_steps
        : completed_correction_steps_[s];
    out.correction_queries = same_window
        ? completed_correction_queries_[s] - cursor.correction_queries
        : completed_correction_queries_[s];
    out.latency_samples = same_window
        ? completed_latency_samples_[s] - cursor.latency_samples
        : completed_latency_samples_[s];
    out.latency_hist.assign(kLatencyBuckets, 0);
    const size_t offset = s * kLatencyBuckets;
    for (size_t b = 0; b < kLatencyBuckets; ++b)
    {
      if (same_window && completed_latency_hist_[offset + b] < cursor.latency_hist[b])
        return false;
      out.latency_hist[b] = same_window
          ? completed_latency_hist_[offset + b] - cursor.latency_hist[b]
          : completed_latency_hist_[offset + b];
    }
    return true;
  }
  void retrain_segment_async(int seg_id, RetrainDone cb) override
  {
    retrain_segment_impl(seg_id, std::move(cb), false);
  }

  // Execute a decision that was legitimately issued from the same pre-repair
  // window snapshot even if another phase has already repaired the segment.
  // This models the real wasted work exposed by the NoAvoid ablation.  Normal
  // LinVeriX never calls this path because its reservation set suppresses the
  // duplicate before execution.
  void retrain_segment_from_stale_decision(int seg_id, RetrainDone cb)
  {
    retrain_segment_impl(seg_id, std::move(cb), true);
  }

private:
  // Use a published per-segment learned index for foreground point queries.
  // All writers invalidate it while holding the exclusive CRUD lock.
public:
  result_t foreground_find(key_type key, val_type &value,
                           size_t *correction_comparisons = nullptr)
  {
    if (correction_comparisons)
      *correction_comparisons = 0;
    std::shared_lock<std::shared_mutex> guard(g_aidel_crud_mu);
    const size_t seg = segment_of_key_(key);
    if (installed_segment_models_[seg] && !overlay_exceeded_[seg])
    {
      const auto modified = deltas_[seg].find(key);
      result_t result;
      if (modified != deltas_[seg].end())
      {
        if (modified->second) value = *modified->second;
        result = modified->second ? Result::ok : Result::failed;
      }
      else
      {
        int64_t prediction_bias;
        {
          std::lock_guard<std::mutex> lk(mu_);
          prediction_bias = prediction_bias_keys_[seg];
        }
        size_t observed_comparisons = 0;
        result = installed_segment_models_[seg]->find_with_prediction_bias(
            key, value, prediction_bias, &observed_comparisons);
        if (correction_comparisons)
          *correction_comparisons = observed_comparisons;
        segment_correction_queries_[seg].fetch_add(1, std::memory_order_relaxed);
        segment_correction_steps_[seg].fetch_add(observed_comparisons,
                                                  std::memory_order_relaxed);
        window_biased_root_queries_.fetch_add(1, std::memory_order_relaxed);
        window_biased_root_steps_.fetch_add(observed_comparisons,
                                             std::memory_order_relaxed);
      }
      routed_reads_.fetch_add(1, std::memory_order_relaxed);
      model_route_hits_[seg].fetch_add(1, std::memory_order_relaxed);
      if (env_on("CHECK_ROUTED_READS"))
      {
        val_type reference{};
        result_t expected = ai_->find(key, reference);
        if (result != expected || (result == Result::ok && value != reference))
        {
          std::cerr << "[ROUTE_MISMATCH] key=" << key << " segment=" << seg << "\n";
          std::abort();
        }
        checked_reads_.fetch_add(1, std::memory_order_relaxed);
      }
      return result;
    }
    fallback_reads_.fetch_add(1, std::memory_order_relaxed);
    return ai_->find(key, value);
  }

  result_t foreground_write(key_type key, val_type value, int operation)
  {
    std::unique_lock<std::shared_mutex> guard(g_aidel_crud_mu);
    val_type before{};
    result_t was = ai_->find(key, before);
    result_t result = operation == 0 ? ai_->insert(key, value)
                    : operation == 1 ? ai_->update(key, value)
                                     : ai_->remove(key);
    const size_t seg = segment_of_key_(key);
    // Reconcile with the canonical index even if the requested mutation
    // failed (e.g. duplicate insert or missing delete).
    val_type actual{};
    result_t observed = ai_->find(key, actual);
    const bool changed = was != observed ||
        (was == Result::ok && observed == Result::ok && before != actual);
    if (!changed) return result;
    if (observed == Result::ok)
      live_values_[seg][key] = actual;
    else
      live_values_[seg].erase(key);
    ++generations_[seg];
    actual_writes_.fetch_add(1, std::memory_order_relaxed);
    if (installed_segment_models_[seg])
    {
      if (observed == Result::ok) deltas_[seg][key] = actual;
      else deltas_[seg][key] = std::nullopt;
      size_t limit = std::max<size_t>(256, live_values_[seg].size() / 10);
#ifdef ROUTE_TEST_HOOKS
      limit = 8;
#endif
      if (!overlay_exceeded_[seg] && deltas_[seg].size() > limit)
      {
        overlay_exceeded_[seg] = true;
        invalidated_models_.fetch_add(1, std::memory_order_relaxed);
      }
    }
    return result;
  }

  uint64_t routed_reads() const { return routed_reads_.load(std::memory_order_relaxed); }
  uint64_t fallback_reads() const { return fallback_reads_.load(std::memory_order_relaxed); }
  uint64_t checked_reads() const { return checked_reads_.load(std::memory_order_relaxed); }
  uint64_t invalidated_models() const { return invalidated_models_.load(std::memory_order_relaxed); }
  uint64_t rejected_publications() const { return rejected_publications_.load(std::memory_order_relaxed); }
  uint64_t actual_writes() const { return actual_writes_.load(std::memory_order_relaxed); }
  size_t segment_for_key(key_type key) const { return segment_of_key_(key); }
  void emit_current_model_routes(int window)
  {
    std::shared_lock<std::shared_mutex> guard(g_aidel_crud_mu);
    for (size_t s = 0; s < segments_; ++s)
    {
      const uint64_t hits = model_route_hits_[s].exchange(0, std::memory_order_acq_rel);
      std::lock_guard<std::mutex> lk(mu_);
      std::cout << "[MODEL_ROUTE] window=" << window << " segment=" << s
                << " model_version=" << model_versions_[s]
                << " query_count=" << hits << std::endl;
    }
  }

private:
  void retrain_segment_impl(int seg_id, RetrainDone cb, bool honor_stale_decision)
  {
    if (seg_id < 0 || static_cast<size_t>(seg_id) >= segments_)
    {
      std::cerr << "[REAL_RETRAIN] invalid segment id=" << seg_id << "\n";
      if (cb)
        cb(seg_id, 0.0, 0.0, 0.0);
      return;
    }
    uint64_t min_extra_ns = 1;
    if (const char *v = getenv("MIN_EXTRA_NS_FOR_RETRAIN"))
      min_extra_ns = strtoull(v, nullptr, 10);
    bool skip_costless = true;
    if (const char *v = getenv("SKIP_COSTLESS_RETRAIN"))
      skip_costless = (atoi(v) != 0);
    double cooldown_sec = 0.0;
    if (const char *v = getenv("RETRAIN_COOLDOWN_SEC"))
      cooldown_sec = atof(v);
    uint32_t extra = seg_extra_ns_[seg_id].load(std::memory_order_acquire);
    int64_t prediction_bias_before = 0;
    {
      std::shared_lock<std::shared_mutex> crud_guard(g_aidel_crud_mu);
      std::lock_guard<std::mutex> lk(mu_);
      prediction_bias_before = prediction_bias_keys_[static_cast<size_t>(seg_id)];
      bool cooldown_block = (cooldown_sec > 0 && last_rt_sec_[seg_id] < cooldown_sec);
      if (!honor_stale_decision && ((g_measured_feedback
          ? generations_[seg_id] <= clean_generations_[seg_id]
          : (use_correction_excess_signal() && !gScenario.periodic_static
                 ? observed_residual_[static_cast<size_t>(seg_id)] <= 0.0
                 : (!gScenario.periodic_static && extra < min_extra_ns))) || cooldown_block))
      {
        if (!skip_costless && !(g_flag_single_phase && Config.policy == "linucb"))
          g_win.retrain_cnt++;
        if (cb)
          cb(seg_id, 0.0, 0.0, 0.0);
        return;
      }
    }
    // ------------------------------------------------------------
    // Measured retraining cost using actual AIDEL training
    // ------------------------------------------------------------
    std::vector<key_type> retrain_keys;
    std::vector<val_type> retrain_vals;
    uint64_t start_generation;
    uint64_t model_version_before;
    {
      std::shared_lock<std::shared_mutex> guard(g_aidel_crud_mu);
      const size_t seg = static_cast<size_t>(seg_id);
      start_generation = generations_[seg];
      model_version_before = model_versions_[seg];
      retrain_keys.reserve(live_values_[seg].size());
      retrain_vals.reserve(live_values_[seg].size());
      for (const auto &entry : live_values_[seg])
      {
        retrain_keys.push_back(entry.first);
        retrain_vals.push_back(entry.second);
      }
    }

    double cost_ms_measured = 0.0;

    if (!retrain_keys.empty())
    {
        const auto t0 = std::chrono::steady_clock::now();
        std::unique_ptr<aidel_type> replacement;
        try
        {
          replacement = std::make_unique<aidel_type>();
          replacement->train(retrain_keys, retrain_vals, Config.maxErr);
        }
        catch (const std::exception &)
        {
          const auto t1 = std::chrono::steady_clock::now();
          cost_ms_measured = std::chrono::duration<double, std::milli>(t1 - t0).count();
          g_win.retrain_cnt++;
          g_win.retrain_cost_ms_sum += cost_ms_measured;
          g_win.retrain_cost_ms_samples.push_back(cost_ms_measured);
          std::cout << "[MAINT_EVENT] event_id=" << g_maintenance_event_sequence.fetch_add(1, std::memory_order_relaxed)
                    << " decision_id=" << active_policy_name() << "_w" << g_active_window_id << "_" << g_active_maintenance_phase
                    << " window=" << g_active_window_id << " policy=" << active_policy_name()
                    << " segment=" << seg_id << " phase=" << g_active_maintenance_phase
                    << " reason=" << active_maintenance_reason()
                    << " generation_before=" << start_generation << " model_version_before=" << model_version_before
                    << " model_version_after=" << model_version_before
                    << " status=training_failed keys=" << retrain_keys.size()
                    << " cost_ms=" << cost_ms_measured << std::endl;
          if (cb) cb(seg_id, 0.0, 0.0, cost_ms_measured);
          return;
        }
        const auto t1 = std::chrono::steady_clock::now();

        cost_ms_measured =
            std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::cout << "[REAL_RETRAIN] seg=" << seg_id
                  << " keys=" << retrain_keys.size()
                  << " cost_ms=" << cost_ms_measured
                  << std::endl;

#ifdef ROUTE_TEST_HOOKS
        if (!g_route_test_release_publish.load(std::memory_order_acquire))
        {
          g_route_test_pre_publish.store(true, std::memory_order_release);
          while (!g_route_test_release_publish.load(std::memory_order_acquire))
            std::this_thread::yield();
        }
#endif

        // Publish only a successfully trained replacement. Foreground reads
        // route to this segment model after publication; the monolithic AIDEL
        // instance remains the canonical data index and correctness reference.
        {
          std::unique_lock<std::shared_mutex> publication(g_aidel_crud_mu);
          if (generations_[static_cast<size_t>(seg_id)] != start_generation)
          {
            rejected_publications_.fetch_add(1, std::memory_order_relaxed);
            g_win.retrain_cnt++;
            g_win.retrain_cost_ms_sum += cost_ms_measured;
            g_win.retrain_cost_ms_samples.push_back(cost_ms_measured);
            int64_t prediction_bias_after;
            {
              std::lock_guard<std::mutex> lk(mu_);
              prediction_bias_after = prediction_bias_keys_[static_cast<size_t>(seg_id)];
            }
            std::cout << "[MAINT_EVENT] event_id=" << g_maintenance_event_sequence.fetch_add(1, std::memory_order_relaxed)
                      << " decision_id=" << active_policy_name() << "_w" << g_active_window_id << "_" << g_active_maintenance_phase
                      << " window=" << g_active_window_id << " policy=" << active_policy_name()
                      << " segment=" << seg_id << " phase=" << g_active_maintenance_phase
                      << " reason=" << active_maintenance_reason()
                      << " generation_before=" << start_generation << " model_version_before=" << model_version_before
                      << " model_version_after=" << model_versions_[static_cast<size_t>(seg_id)]
                      << " status=rejected_stale keys=" << retrain_keys.size()
                      << " cost_ms=" << cost_ms_measured
                      << " prediction_bias_before_keys=" << prediction_bias_before
                      << " prediction_bias_after_keys=" << prediction_bias_after
                      << std::endl;
            if (cb) cb(seg_id, 0.0, 0.0, cost_ms_measured);
            return;
          }
          const uint64_t old_version = model_versions_[static_cast<size_t>(seg_id)];
          const uint64_t old_route_hits = model_route_hits_[static_cast<size_t>(seg_id)].exchange(0, std::memory_order_acq_rel);
          std::cout << "[MODEL_ROUTE] window=" << g_active_window_id << " segment=" << seg_id
                    << " model_version=" << old_version << " query_count=" << old_route_hits << std::endl;
          std::lock_guard<std::mutex> lk(mu_);
          installed_segment_models_[static_cast<size_t>(seg_id)] = std::move(replacement);
          model_versions_[static_cast<size_t>(seg_id)] = old_version + 1;
          clean_generations_[seg_id] = generations_[seg_id];
          deltas_[seg_id].clear();
          overlay_exceeded_[seg_id] = false;
          prediction_bias_keys_[static_cast<size_t>(seg_id)] = 0;
          if (!g_measured_feedback)
          {
            ema_mean_read_ms_[seg_id] = std::max(0.5, ema_mean_read_ms_[seg_id] - 1.5);
            max_err_[seg_id] = std::max(0.0, max_err_[seg_id] - 3.0);
          }
          last_rt_sec_[seg_id] = 0.0;
          maintenance_age_sec_[seg_id] = 0.0;
          if (gScenario.tail_enable)
          {
            uint64_t nv = static_cast<uint64_t>(extra * gScenario.tail_retention_factor);
            seg_extra_ns_[seg_id].store(static_cast<uint32_t>(std::max<uint64_t>(1000, nv)),
                                        std::memory_order_release);
            tail_active_[seg_id] = 1;
          }
          else if (drift_reset_mode_ == 0)
          {
            seg_extra_ns_[seg_id].store(0, std::memory_order_release);
            tail_active_[seg_id] = 0;
          }
          // Real retraining is synchronous here, so prefer the latest wall
          // clock observation.  A 0.8 old-value weight left estimates near
          // their synthetic size prior for most of a short online run.
          est_cost_ms_[seg_id] = 0.30 * est_cost_ms_[seg_id] +
                                 0.70 * std::max(0.001, cost_ms_measured);
        }
        std::cout << "[MAINT_EVENT] event_id=" << g_maintenance_event_sequence.fetch_add(1, std::memory_order_relaxed)
                  << " decision_id=" << active_policy_name() << "_w" << g_active_window_id << "_" << g_active_maintenance_phase
                  << " window=" << g_active_window_id << " policy=" << active_policy_name()
                  << " segment=" << seg_id << " phase=" << g_active_maintenance_phase
                  << " reason=" << active_maintenance_reason()
                  << " generation_before=" << start_generation << " model_version_before=" << model_version_before
                  << " model_version_after=" << model_versions_[static_cast<size_t>(seg_id)]
                  << " status=published keys=" << retrain_keys.size()
                  << " cost_ms=" << cost_ms_measured
                  << " prediction_bias_before_keys=" << prediction_bias_before
                  << " prediction_bias_after_keys=0" << std::endl;
    }
    else
    {
      std::cerr << "[REAL_RETRAIN] segment " << seg_id << " contains no training keys\n";
      if (cb)
        cb(seg_id, 0.0, 0.0, 0.0);
      return;
    }
    if (!(g_flag_single_phase && Config.policy == "linucb" && g_in_linucb_midwindow))
      g_win.retrain_cnt++;
    g_win.retrain_cost_ms_sum += cost_ms_measured;
        g_win.retrain_cost_ms_samples.push_back(cost_ms_measured);
    if (cb)
      cb(seg_id, g_measured_feedback ? -1.0 : -1.5,
         g_measured_feedback ? 0.0 : -3.0, cost_ms_measured);
  }

public:
  void mst_build_if_needed() override {}
  void mst_update_by_key(uint64_t key, uint64_t value) override
  {
    std::lock_guard<std::mutex> lk(mu_);
    mst_.update_by_key(key, value);
  }
  RangeProof mst_range_proof(uint64_t l, uint64_t r) override
  {
    std::lock_guard<std::mutex> lk(mu_);
    return mst_.range_proof(l, r);
  }
  uint64_t mst_root_hash() const override
  {
    std::lock_guard<std::mutex> lk(mu_);
    return mst_.root_hash();
  }
  void note_operation(key_type k, double lat, bool is_write)
  {
    size_t seg = segment_of_key_(k);
    std::lock_guard<std::mutex> lk(mu_);
    qps_[seg] += 1.0;
    ema_mean_read_ms_[seg] = 0.95 * ema_mean_read_ms_[seg] + 0.05 * lat;
    if (is_write)
      write_ratio_[seg] = std::min(1.0, write_ratio_[seg] + 0.002);
    else
    {
      const double ns = lat * 1.0e6;
      // The read-only warm-up supplies a per-segment reference before writes.
      const double elapsed = std::chrono::duration<double>(
          std::chrono::steady_clock::now() - g_workload_started).count();
      if (elapsed < g_write_warmup_sec && base_read_count_[seg] < 512)
      {
        ++base_read_count_[seg];
        base_read_ns_[seg] += (ns - base_read_ns_[seg]) / base_read_count_[seg];
      }
      ++window_read_count_[seg];
      ++cumulative_read_count_[seg];
      window_read_ns_[seg] += ns;
    }
    last_rt_sec_[seg] += 0.001;
  }
  void note_sampled_latency(key_type k, uint32_t latency_ns)
  {
    const size_t seg = segment_of_key_(k);
    const size_t bucket = std::min<size_t>(kLatencyBuckets - 1,
        static_cast<size_t>(latency_ns / kLatencyBucketNs));
    segment_latency_hist_[seg * kLatencyBuckets + bucket].fetch_add(1, std::memory_order_relaxed);
  }
  
  // 修改注入漂移函数，使得每个segment的漂移不同
void inject_latency_drift(size_t K, uint32_t add_ns) {
    if (!segments_ || !K || !add_ns)
        return;

    const bool temporal = getenv("DRIFT_TEMPORAL_HETERO") &&
                          atoi(getenv("DRIFT_TEMPORAL_HETERO")) != 0;
    if (temporal) {
        if (temporal_ids_.empty()) {
            temporal_ids_.resize(segments_);
            for (size_t i = 0; i < segments_; ++i) temporal_ids_[i] = (int)i;
            std::mt19937_64 cohort_rng{
                static_cast<uint64_t>(Config.seed) ^ 0x74656d706f72616cULL};
            std::shuffle(temporal_ids_.begin(), temporal_ids_.end(), cohort_rng);
        }
        // A fixed seed-derived cohort contains rising, steady, decaying,
        // bursty, and low-background segments. Drift persists until an actual
        // repair resets it, so cross-window prediction can matter.
        const size_t active = std::min(segments_, std::max<size_t>(K, 2 * K));
        const size_t phase = temporal_tick_ % 6;
        const uint64_t cap_ns = getenv("DRIFT_CAP_NS")
            ? std::max<uint64_t>(add_ns,
                strtoull(getenv("DRIFT_CAP_NS"), nullptr, 10))
            : 2000000ULL;
        std::lock_guard<std::mutex> lk(mu_);
        for (size_t i = 0; i < active; ++i) {
            double scale = 0.25;
            if (i < 2) scale = 0.45 + 0.18 * phase;
            else if (i < 4) scale = 1.00;
            else if (i < 6) scale = 1.35 - 0.18 * phase;
            else if (i < 8) scale = (temporal_tick_ % 4 == 0) ? 2.00 : 0.10;
            const uint64_t inc = static_cast<uint64_t>(
                add_ns * std::max(0.10, scale));
            const int id = temporal_ids_[i];
            const uint64_t oldv =
                seg_extra_ns_[id].load(std::memory_order_relaxed);
            seg_extra_ns_[id].store(
                static_cast<uint32_t>(std::min(cap_ns, oldv + inc)),
                std::memory_order_relaxed);
            add_prediction_bias_locked(id, prediction_bias_increment(scale));
        }
        ++temporal_tick_;
        return;
    }

    std::vector<int> ids(segments_);
    for (size_t i = 0; i < segments_; ++i)
        ids[i] = (int)i;

    thread_local std::mt19937_64 rng{static_cast<uint64_t>(Config.seed) ^ 0x876543210ULL};
    std::shuffle(ids.begin(), ids.end(), rng);

    size_t use = std::min(K, (size_t)segments_);
    std::lock_guard<std::mutex> lk(mu_);

    // Controlled-window mode: each window is a fresh shock instead of adding
    // synthetic delay forever until every segment reaches the 500 us cap.
    const bool no_accum = getenv("DRIFT_NO_ACCUM") && atoi(getenv("DRIFT_NO_ACCUM")) != 0;
    const bool heterogeneous = getenv("DRIFT_HETERO") && atoi(getenv("DRIFT_HETERO")) != 0;
    if (no_accum) {
        for (size_t s = 0; s < segments_; ++s) {
            seg_extra_ns_[s].store(0, std::memory_order_relaxed);
            tail_active_[s] = 0;
            prediction_bias_keys_[s] = 0;
        }
    }
    
    // 随机为每个segment注入不同幅度的漂移
    for (size_t i = 0; i < use; ++i) {
        int id = ids[i];
        
        // A deterministic amplitude ladder preserves real heterogeneity across
        // windows and seeds without converging all arms to the same cap.
        static const double scale[] = {2.00, 1.75, 1.50, 1.25, 1.00, 0.80, 0.65, 0.50};
        uint32_t random_drift = heterogeneous
            ? static_cast<uint32_t>(add_ns * scale[i % (sizeof(scale) / sizeof(scale[0]))])
            : add_ns;
        uint32_t oldv = seg_extra_ns_[id].load(std::memory_order_relaxed);
        uint64_t merged = (uint64_t)oldv + random_drift;

        const uint64_t cap_ns = getenv("DRIFT_CAP_NS")
            ? std::max<uint64_t>(add_ns,
                strtoull(getenv("DRIFT_CAP_NS"), nullptr, 10))
            : 500000ULL;
        if (merged > cap_ns)
            merged = cap_ns;
        seg_extra_ns_[id].store((uint32_t)merged, std::memory_order_relaxed);
        add_prediction_bias_locked(id, prediction_bias_increment(
            heterogeneous ? scale[i % (sizeof(scale) / sizeof(scale[0]))] : 1.0));
    }
}

  std::vector<int> inject_latency_drift_return_ids(size_t K, uint32_t add_ns)
  {
    std::vector<int> chosen;
    if (!segments_ || !K || !add_ns)
      return chosen;
    size_t use = std::min(K, (size_t)segments_);
    const bool temporal = getenv("DRIFT_TEMPORAL_HETERO") &&
                          atoi(getenv("DRIFT_TEMPORAL_HETERO")) != 0;
    if (temporal)
    {
      if (temporal_ids_.empty())
      {
        temporal_ids_.resize(segments_);
        for (size_t i = 0; i < segments_; ++i) temporal_ids_[i] = (int)i;
        std::mt19937_64 cohort_rng{
            static_cast<uint64_t>(Config.seed) ^ 0x74656d706f72616cULL};
        std::shuffle(temporal_ids_.begin(), temporal_ids_.end(), cohort_rng);
      }
      chosen.assign(temporal_ids_.begin(), temporal_ids_.begin() + use);
    }
    else
    {
      std::vector<int> ids(segments_);
      for (size_t i = 0; i < segments_; ++i) ids[i] = (int)i;
      std::mt19937_64 rng{static_cast<uint64_t>(Config.seed) ^ 0xABCDEF555ULL};
      std::shuffle(ids.begin(), ids.end(), rng);
      chosen.assign(ids.begin(), ids.begin() + use);
    }
    {
      std::lock_guard<std::mutex> lk(mu_);
      for (size_t i = 0; i < chosen.size(); ++i)
      {
        const int id = chosen[i];
        uint32_t oldv = seg_extra_ns_[id].load(std::memory_order_relaxed);
        double scale = 1.0;
        if (temporal)
        {
          const size_t phase = temporal_tick_ % 6;
          if (i < 2) scale = 0.45 + 0.18 * phase;
          else if (i < 4) scale = 1.0;
          else if (i < 6) scale = 1.35 - 0.18 * phase;
          else if (i < 8) scale = (temporal_tick_ % 4 == 0) ? 2.0 : 0.10;
        }
        uint64_t merged = (uint64_t)oldv +
            static_cast<uint64_t>(add_ns * std::max(0.10, scale));
        if (merged > 500000)
          merged = 500000;
        seg_extra_ns_[id].store((uint32_t)merged, std::memory_order_relaxed);
        add_prediction_bias_locked(id, prediction_bias_increment(scale));
        if (!gScenario.tail_enable)
          tail_active_[id] = 0;
      }
    }
    if (temporal) ++temporal_tick_;
    return chosen;
  }
  void inject_longtail_pattern(const std::vector<ClaimsScenario::Bucket> &bs)
  {
    if (bs.empty())
      return;
    std::vector<int> pool(segments_);
    for (size_t i = 0; i < segments_; ++i)
      pool[i] = (int)i;
    static thread_local std::mt19937_64 rng{0x13579BDF1234ULL};
    std::shuffle(pool.begin(), pool.end(), rng);
    size_t off = 0;
    std::lock_guard<std::mutex> lk(mu_);
    for (auto &b : bs)
    {
      for (int j = 0; j < b.count && off < pool.size(); ++j, ++off)
      {
        int id = pool[off];
        uint32_t oldv = seg_extra_ns_[id].load(std::memory_order_relaxed);
        uint64_t merged = (uint64_t)oldv + b.extra_ns;
        if (merged > 500000)
          merged = 500000;
        seg_extra_ns_[id].store((uint32_t)merged, std::memory_order_relaxed);
        tail_active_[id] = 0;
      }
    }
  }
  uint32_t extra_latency_of_key(key_type k) const
  {
    if (!segments_)
      return 0;
    size_t seg = segment_of_key_(k);
    return seg_extra_ns_[seg].load(std::memory_order_relaxed);
  }
  size_t tail_active_count() const
  {
    size_t c = 0;
    for (auto f : tail_active_)
      if (f)
        ++c;
    return c;
  }

private:
  uint64_t prediction_bias_increment(double scale) const
  {
    uint64_t base = 512;
    if (const char *v = getenv("DRIFT_PREDICTION_BIAS_KEYS"))
      base = std::strtoull(v, nullptr, 10);
    if (!base)
      return 0;
    return static_cast<uint64_t>(std::max<long long>(1, std::llround(base * std::max(0.10, scale))));
  }
  void add_prediction_bias_locked(int seg_id, uint64_t increment)
  {
    const size_t seg = static_cast<size_t>(seg_id);
    uint64_t cap = 16384;
    if (const char *v = getenv("DRIFT_PREDICTION_BIAS_CAP_KEYS"))
      cap = std::strtoull(v, nullptr, 10);
    if (segment_keys_[seg].empty())
      return;
    cap = std::min<uint64_t>(cap, segment_keys_[seg].size() - 1);
    cap = std::min<uint64_t>(cap, static_cast<uint64_t>(std::numeric_limits<int64_t>::max()));
    const int64_t current = prediction_bias_keys_[seg];
    const uint64_t magnitude = current < 0
        ? static_cast<uint64_t>(-(current + 1)) + 1
        : static_cast<uint64_t>(current);
    const uint64_t applied = magnitude >= cap ? 0 : std::min(increment, cap - magnitude);
    if (!applied)
      return;
    const bool positive = ((static_cast<uint64_t>(Config.seed) + seg) & 1u) != 0;
    prediction_bias_keys_[seg] += positive
        ? static_cast<int64_t>(applied) : -static_cast<int64_t>(applied);
  }
  static inline uint64_t splitmix64(uint64_t x)
  {
    x += 0x9e3779b97f4a7c15ull;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ull;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebull;
    return x ^ (x >> 31);
  }
  size_t segment_of_key_(key_type k) const
  {
    return static_cast<size_t>(std::lower_bound(
        segment_boundaries_.begin(), segment_boundaries_.end(), k) - segment_boundaries_.begin());
  }
  void decay_qps_locked()
  {
    auto now = std::chrono::steady_clock::now();
    double sec = std::chrono::duration<double>(now - last_snapshot_).count();
    last_snapshot_ = now;
    double d = std::exp(-sec / 1.0);
    for (auto &v : qps_)
      v *= d;
    for (auto &t : last_rt_sec_)
      t += sec;
    for (auto &t : maintenance_age_sec_)
      t += sec;
  }
  aidel_type *ai_;
  size_t segments_;
  static constexpr size_t kLatencyBuckets = 256;
  static constexpr uint32_t kLatencyBucketNs = 500;

    // Snapshot of real keys for actual segment retraining
  std::vector<key_type> keys_snapshot_;
  std::vector<key_type> segment_boundaries_;
  std::vector<std::vector<key_type>> segment_keys_;
  std::vector<std::vector<val_type>> segment_vals_;
  std::vector<std::unique_ptr<aidel_type>> installed_segment_models_;
  std::vector<uint64_t> model_versions_; // guarded by g_aidel_crud_mu
  std::vector<int64_t> prediction_bias_keys_; // guarded by mu_
  std::vector<std::map<key_type, val_type>> live_values_; // canonical mirror, CRUD lock held
  std::vector<uint64_t> generations_; // guarded by g_aidel_crud_mu
  std::vector<uint64_t> clean_generations_;
  std::vector<std::unordered_map<key_type, std::optional<val_type>>> deltas_;
  std::vector<bool> overlay_exceeded_;
  std::vector<double> base_read_ns_, window_read_ns_;
  std::vector<uint64_t> base_read_count_, window_read_count_;
  std::vector<uint64_t> cumulative_read_count_;
  int completed_window_id_ = 0;
  std::vector<double> completed_read_ns_;
  std::vector<uint64_t> completed_read_count_;
  std::vector<uint64_t> completed_correction_steps_, completed_correction_queries_;
  std::vector<uint64_t> clean_correction_steps_, clean_correction_queries_;
  std::vector<int> clean_correction_window_;
  std::vector<double> observed_residual_;
  std::unique_ptr<std::atomic<uint64_t>[]> segment_correction_steps_;
  std::unique_ptr<std::atomic<uint64_t>[]> segment_correction_queries_;
  std::unique_ptr<std::atomic<uint64_t>[]> model_route_hits_;
  std::unique_ptr<std::atomic<uint64_t>[]> segment_latency_hist_;
  std::vector<uint64_t> completed_latency_hist_, clean_latency_hist_;
  std::vector<uint64_t> completed_latency_samples_, clean_latency_samples_;
  std::atomic<uint64_t> routed_reads_{0}, fallback_reads_{0}, checked_reads_{0};
  std::atomic<uint64_t> invalidated_models_{0}, rejected_publications_{0};
  std::atomic<uint64_t> actual_writes_{0};
  std::atomic<uint64_t> window_biased_root_queries_{0};
  std::atomic<uint64_t> window_biased_root_steps_{0};
  std::vector<SegmentStats> stats_;
  std::vector<double> ema_mean_read_ms_, max_err_, qps_, write_ratio_, size_mb_,
      last_rt_sec_, maintenance_age_sec_, est_cost_ms_, drift_;
  std::vector<double> last_drift_observed_, drift_slope_ema_;
  std::unique_ptr<std::atomic<uint32_t>[]> seg_extra_ns_;
  std::vector<uint8_t> tail_active_;
  std::vector<int> temporal_ids_;
  size_t temporal_tick_ = 0;
  int drift_reset_mode_ = 0;
  std::chrono::steady_clock::time_point last_snapshot_;
  mutable std::mutex mu_;
  mks::MerkleSum mst_;
};

template <typename T>
static double percentile(std::vector<T> &v, double q)
{
  if (v.empty())
    return 0;
  if (q < 0)
    q = 0;
  if (q > 1)
    q = 1;
  size_t k = (size_t)std::floor(q * (v.size() - 1));
  std::nth_element(v.begin(), v.begin() + k, v.end());
  return (double)v[k];
}
static double compute_topk_sum(AidelAdapter *adp, size_t K)
{
  auto st = adp->collect_all_stats();
  if (st.empty())
    return 0;
  if (g_flag_use_max_only)
  {
    double mx = 0;
    for (auto &s : st)
      mx = std::max(mx, s.drift);
    return mx;
  }
  if (K == 0)
    K = 1;
  std::vector<double> vals;
  vals.reserve(st.size());
  for (auto &s : st)
    vals.push_back(s.drift);
  std::sort(vals.begin(), vals.end(), std::greater<>());
  size_t use = std::min(vals.size(), (size_t)K);
  double sum = 0;
  for (size_t i = 0; i < use; ++i)
    sum += vals[i];
  return sum;
}

static ArmContext make_scheduler_arm(const SegmentStats &s)
{
  ArmContext a;
  a.arm_id = static_cast<uint32_t>(s.seg_id);
  a.x = {
      std::tanh(std::max(0.0, s.max_err) / 50.0),
      std::tanh(std::max(0.0, s.qps) / 50000.0),
      std::tanh(std::max(0.0, s.correction_steps_per_query) / 16.0),
      std::tanh(std::max(0.0, s.mean_read_ms) / 50.0),
      std::tanh(std::max(0.0, s.last_retrain_sec) / 60.0),
      std::tanh(std::max(0.0, s.est_cost_ms) / 100.0),
      std::tanh(std::max(0.0, s.err_slope) / 100.0),
      // s.drift is excess exact-correction comparisons/query in both the
      // controlled read-only experiment and the write-feedback path. Keep its
      // feature normalization in that unit; 2000 belonged to the retired
      // nanosecond drift signal and compressed all RQ1 residuals near zero.
      // RQ1 drift is measured in excess correction comparisons/query (unlike
      // RQ6's microseconds). Normalize in the RQ1 unit so ordinary residuals
      // retain ordering information without saturating the contextual feature.
      std::tanh(std::max(0.0, s.drift +
          0.75 * std::max(0.0, s.err_slope)) / 50.0)};
  if (s.tail_latency_samples >= 512 && s.warmup_tail_latency_samples >= 512 &&
      s.warmup_p99_read_ms > 0.0)
  {
    const double relative_tail_degradation = std::clamp(
        s.p99_read_ms / s.warmup_p99_read_ms - 1.0, 0.0, 1.0);
    a.x.push_back(std::tanh(relative_tail_degradation / 0.5));
  }
  else
    a.x.push_back(0.0);
  a.est_cost = std::max(1e-6, s.est_cost_ms);
  return a;
}

static void run_verification(aidel_type *ai)
{
  if (!ai)
    return;
  if (Config.proof_rate <= 0.0 || Config.verify_layer != "merklesum")
    return;
  if (exist_keys.empty())
    return;
  size_t checks = 0, fails = 0;
  const size_t cap = 100000;
  size_t step = 1;
  if (exist_keys.size() > cap)
    step = (exist_keys.size() + cap - 1) / cap;
  for (size_t i = 0; i < exist_keys.size(); i += step)
  {
    key_type k = exist_keys[i];
    val_type v;
    // End-of-run integrity check still uses the canonical index.
    bool ok = (ai->find(k, v) == Result::ok);
    checks++;
    if (!ok)
      fails++;
  }
  std::cerr << "[verify] checks=" << checks << " fails=" << fails << "\n";
}

struct alignas(CACHELINE_SIZE) ThreadParam
{
  aidel_type *ai = nullptr;
  AidelAdapter *adapter = nullptr;
  VerifyService *verifier = nullptr;
  std::atomic<uint64_t> throughput{0};
  uint32_t thread_id = 0;
  std::vector<uint32_t> lat_samples_ns;
  std::mutex lat_mu;
  uint32_t sample_tick = 0;
};
static std::atomic<bool> running{false};
static std::atomic<size_t> ready_threads{0};
static std::atomic<size_t> g_ycsb_cursor{0};
// AIDEL mutations are not internally synchronized.  Keep concurrent reads,
// but serialize CRUD writes so YCSB-D cannot corrupt the foreground index.

static void *run_fg(void *p)
{
  ThreadParam &tp = *(ThreadParam *)p;
  aidel_type *ai = tp.ai;
  AidelAdapter *adapter = tp.adapter;
  bool use_ycsb = (Config.benchmark >= 6 && Config.benchmark <= 11 &&
                   YCSBconfig.operate_queue != nullptr);
  std::mt19937 gen((uint32_t)(Config.seed + tp.thread_id * 1013904223u));
  std::uniform_real_distribution<> ur(0, 1);
  // Point lookups use a fixed, seed-derived permutation of the same key set
  // for every policy. A sorted sweep creates artificial per-window segment
  // phases and leaves recently repaired segments unqueried until later.
  std::vector<key_type> read_keys = exist_keys;
  if (!read_keys.empty())
  {
    std::seed_seq order_seed{static_cast<uint32_t>(Config.seed), tp.thread_id,
                             0x4c565852u};
    std::mt19937_64 order_rng(order_seed);
    std::shuffle(read_keys.begin(), read_keys.end(), order_rng);
  }
  size_t non_exist_per = non_exist_keys.empty() ? 0 : non_exist_keys.size() / std::max<size_t>(1, Config.thread_num);
  size_t start = non_exist_keys.empty() ? 0 : tp.thread_id * non_exist_per;
  size_t stop = non_exist_keys.empty() ? 0 : (tp.thread_id + 1) * non_exist_per;
  std::vector<key_type> op_keys;
  if (!non_exist_keys.empty() && start <= stop && stop <= non_exist_keys.size())
    op_keys.assign(non_exist_keys.begin() + start, non_exist_keys.begin() + stop);
  ready_threads++;
  while (!running)
  {
  }
  val_type dummy = 0;
  size_t qi = 0, ni = 0, ii = 0, ui = 0, di = 0;
  while (running)
  {
    const auto op_begin = std::chrono::steady_clock::now();
    double d = ur(gen);
    const bool warmup_read = g_measured_feedback &&
        std::chrono::duration<double>(op_begin - g_workload_started).count() < g_write_warmup_sec;
    if (warmup_read) d = 0.0;
    bool is_write = false;
    key_type used_key = 0;
    val_type written_value = 0;
    if (use_ycsb)
    {
      const size_t ticket = g_ycsb_cursor.fetch_add(1, std::memory_order_relaxed);
      const auto &op = YCSBconfig.operate_queue[ticket % YCSBconfig.operate_num];
      key_type k = op.key;
      switch (op.op)
      {
      case 0:
        adapter->foreground_find(k, dummy);
        break;
      case 1:
        adapter->foreground_write(k, k, ticket < YCSBconfig.operate_num ? 0 : 1);
        written_value = k;
        is_write = true;
        break;
      case 2:
        adapter->foreground_write(k, k, 1);
        written_value = k;
        is_write = true;
        break;
      case 3:
        adapter->foreground_write(k, k, 2);
        written_value = k;
        is_write = true;
        break;
      case 4:
        for (int i = 0; i < op.range; i++) adapter->foreground_find(k + i, dummy);
        break;
      default:
        adapter->foreground_find(k, dummy);
        break;
      }
      used_key = k;
    }
    else
    {
      double rlim = Config.read_ratio;
      double scale = 1.0;
      if (g_measured_feedback && getenv("WRITE_PATTERN"))
      {
        std::string pattern = getenv("WRITE_PATTERN");
        const double t = std::chrono::duration<double>(op_begin - g_workload_started).count();
        if (pattern == "burst")
        {
          const int onset = getenv("WRITE_BURST_SEC") ? atoi(getenv("WRITE_BURST_SEC")) : g_write_warmup_sec + 4;
          scale = (t >= onset && t < onset + 2 * std::max(1, Config.win_sec)) ? 1.0 : 0.0;
        }
        else if (pattern == "gradual")
          scale = std::clamp((t - g_write_warmup_sec) / std::max(1.0, double(Config.runtime - g_write_warmup_sec)), 0.0, 1.0);
      }
      rlim = 1.0 - scale * (1.0 - rlim);
      double ilim = rlim + scale * Config.insert_ratio;
      double ulim = ilim + scale * Config.update_ratio;
      double dlim = ulim + scale * Config.delete_ratio;
      bool do_neg = (Config.neg_read_ratio > 0.0) && !non_exist_keys.empty() && (ur(gen) < Config.neg_read_ratio);
      if (d <= rlim)
      {
        if (do_neg)
        {
          key_type k = non_exist_keys[ni % non_exist_keys.size()];
          adapter->foreground_find(k, dummy);
          used_key = k;
          ni++;
        }
        else
        {
          key_type k = read_keys[qi % read_keys.size()];
          adapter->foreground_find(k, dummy);
          used_key = k;
          qi = (qi + 1) % exist_keys.size();
        }
      }
      else if (d <= ilim)
      {
        key_type k = !op_keys.empty() && ii < op_keys.size() ? op_keys[ii]
            : exist_keys[ui++ % exist_keys.size()];
        adapter->foreground_write(k, k, !op_keys.empty() && ii < op_keys.size() ? 0 : 1);
        written_value = k;
        used_key = k;
        is_write = true;
        ii++;
      }
      else if (d <= ulim)
      {
        key_type k = g_measured_feedback ? exist_keys[ui % exist_keys.size()]
            : (op_keys.empty() ? exist_keys[ui % exist_keys.size()] : op_keys[ui % op_keys.size()]);
        written_value = g_measured_feedback ? (k ^ static_cast<key_type>(ui + 1)) : k;
        adapter->foreground_write(k, written_value, 1);
        used_key = k;
        is_write = true;
        ui++;
      }
      else if (d <= dlim)
      {
        if (!exist_keys.empty())
        {
          key_type k = exist_keys[di % exist_keys.size()];
          adapter->foreground_write(k, k, 2);
          written_value = k;
          used_key = k;
          is_write = true;
          di++;
        }
      }
      else
      {
        key_type k = read_keys[qi % read_keys.size()];
        adapter->foreground_find(k, dummy);
        used_key = k;
        qi = (qi + 1) % exist_keys.size();
      }
    }
    // Apply per-segment drift to the actual request path. Previously drift
    // changed only residual counters, leaving throughput and p99 unaffected.
    // Keep injected wait only for the original controlled-drift experiment.
    // Default P99 now measures real lookup and publication behavior.
    if (!use_correction_excess_signal() && !g_measured_feedback &&
        env_on("SIMULATED_DRIFT_WAIT"))
      busy_wait_ns(adapter->extra_latency_of_key(used_key));
    const auto op_end = std::chrono::steady_clock::now();
    const auto latency_ns_i64 =
        std::chrono::duration_cast<std::chrono::nanoseconds>(op_end - op_begin).count();
    const uint32_t latency_ns = static_cast<uint32_t>(
        std::min<int64_t>(latency_ns_i64, std::numeric_limits<uint32_t>::max()));
    adapter->note_operation(used_key, static_cast<double>(latency_ns) / 1.0e6, is_write);
    if (is_write && tp.verifier)
      tp.verifier->enqueue_write(static_cast<int>(tp.thread_id), used_key, written_value);
    tp.sample_tick++;
    if (!is_write && (tp.sample_tick & 0x3Fu) == 0)
      adapter->note_sampled_latency(used_key, latency_ns);
    if (!is_write && (tp.sample_tick & 0xFFu) == 0)
    {
      std::lock_guard<std::mutex> lk(tp.lat_mu);
      if (tp.lat_samples_ns.size() < 200000)
        tp.lat_samples_ns.push_back(latency_ns);
    }
    tp.throughput.fetch_add(1, std::memory_order_relaxed);
  }
  pthread_exit(nullptr);
}

static void preprocess_claims_args(int &argc, char **&argv)
{
  static bool done = false;
  if (done)
    return;
  done = true;
  static std::vector<char *> storage;
  storage.push_back(argv[0]);
  auto need = [&](int i, const char *f)
  { if(i+1>=argc){fprintf(stderr,"%s need val\n",f); exit(2);} return argv[i+1]; };
  for (int i = 1; i < argc; ++i)
  {
    std::string a = argv[i];
    if (a == "--longtail")
    {
      const char *v = need(i, "--longtail");
      ++i;
      std::stringstream ss(v);
      std::string tok;
      while (std::getline(ss, tok, ','))
      {
        auto pos = tok.find(':');
        if (pos == std::string::npos)
          continue;
        int cnt = 0;
        double us = 0;
        try
        {
          cnt = std::stoi(tok.substr(0, pos));
          us = std::stod(tok.substr(pos + 1));
        }
        catch (...)
        {
          continue;
        }
        if (cnt > 0 && us > 0)
          gScenario.longtail.push_back({cnt, (uint32_t)(us * 1000.0)});
      }
      continue;
    }
    else if (a == "--scenario")
    {
      const char *v = need(i, "--scenario");
      ++i;
      std::string sc = v;
      if (sc == "midlate")
        gScenario.enable_midlate = true;
      else if (sc == "tail")
        gScenario.tail_enable = true;
      continue;
    }
    else if (a == "--K-start")
    {
      gScenario.K_start = std::stoi(need(i, "--K-start"));
      ++i;
      continue;
    }
    else if (a == "--K-mid")
    {
      gScenario.K_mid = std::stoi(need(i, "--K-mid"));
      gScenario.enable_midlate = true;
      ++i;
      continue;
    }
    else if (a == "--K-late")
    {
      gScenario.K_late = std::stoi(need(i, "--K-late"));
      gScenario.enable_midlate = true;
      ++i;
      continue;
    }
    else if (a == "--mid-time")
    {
      gScenario.mid_time_s = std::stod(need(i, "--mid-time"));
      ++i;
      continue;
    }
    else if (a == "--late-time")
    {
      gScenario.late_time_s = std::stod(need(i, "--late-time"));
      ++i;
      continue;
    }
    else if (a == "--no-topk")
    {
      gScenario.disable_topk = true;
      continue;
    }
    else if (a == "--no-avoid")
    {
      gScenario.disable_avoid = true;
      continue;
    }
    else if (a == "--static-fair")
    {
      gScenario.fair_static = true;
      continue;
    }
    else if (a == "--greedy")
    {
      // Cost-aware myopic Greedy baseline: rank each segment by its current
      // residual reduction per estimated millisecond of real retraining.
      // It has no cross-window learning, exploration, or future information.
      gScenario.greedy_static = true;
      continue;
    }
    else if (a == "--static-dp" || a == "--static-dp-limited")
    {
      gScenario.static_dp = true;
      gScenario.static_dp_limited = (a == "--static-dp-limited");
      continue;
    }
    else if (a == "--periodic")
        {
            gScenario.periodic_static = true;
            continue;
        }
        else if (a == "--threshold")
        {
            gScenario.threshold_static = true;
            continue;
        }
        else if (a == "--tail-retention")
    {
      gScenario.tail_enable = true;
      gScenario.tail_retention_factor = std::stod(need(i, "--tail-retention"));
      ++i;
      continue;
    }
    else if (a == "--tail-decay")
    {
      gScenario.tail_enable = true;
      gScenario.tail_decay_us = std::stod(need(i, "--tail-decay"));
      ++i;
      continue;
    }
    else if (a == "--proof-rate")
    {
      gScenario.proof_rate_override = std::stod(need(i, "--proof-rate"));
      ++i;
      continue;
    }
    else if (a == "--proof-batch")
    {
      gScenario.proof_batch_override = std::stoi(need(i, "--proof-batch"));
      ++i;
      continue;
    }
    storage.push_back(argv[i]);
  }
  storage.push_back(nullptr);
  argc = (int)storage.size() - 1;
  argv = storage.data();
  optind = 1;
}

static void run_benchmark(aidel_type *ai,
                          AidelAdapter *adapter,
                          VerifyService *verifier,
                          size_t sec,
                          const PredictionErrorStats<aidel_type, key_type> &,
                          CsvLogger *csv_logger,
                          size_t /*unused*/)
{
  const size_t N = std::max<size_t>(1, Config.thread_num);
  std::vector<pthread_t> threads(N);
  std::vector<ThreadParam *> params(N);
  for (size_t i = 0; i < N; ++i)
  {
    params[i] = new ThreadParam();
    params[i]->ai = ai;
    params[i]->adapter = adapter;
    params[i]->verifier = verifier;
    params[i]->thread_id = static_cast<uint32_t>(i);
  }
  running = false;
  ready_threads = 0;
  for (size_t i = 0; i < N; ++i)
    if (pthread_create(&threads[i], nullptr, run_fg, (void *)params[i]) != 0)
    {
      std::cerr << "pthread_create fail\n";
      abort();
    }
  while (ready_threads < N)
    usleep(1000);
  g_workload_started = std::chrono::steady_clock::now();
  running = true;

  // 添加 rng_local
  std::mt19937_64 rng_local(static_cast<uint64_t>(Config.seed) ^ 0x9e3779b97f4a7c15ULL);

  size_t current_sec = 0;
  const int WIN = std::max(1, Config.win_sec);
  LinUCBController::Param phase1_param;
  phase1_param.d = 9;
  // Strong regularization prevents the enormous cold-start confidence term
  // (lambda=1e-3) from overwhelming the observable residual signal.
  phase1_param.alpha = std::min(0.20, std::max(0.0, Config.alpha));
  phase1_param.lambda = std::max(1.0, Config.lambda);
  phase1_param.budget_B = 1;
  // NoAdapt is a calibrated-then-frozen learned scheduler.  It must not keep
  // the hand-written residual/slope shortcut after online updates are
  // disabled; otherwise it remains a near-current-window oracle despite the
  // ablation. This branch is inactive for every normal LinVeriX run.
  phase1_param.use_residual_prior = !g_flag_disable_adapt;
  LinUCBController phase1_controller(phase1_param);
  std::ofstream phase_budget_csv;
  if (Config.policy == "linucb" && !g_flag_single_phase && g_drift_enabled &&
      !gScenario.greedy_static && !gScenario.static_dp && !gScenario.periodic_static)
  {
    const std::filesystem::path run_csv(Config.csv_log);
    std::string run_stem = run_csv.filename().string();
    const size_t csv_ext = run_stem.rfind(".csv");
    if (csv_ext != std::string::npos) run_stem.resize(csv_ext);
    const auto budget_dir = run_csv.parent_path() / ("budget_" + run_stem);
    std::filesystem::create_directories(budget_dir);
    const std::string budget_path = (budget_dir / "budget.csv").string();
    phase_budget_csv.open(budget_path, std::ios::out | std::ios::trunc);
    if (phase_budget_csv.good())
      phase_budget_csv << "window_id,U_uncertainty,R_topk_residual,rho,B1_alloc,B2_alloc,"
                          "B1_used,B2_used,p1_starvation_windows,p2_starvation_windows,"
                          "forced_fair_split,B1_credit_after,topk_reference_cmp_per_query\n";
  }
  if (gScenario.enable_midlate && current_sec == 0)
  {
    gScenario.mid_global_sec = (int)std::floor(gScenario.mid_time_s);
    gScenario.late_global_sec = (int)std::ceil(gScenario.late_time_s - 1e-9);
  }
  double raw_baseline_topk_sum_cmp_per_query = 0.0;
  bool raw_baseline_recorded = false;
  double topk_sum_post_injection_cmp_per_query = 0.0;
  double topk_sum_post_phase2_cmp_per_query = 0.0;
  double peak_topk_sum_cmp_per_query = 0.0;
  double budget_oracle_topk_target_cmp_per_query = 0.0;
  double triplet_post_ratio = 0.0;
  size_t usedB_phase1 = 0, usedB_phase2 = 0, phase2_used = 0;
  double phase1_cost_ms_sum = 0.0, phase2_cost_ms_sum = 0.0;
  double tau_cmp_per_query = 0.0, phi_cmp_per_query = 0.0, margin_pct = 0.10;
  double fixed_tau_cmp_per_query = 0.0, fixed_phi_cmp_per_query = 0.0;
  bool baseline_finalized = false;
  bool executed_static_batch = false;
  bool executed_linverix_allocation_this_window = false;
  bool executed_phase2_this_window = false;
  bool mid_inject_flag = false, late_inject_flag = false;
  bool injected_this_window = false;
  int late_segments_repaired = 0;
  std::vector<size_t> tput_hist(N, 0);
  std::vector<uint64_t> sec_tput;
  sec_tput.reserve(WIN + 4);
  // Both phases schedule from one immutable window observation.  This matches
  // a dual-phase controller whose decisions can overlap in time and makes the
  // reservation/avoidance mechanism testable without changing drift values.
  std::vector<SegmentStats> window_decision_snapshot;
  // Static Threshold is a one-window-lag reactive policy.  It may only act on
  // the last completed observation, never on a shock injected at the current
  // boundary.  Keep the current raw snapshot separately and publish it only
  // after this window's threshold decision has been finalized.
  std::vector<SegmentStats> threshold_prev_stats;
  std::vector<SegmentStats> threshold_current_stats;
  struct PendingMeasuredReward
  {
    int segment;
    int window;
    double before_mean_ms;
    double before_correction_steps_per_query;
    double before_p99_ms;
    double cost_ms;
    SegmentFeedbackCursor feedback_cursor;
    bool first_feedback_window = true;
    double post_read_ns = 0.0;
    uint64_t post_read_count = 0;
    uint64_t post_correction_steps = 0;
    uint64_t post_correction_queries = 0;
    uint64_t post_latency_samples = 0;
    std::vector<uint64_t> post_latency_hist;
    std::vector<double> feature_context;
  };
  std::vector<PendingMeasuredReward> pending_measured_rewards;
  size_t p1_starvation_windows = 0;
  size_t p2_starvation_windows = 0;
  double budget_U = 0.0, budget_R = 0.0, budget_rho = 0.40;
  size_t budget_B1 = 0, budget_B2 = 0;
  bool budget_forced_fair_split = false;
  // Carry fractional phase-1 allocations across windows. Per-window floor()
  // discarded rho*B whenever B was small (notably B=2), starving exploration.
  double phase1_budget_credit = 0.0;

  auto gi = [](const char *k, int d) -> int
  { const char* v=getenv(k); if(!v) return d; try{return std::stoi(v);}catch(...){return d;} };
  auto gu = [](const char *k, uint32_t d) -> uint32_t
  { const char* v=getenv(k); if(!v) return d; try{return (uint32_t)std::stoul(v);}catch(...){return d;} };
  int DRIFT_INTERVAL = gi("DRIFT_INTERVAL_SEC", 0);
  int DRIFT_K = gi("DRIFT_K", 4);
  uint32_t DRIFT_LAT_NS_PER_SEG = gu("DRIFT_LAT_NS_PER_SEG", 20000);
  int DRIFT_WARMUP_SEC = gi("DRIFT_WARMUP_SEC", 0);

  auto record_synthetic_injection = [&]()
  {
    const auto stats = adapter->collect_all_stats();
    std::vector<double> residuals;
    residuals.reserve(stats.size());
    for (const auto &s : stats) residuals.push_back(s.drift);
    std::sort(residuals.begin(), residuals.end(), std::greater<>());
    const size_t topk = std::min(residuals.size(), (size_t)std::max(0, DRIFT_K));
    const size_t ideal_repairs = std::min(topk, static_cast<size_t>(Config.budget_B));
    budget_oracle_topk_target_cmp_per_query = 0.0;
    for (size_t i = ideal_repairs; i < topk; ++i)
      budget_oracle_topk_target_cmp_per_query += residuals[i];
    const double injected_topk = compute_topk_sum(adapter, (size_t)DRIFT_K);
    raw_baseline_topk_sum_cmp_per_query = injected_topk;
    raw_baseline_recorded = true;
    topk_sum_post_injection_cmp_per_query = injected_topk;
    peak_topk_sum_cmp_per_query = std::max(peak_topk_sum_cmp_per_query, injected_topk);
    baseline_finalized = true;
    triplet_post_ratio = 1.0;
  };

  while (current_sec < sec)
  {
    std::this_thread::sleep_for(std::chrono::seconds(1));
    bool window_start = ((current_sec % WIN) == 0);
    bool end_of_window = (((current_sec + 1) % WIN) == 0);
    int sec_in_window = (int)(current_sec % WIN);
    int current_window = (int)(current_sec / WIN);
    g_active_window_id = current_window + 1;
    const int configured_warmup_windows =
        std::max(0, gi("DRIFT_WARMUP_WINDOWS", 0));
    // The declared warm-up is a clean, strategy-independent query baseline.
    // Do not let any policy spend maintenance budget before the first evaluated
    // window; otherwise warm-up P99 includes policy-specific retraining load.
    const bool maintenance_window_active =
        current_window >= configured_warmup_windows;

    if (window_start)
    {
      if (current_window > 0 && raw_baseline_topk_sum_cmp_per_query > 0.0)
      {
        p1_starvation_windows = usedB_phase1 == 0 ? p1_starvation_windows + 1 : 0;
        p2_starvation_windows = usedB_phase2 == 0 ? p2_starvation_windows + 1 : 0;
      }
      else if (current_window > 0)
      {
        p1_starvation_windows = 0;
        p2_starvation_windows = 0;
      }
      for (auto it = pending_measured_rewards.begin(); it != pending_measured_rewards.end(); )
      {
        SegmentFeedbackWindow observed;
        const bool feedback_window_valid = current_window > it->window &&
            adapter->published_query_window(
                it->segment, it->feedback_cursor, observed);
        if (!feedback_window_valid)
        {
          // The selected model version was replaced before its first complete
          // foreground window could be observed.
          it = pending_measured_rewards.erase(it);
          continue;
        }
        if (observed.window_id == it->feedback_cursor.window_id &&
            observed.read_count < 32 && observed.latency_samples < 512)
        {
          // Publication occurred so late in its window that no useful
          // post-publication sample was available. Wait for the next full
          // window rather than turning a same-window counter delta into zero.
          ++it;
          continue;
        }
        double reward = 0.0;
        const bool has_query_exposure = observed.read_count >= 32;
        const bool has_reliable_p99 = observed.latency_samples >= 512;
        double after_mean_ms = 0.0;
        double after_correction_steps_per_query = 0.0;
        double after_p99_ms = 0.0;
        if (has_query_exposure)
        {
          after_mean_ms = observed.read_ns / observed.read_count / 1.0e6;
          after_correction_steps_per_query =
              static_cast<double>(observed.correction_steps) / observed.read_count;
          const double work_gain =
              (it->before_correction_steps_per_query - after_correction_steps_per_query) /
              std::max(1.0, it->before_correction_steps_per_query);
          const double latency_gain =
              (it->before_mean_ms - after_mean_ms) / std::max(1e-6, it->before_mean_ms);
          if (has_reliable_p99 && it->before_p99_ms > 0.0)
          {
            const uint64_t target = static_cast<uint64_t>(
                std::ceil(observed.latency_samples * 0.99));
            uint64_t seen = 0;
            for (size_t b = 0; b < observed.latency_hist.size(); ++b)
            {
              seen += observed.latency_hist[b];
              if (seen >= target)
              {
                after_p99_ms = (static_cast<double>(b) + 0.5) * 500.0 / 1.0e6;
                break;
              }
            }
            const double p99_gain =
                (it->before_p99_ms - after_p99_ms) / std::max(1e-6, it->before_p99_ms);
            reward = 0.40 * work_gain + 0.20 * latency_gain + 0.40 * p99_gain;
          }
          else
          {
            // With too few tail samples, retain exact work and mean-latency
            // evidence without inventing a P99 estimate.
            reward = (2.0 / 3.0) * work_gain + (1.0 / 3.0) * latency_gain;
          }
        }
        // A first post-publication window with no routed queries is an explicit
        // zero-observed-service-benefit outcome, rather than an endlessly cold
        // arm that can repeatedly consume exploration budget.
        reward = std::clamp(reward, -1.0, 1.0);
        {
          // Only the first complete post-publication window is attributable to
          // this repair. Later windows may include another injected drift step.
          phase1_controller.observeReward(static_cast<uint32_t>(it->segment), reward,
                                          it->feature_context);
          std::cerr << "[LINUCB_FEEDBACK] segment=" << it->segment
                    << " before_correction_steps_per_query="
                    << it->before_correction_steps_per_query
                    << " after_correction_steps_per_query="
                    << after_correction_steps_per_query
                    << " before_mean_read_ms=" << it->before_mean_ms
                    << " after_mean_read_ms=" << after_mean_ms
                    << " before_p99_ms=" << it->before_p99_ms
                    << " after_p99_ms=" << after_p99_ms
                    << " model_version=" << it->feedback_cursor.model_version
                    << " post_publication_queries=" << observed.read_count
                    << " post_publication_p99_samples=" << observed.latency_samples
                    << " feedback_age_windows=" << (current_window - it->window)
                    << " feedback_components="
                    << (!has_query_exposure ? "no_query" :
                        (has_reliable_p99 ? "work_mean_p99" : "work_mean"))
                    << " reward=" << reward << "\n";
        }
        it = pending_measured_rewards.erase(it);
      }
      usedB_phase1 = usedB_phase2 = phase2_used = 0;
      budget_U = 0.0;
      budget_R = 0.0;
      budget_rho = 0.40;
      budget_B1 = 0;
      budget_B2 = (size_t)Config.budget_B;
      budget_forced_fair_split = false;
      phase1_cost_ms_sum = phase2_cost_ms_sum = 0;
      tau_cmp_per_query = phi_cmp_per_query = 0;
      executed_phase2_this_window = false;
      executed_linverix_allocation_this_window = false;
      executed_static_batch = false;
      mid_inject_flag = late_inject_flag = false;
      injected_this_window = false;
      late_segments_repaired = 0;
      budget_oracle_topk_target_cmp_per_query = 0.0;
      g_phase2_total_repairs = g_phase2_redundant_repairs = 0;
      g_retrained_segments_this_window.clear();
      g_start_injected_segments.clear();
      g_mid_injected_segments.clear();
      g_late_injected_segments.clear();
      baseline_finalized = false;
      window_decision_snapshot.clear();
      raw_baseline_recorded = false;
      raw_baseline_topk_sum_cmp_per_query = 0.0;

      if (current_window > 0)
      {
        raw_baseline_topk_sum_cmp_per_query = topk_sum_post_phase2_cmp_per_query;
        raw_baseline_recorded = true;
        topk_sum_post_injection_cmp_per_query = raw_baseline_topk_sum_cmp_per_query;
        peak_topk_sum_cmp_per_query = raw_baseline_topk_sum_cmp_per_query;
        topk_sum_post_phase2_cmp_per_query = raw_baseline_topk_sum_cmp_per_query;
        baseline_finalized = true;
        triplet_post_ratio = 1.0;
      }
      else
      {
        topk_sum_post_injection_cmp_per_query = 0;
        topk_sum_post_phase2_cmp_per_query = 0;
        peak_topk_sum_cmp_per_query = 0;
        triplet_post_ratio = 0;
      }
    }

    bool linucb_phase_enabled = maintenance_window_active && g_drift_enabled &&
                                (Config.policy == "linucb") &&
                                !g_flag_single_phase &&
                                !gScenario.greedy_static &&
                                !gScenario.static_dp;
    bool adapt_enabled = linucb_phase_enabled && !g_flag_disable_runtime;
    size_t effB = (size_t)Config.budget_B;

    if (current_window == 0 || gScenario.K_mid > 0 || gScenario.K_late > 0)
    {
      if (window_start)
      {
        if (!g_measured_feedback && current_window == 0 && !gScenario.longtail.empty())
        {
          adapter->inject_longtail_pattern(gScenario.longtail);
          injected_this_window = true;
          record_synthetic_injection();
        }
        if (!g_measured_feedback && current_window == 0 && gScenario.K_start > 0)
        {
        g_start_injected_segments =
              adapter->inject_latency_drift_return_ids((size_t)gScenario.K_start,
                                                       DRIFT_LAT_NS_PER_SEG ? DRIFT_LAT_NS_PER_SEG : 1);
          injected_this_window = true;
          record_synthetic_injection();
        }
      }
      if (!g_measured_feedback && gScenario.K_mid > 0 && !gScenario.mid_injected && current_sec == gScenario.mid_global_sec)
      {
        g_mid_injected_segments =
            adapter->inject_latency_drift_return_ids((size_t)gScenario.K_mid,
                                                     DRIFT_LAT_NS_PER_SEG ? DRIFT_LAT_NS_PER_SEG : 1);
        gScenario.mid_injected = true;
        mid_inject_flag = true;
        injected_this_window = true;
        record_synthetic_injection();
      }
      if (!g_measured_feedback && gScenario.K_late > 0 && !gScenario.late_injected &&
          current_sec == gScenario.late_global_sec)
      {
        g_late_injected_segments =
            adapter->inject_latency_drift_return_ids((size_t)gScenario.K_late,
                                                     DRIFT_LAT_NS_PER_SEG ? DRIFT_LAT_NS_PER_SEG : 1);
        gScenario.late_injected = true;
        late_inject_flag = true;
        injected_this_window = true;
        record_synthetic_injection();
      }
      bool staging_done = false;
      if (gScenario.K_late > 0)
        staging_done = gScenario.late_injected;
      else if (gScenario.K_mid > 0)
        staging_done = gScenario.mid_injected;
      else
        staging_done = window_start;
      if (staging_done && !baseline_finalized)
      {
        double base = compute_topk_sum(adapter, (size_t)DRIFT_K);
        raw_baseline_topk_sum_cmp_per_query = base;
        raw_baseline_recorded = true;
        topk_sum_post_injection_cmp_per_query = base;
        peak_topk_sum_cmp_per_query = std::max(peak_topk_sum_cmp_per_query, base);
        baseline_finalized = true;
        triplet_post_ratio = 1.0;
      }
    }
    if (!g_measured_feedback && window_start && DRIFT_INTERVAL > 0) {

      // 让 DRIFT_INTERVAL 表示"每隔多少个 window 注入一次"
      int win_id = current_window; // 从 1 开始算 periodic
      bool do_inject = (win_id >= DRIFT_WARMUP_SEC / WIN) &&
                      ((win_id - (DRIFT_WARMUP_SEC / WIN)) % (DRIFT_INTERVAL / WIN == 0 ? 1 : (DRIFT_INTERVAL / WIN)) == 0);

      // 每个 window 注入
      if (do_inject) {
        adapter->inject_latency_drift((size_t)DRIFT_K, DRIFT_LAT_NS_PER_SEG);
        injected_this_window = true;
        record_synthetic_injection();
      }
    }

    // In measured mode all four policies receive the same previous observed
    // read/write counters; none can see the simulated injection ground truth.
    if (g_measured_feedback && window_start)
    {
      baseline_finalized = true;
      raw_baseline_topk_sum_cmp_per_query = compute_topk_sum(adapter, (size_t)DRIFT_K);
      topk_sum_post_injection_cmp_per_query = raw_baseline_topk_sum_cmp_per_query;
      peak_topk_sum_cmp_per_query = raw_baseline_topk_sum_cmp_per_query;
      topk_sum_post_phase2_cmp_per_query = raw_baseline_topk_sum_cmp_per_query;
      raw_baseline_recorded = true;
    }


    bool static_policy_due = gScenario.fair_static || gScenario.greedy_static ||
                             gScenario.static_dp;
    if (gScenario.periodic_static)
    {
      const int every = std::max(1, gi("PERIODIC_EVERY_WINDOWS", 1));
      static_policy_due = (current_window % every) == 0;
    }
    if (gScenario.threshold_static && baseline_finalized && !executed_static_batch)
    {
      const double threshold_us = Config.tau > 0.0
                                      ? Config.tau
                                      : static_cast<double>(gi("THRESHOLD_RESIDUAL_CMP_PER_QUERY", 1));
      threshold_current_stats = adapter->collect_all_stats();
      double max_drift = 0.0;
      for (const auto &s : threshold_prev_stats)
        max_drift = std::max(max_drift, s.drift);
      static_policy_due = !threshold_prev_stats.empty() && max_drift >= threshold_us;
      std::cout << "[THRESHOLD_DECISION] decision_window=" << current_window
                << " observed_window=" << (current_window - 1)
                << " theta_us=" << threshold_us
                << " max_prev_drift_us=" << max_drift
                << " due=" << (static_policy_due ? 1 : 0)
                << std::endl;
    }
    if (maintenance_window_active &&
        (gScenario.fair_static || gScenario.greedy_static || gScenario.static_dp || gScenario.periodic_static || gScenario.threshold_static) &&
        baseline_finalized && !executed_static_batch && static_policy_due)
    {
      auto st_final = gScenario.threshold_static
                          ? threshold_prev_stats
                          : adapter->collect_all_stats();
      struct StaticCandidate
      {
        int id;
        double drift;
        double cost_ms;
        double maintenance_age_sec;
      };
      std::vector<StaticCandidate> arr;
      const double threshold_us = Config.tau > 0.0
                                      ? Config.tau
                                      : static_cast<double>(gi("THRESHOLD_RESIDUAL_CMP_PER_QUERY", 1));
      for (auto &s : st_final)
      {
        const bool eligible = gScenario.periodic_static ||
            (s.drift > 0 && (!gScenario.threshold_static || s.drift >= threshold_us));
        if (eligible)
          arr.push_back({s.seg_id, s.drift, std::max(0.001, s.est_cost_ms),
                         std::max(0.0, s.maintenance_age_sec)});
      }
      std::sort(arr.begin(), arr.end(), [](auto &a, auto &b)
                { return a.drift > b.drift; });
      if (gScenario.greedy_static)
      {
        std::stable_sort(arr.begin(), arr.end(), [](const auto &a, const auto &b)
        {
          const double da = a.drift / std::max(0.001, a.cost_ms);
          const double db = b.drift / std::max(0.001, b.cost_ms);
          if (da != db) return da > db;
          return a.drift > b.drift;
        });
      }
      else if (gScenario.periodic_static)
      {
        // P=1 age-based baseline: every window, service the oldest-maintained
        // dirty segments. Residual magnitude and retraining cost do not rank it.
        std::stable_sort(arr.begin(), arr.end(), [](const auto &a, const auto &b)
        {
          if (a.maintenance_age_sec != b.maintenance_age_sec)
            return a.maintenance_age_sec > b.maintenance_age_sec;
          return a.id < b.id;
        });
      }
      std::vector<int> chosen;
      size_t repair_cap = gScenario.static_dp_limited ? std::min<size_t>(1, effB) : effB;
      if (gScenario.static_dp && repair_cap > 0 && !arr.empty())
      {
        // StaticDP: exact 0/1 knapsack over the current residual snapshot.
        // It maximizes predicted residual reduction subject to both the repair
        // count B and a fixed per-window retraining-time allowance.  Unlike
        // LinVeriX, it has no online reward update or cross-window learning.
        double cost_budget_ms = 0.0;
        if (const char *v = getenv("STATICDP_COST_BUDGET_MS"))
          cost_budget_ms = std::max(0.001, atof(v));
        if (cost_budget_ms <= 0.0)
        {
          std::vector<double> costs;
          for (const auto &c : arr) costs.push_back(c.cost_ms);
          std::nth_element(costs.begin(), costs.begin() + costs.size() / 2, costs.end());
          cost_budget_ms = costs[costs.size() / 2] * repair_cap;
        }
        // Scale the DP quantum with the actual budget.  A fixed 0.001-ms
        // floor made tiny-data smoke tests spuriously reject candidates whose
        // cost was equal to the budget after upward rounding.
        const double quantum_ms = std::max(1e-9, cost_budget_ms / 2000.0);
        const int W = std::max(1, std::min(2000, (int)std::floor(cost_budget_ms / quantum_ms)));
        const auto weight_of = [quantum_ms](double cost_ms)
        {
          return std::max(1, (int)std::ceil(cost_ms / quantum_ms - 1e-12));
        };
        const size_t n = arr.size();
        const double neg = -1e300;
        std::vector<std::vector<std::vector<double>>> dp(
            n + 1, std::vector<std::vector<double>>(repair_cap + 1,
                                                    std::vector<double>(W + 1, neg)));
        std::vector<std::vector<std::vector<uint8_t>>> take(
            n + 1, std::vector<std::vector<uint8_t>>(repair_cap + 1,
                                                     std::vector<uint8_t>(W + 1, 0)));
        dp[0][0][0] = 0.0;
        for (size_t i = 1; i <= n; ++i)
        {
          const int wi = weight_of(arr[i - 1].cost_ms);
          for (size_t b = 0; b <= repair_cap; ++b)
            for (int w = 0; w <= W; ++w)
            {
              dp[i][b][w] = dp[i - 1][b][w];
              if (b > 0 && w >= wi && dp[i - 1][b - 1][w - wi] > neg / 2)
              {
                const double value = dp[i - 1][b - 1][w - wi] + arr[i - 1].drift;
                if (value > dp[i][b][w]) { dp[i][b][w] = value; take[i][b][w] = 1; }
              }
            }
        }
        size_t best_b = 0; int best_w = 0; double best = 0.0;
        for (size_t b = 0; b <= repair_cap; ++b)
          for (int w = 0; w <= W; ++w)
            if (dp[n][b][w] > best) { best = dp[n][b][w]; best_b = b; best_w = w; }
        for (size_t i = n, b = best_b; i > 0; --i)
        {
          if (take[i][b][best_w])
          {
            chosen.push_back(arr[i - 1].id);
            best_w -= weight_of(arr[i - 1].cost_ms);
            --b;
          }
        }
      }
      else
      {
        const size_t take_n = std::min(arr.size(), repair_cap);
        for (size_t i = 0; i < take_n; ++i) chosen.push_back(arr[i].id);
      }
      if (gScenario.periodic_static)
      {
        std::cout << "[PERIODIC_DECISION] window=" << current_window
                  << " P=" << std::max(1, gi("PERIODIC_EVERY_WINDOWS", 1))
                  << " ranking=maintenance_age_desc chosen=";
        for (size_t i = 0; i < chosen.size(); ++i)
        {
          if (i) std::cout << ",";
          std::cout << chosen[i];
        }
        std::cout << std::endl;
      }
      for (int chosen_id : chosen)
      {
        const double cost_before = g_win.retrain_cost_ms_sum;
        g_active_maintenance_phase = "baseline";
        adapter->retrain_segment_async(chosen_id, nullptr);
        phase1_cost_ms_sum += g_win.retrain_cost_ms_sum - cost_before;
        usedB_phase1++;
        g_retrained_segments_this_window.insert(chosen_id);
      }
      topk_sum_post_phase2_cmp_per_query = compute_topk_sum(adapter, (size_t)DRIFT_K);
      if (raw_baseline_topk_sum_cmp_per_query > 0)
        triplet_post_ratio = topk_sum_post_phase2_cmp_per_query / raw_baseline_topk_sum_cmp_per_query;
      executed_static_batch = true;
      executed_phase2_this_window = true;
      if (gScenario.threshold_static)
        threshold_prev_stats = threshold_current_stats;
    }
    else if ((gScenario.fair_static || gScenario.greedy_static || gScenario.static_dp ||
              gScenario.periodic_static || gScenario.threshold_static) &&
             baseline_finalized && !executed_static_batch && !static_policy_due)
    {
      topk_sum_post_phase2_cmp_per_query = compute_topk_sum(adapter, static_cast<size_t>(DRIFT_K));
      if (raw_baseline_topk_sum_cmp_per_query > 0)
        triplet_post_ratio = topk_sum_post_phase2_cmp_per_query / raw_baseline_topk_sum_cmp_per_query;
      if (gScenario.threshold_static)
      {
        threshold_prev_stats = threshold_current_stats;
        // A threshold policy makes at most one trigger decision per window,
        // including a no-op decision below theta.
        executed_static_batch = true;
      }
    }

    if (baseline_finalized && linucb_phase_enabled &&
        !gScenario.fair_static && !gScenario.greedy_static && !gScenario.static_dp &&
        !executed_linverix_allocation_this_window)
    {
      g_in_linucb_midwindow = true;
      auto stats = adapter->collect_all_stats();
      if (!stats.empty())
      {
        std::vector<double> dr;
        dr.reserve(stats.size());
        for (auto &s : stats)
          dr.push_back(s.drift);
        if (adapt_enabled)
        {
          tau_cmp_per_query = percentile(dr, 0.80);
          phi_cmp_per_query = tau_cmp_per_query * (1.0 + margin_pct);
        }
        else
        {
          if (fixed_tau_cmp_per_query == 0.0)
          {
            fixed_tau_cmp_per_query = percentile(dr, 0.80);
            fixed_phi_cmp_per_query = fixed_tau_cmp_per_query * (1.0 + margin_pct);
          }
          tau_cmp_per_query = fixed_tau_cmp_per_query;
          phi_cmp_per_query = fixed_phi_cmp_per_query;
        }
      }
      auto st2 = adapter->collect_all_stats();
      if (window_decision_snapshot.empty())
        window_decision_snapshot = st2;
      size_t phase1_cap = effB;
      // Adaptive phase allocation. U is mean normalized LinUCB confidence
      // width over eligible arms; R is Top-K residual normalized by the
      // configured full-injection Top-K scale. Both are bounded to [0,1].
      std::vector<ArmContext> allocation_arms;
      allocation_arms.reserve(st2.size());
      for (const auto &s : st2)
        if (s.drift > 0)
          allocation_arms.push_back(make_scheduler_arm(s));
      if (!allocation_arms.empty())
      {
        std::vector<uint32_t> ids;
        ids.reserve(allocation_arms.size());
        for (const auto &a : allocation_arms) ids.push_back(a.arm_id);
        phase1_controller.ensure_arms_exist(ids);
        double uncertainty_sum = 0.0;
        for (const auto &a : allocation_arms)
        {
          const double u = phase1_controller.uncertainty(a.x);
          uncertainty_sum += u / (1.0 + u);
        }
        budget_U = uncertainty_sum / allocation_arms.size();
      }
      const double current_topk_residual = compute_topk_sum(adapter, (size_t)DRIFT_K);
      // Unitless bounded load indicator derived from measured excess correction
      // comparisons/query. One comparison/query is the fixed reference scale.
      budget_R = gScenario.disable_topk
          ? 0.0
          : current_topk_residual / (1.0 + current_topk_residual);
      // Keep exploration responsive to uncertainty, but let a persistently
      // large Top-K residual reserve more of the scarce window budget for
      // immediate repair. The scaled range bounds exploration while preserving
      // a small ongoing opportunity for contextual feedback.
      budget_rho = std::clamp(0.40 + 0.20 * budget_U - 0.20 * budget_R,
                              0.20, 0.60);
      // Keep the conservative exploration share while Phase 1 considers all
      // drifting segments; unlike Phase 2, exploration is not screened to the
      // residual Top-K frontier.
      // Let the uncertainty/residual controller use its full adaptive share.
      // A 0.25 multiplier starved Phase 1 under B=2, yielding too few
      // post-publication observations for the contextual scheduler to learn.
 double phase1_rho_scale = 1.0;
      if (const char *v = getenv("LINUCB_PHASE1_RHO_SCALE"))
      {
        char *end = nullptr;
        const double parsed = std::strtod(v, &end);
        if (end != v && *end == '\0' && std::isfinite(parsed))
          phase1_rho_scale = std::clamp(parsed, 0.0, 1.0);
      }
      budget_rho *= phase1_rho_scale;
      const double phase1_credit_target = phase1_budget_credit +
          budget_rho * static_cast<double>(effB);
      phase1_cap = std::min(effB, static_cast<size_t>(std::max(
          0.0, std::floor(phase1_credit_target))));
      int phase1_starvation_limit = 8;
      if (const char *v = getenv("LINUCB_PHASE1_STARVATION_WINDOWS"))
      {
        const int parsed = atoi(v);
        if (parsed > 0)
          phase1_starvation_limit = parsed;
      }
      // Preserve a repair slot whenever phase 2 has been starved. Exploration
      // receives an aging reservation only after a longer starvation interval,
      // so it remains available without repeatedly displacing urgent repairs.
      if (current_topk_residual > 0.0 && effB >= 2 &&
          p2_starvation_windows >= 2)
      {
        phase1_cap = 1;
        budget_forced_fair_split = true;
      }
      else if (current_topk_residual > 0.0 && effB >= 2 &&
               p1_starvation_windows >= phase1_starvation_limit)
      {
        phase1_cap = 1;
        budget_forced_fair_split = true;
      }
      else if (current_topk_residual > 0.0 && effB == 1 &&
               (p1_starvation_windows >= phase1_starvation_limit || p2_starvation_windows >= 2))
      {
        phase1_cap = p2_starvation_windows >= 2 ? 0 : 1;
        budget_forced_fair_split = true;
      }
      // Explicit override used by component ablations and diagnostics; the
      // RQ1 full-policy runner does not set it.
      if (const char *v = getenv("LINUCB_PHASE1_MAX_B"))
      {
        const int lim = atoi(v);
        if (lim >= 0)
          phase1_cap = std::min(phase1_cap, static_cast<size_t>(lim));
      }
      // Debit the number actually allocated, including fairness or ablation
      // overrides, so the carried fraction remains an auditable budget ledger.
      // Carry signed credit so fairness overrides that spend above the
      // adaptive target are repaid by later windows instead of silently
      // inflating the long-run Phase-1 share.
      phase1_budget_credit = phase1_credit_target -
          static_cast<double>(phase1_cap);
      budget_B1 = phase1_cap;
      budget_B2 = effB - phase1_cap;
      executed_linverix_allocation_this_window = true;
      if (phase1_cap > 0)
      {
        std::vector<int> selected_ids;
        if (g_flag_select_random)
        {
          for (const auto &s : st2)
            if (s.drift > 0)
              selected_ids.push_back(s.seg_id);
          std::shuffle(selected_ids.begin(), selected_ids.end(),
                       std::mt19937{static_cast<uint32_t>(Config.seed + current_sec)});
        }
        else
        {
          std::vector<const SegmentStats *> p1_candidates;
          p1_candidates.reserve(st2.size());
          for (const auto &s : st2)
          {
            if (s.drift <= 0)
              continue;
            p1_candidates.push_back(&s);
          }
          // Keep exploration on the same residual frontier that Phase 2 can
          // repair. Otherwise scarce Phase-1 actions can be spent learning
          // about low-pressure segments that are not viable repair choices.
          if (!gScenario.disable_topk && DRIFT_K > 0 &&
              p1_candidates.size() > static_cast<size_t>(DRIFT_K))
          {
            std::stable_sort(p1_candidates.begin(), p1_candidates.end(),
                             [](const SegmentStats *a, const SegmentStats *b)
                             { return a->drift > b->drift; });
            p1_candidates.resize(static_cast<size_t>(DRIFT_K));
          }
          std::vector<ArmContext> arms;
          arms.reserve(p1_candidates.size());
          for (const SegmentStats *s : p1_candidates)
          {
            arms.push_back(make_scheduler_arm(*s));
          }
          phase1_controller.set_budget_B(phase1_cap);
          const auto picked = phase1_controller.select(arms);
          selected_ids.assign(picked.begin(), picked.end());
        }
        size_t step = 0;
        for (int selected_id : selected_ids)
        {
          if (usedB_phase1 >= phase1_cap)
            break;
          const auto stat_it = std::find_if(st2.begin(), st2.end(),
                                            [selected_id](const SegmentStats &s) { return s.seg_id == selected_id; });
          if (stat_it == st2.end())
            continue;
          const auto &c = *stat_it;
          bool already_phase1 = (g_retrained_segments_this_window.count(c.seg_id) > 0);
          if (!gScenario.disable_avoid && already_phase1)
          {
            dbg_p1("[P1] win=" + std::to_string(current_window) + " step=" + std::to_string(step) +
                   " seg=" + std::to_string(c.seg_id) + " drift=" + std::to_string((int)c.drift) +
                   " already=1 action=skip_dup avoid=1");
            step++;
            continue;
          }
          const double cost_before = g_win.retrain_cost_ms_sum;
          const double before_mean_ms = c.mean_read_ms;
          const double before_correction_steps_per_query = c.correction_steps_per_query;
          const double before_p99_ms = c.p99_read_ms;
          const uint64_t before_correction_queries = c.correction_queries;
          const std::vector<double> decision_context = make_scheduler_arm(c).x;
          g_active_maintenance_phase = "phase1";
          adapter->retrain_segment_async(c.seg_id, [&, before_mean_ms, before_p99_ms,
              before_correction_steps_per_query, before_correction_queries,
              decision_context]
              (int id, double d_mean_read_ms, double, double cost_ms) {
            if (d_mean_read_ms >= 0.0 || before_correction_queries < 32)
              return; // stale or insufficient pre-retrain observation
            const SegmentFeedbackCursor feedback_cursor =
                adapter->snapshot_query_feedback(id);
            PendingMeasuredReward pending{};
            pending.segment = id;
            pending.window = current_window;
            pending.before_mean_ms = before_mean_ms;
            pending.before_correction_steps_per_query =
                before_correction_steps_per_query;
            pending.before_p99_ms = before_p99_ms;
            pending.cost_ms = cost_ms;
            pending.feedback_cursor = feedback_cursor;
            pending.feature_context = decision_context;
            pending_measured_rewards.push_back(std::move(pending));
            // Reward is applied after the window closes, using only reads that
            // occurred after this model was published.
          });
          phase1_cost_ms_sum += g_win.retrain_cost_ms_sum - cost_before;
          usedB_phase1++;
          g_retrained_segments_this_window.insert(c.seg_id);
          dbg_p1("[P1] win=" + std::to_string(current_window) + " step=" + std::to_string(step) +
                 " seg=" + std::to_string(c.seg_id) + " drift=" + std::to_string((int)c.drift) +
                 " already=" + (already_phase1 ? "1" : "0") +
                 " action=exec avoid=" + (gScenario.disable_avoid ? "0" : "1"));
          step++;
        }
        if (g_dbg_phase1)
        {
          std::ostringstream oss;
          oss << "[P1-END] win=" << current_window
              << " total_exec=" << usedB_phase1
              << " recorded_set_sz=" << g_retrained_segments_this_window.size()
              << " {";
          bool first = true;
          for (auto &sid : g_retrained_segments_this_window)
          {
            if (!first)
              oss << ",";
            first = false;
            oss << sid;
          }
          oss << "}";
          dbg_p1(oss.str());
        }
      }
      g_in_linucb_midwindow = false;
    }

    // Phase 1 may consume the complete repair budget. In that case phase 2
    // is correctly skipped, but the post-repair residual still has to be
    // measured. Previously the CSV retained its reset value (zero), making
    // B=1 experiments appear artificially perfect.
    if (baseline_finalized && linucb_phase_enabled &&
        !gScenario.fair_static && !gScenario.greedy_static && !gScenario.static_dp &&
        !g_flag_no_phase2 && usedB_phase1 >= effB && !executed_phase2_this_window)
    {
      topk_sum_post_phase2_cmp_per_query = compute_topk_sum(adapter, (size_t)DRIFT_K);
      if (raw_baseline_topk_sum_cmp_per_query > 0)
        triplet_post_ratio = topk_sum_post_phase2_cmp_per_query / raw_baseline_topk_sum_cmp_per_query;
      executed_phase2_this_window = true;
    }

  if (baseline_finalized && linucb_phase_enabled &&
      !gScenario.fair_static && !gScenario.greedy_static && !gScenario.static_dp &&
      (g_flag_no_phase2 || gScenario.periodic_static || gScenario.threshold_static))
  {
    topk_sum_post_phase2_cmp_per_query = compute_topk_sum(adapter, (size_t)DRIFT_K);
    if (raw_baseline_topk_sum_cmp_per_query > 0)
      triplet_post_ratio = topk_sum_post_phase2_cmp_per_query / raw_baseline_topk_sum_cmp_per_query;
  }

    if (baseline_finalized && linucb_phase_enabled &&
        !gScenario.fair_static && !gScenario.greedy_static && !gScenario.static_dp &&
        !g_flag_no_phase2 && usedB_phase1 < effB && !executed_phase2_this_window)
    {
      auto st = window_decision_snapshot.empty()
                    ? adapter->collect_all_stats()
                    : window_decision_snapshot;
      struct C2
      {
        int id;
        double drift;
        double cost_ms;
        double qps;
        double tail_ratio;
        double learned_gain;
      };
      std::vector<C2> cand;
      cand.reserve(st.size());
      for (const auto &s : st)
        if (s.drift > 0)
        {
          cand.push_back({s.seg_id, s.drift, std::max(0.05, s.est_cost_ms),
                          std::max(0.0, s.qps),
                          s.tail_latency_samples >= 512 &&
                                  s.warmup_tail_latency_samples >= 512 &&
                                  s.p99_read_ms >= s.warmup_p99_read_ms * 1.05 &&
                                  s.warmup_p99_read_ms > 0.0
                              ? std::clamp(s.p99_read_ms / s.warmup_p99_read_ms, 1.0, 1.5)
                              : 1.0,
                          phase1_controller.expected_reward(
                              static_cast<uint32_t>(s.seg_id), make_scheduler_arm(s).x)});
        }
      if (env_on("DEBUG_SEGMENT_P99"))
        for (const auto &c : cand)
          std::cerr << "[SEGMENT_P99_RANK] window=" << current_window
                    << " seg=" << c.id << " residual=" << c.drift
                    << " p99_ms=" << st[static_cast<size_t>(c.id)].p99_read_ms
                    << " warmup_p99_ms=" << st[static_cast<size_t>(c.id)].warmup_p99_read_ms
                    << " samples=" << st[static_cast<size_t>(c.id)].tail_latency_samples
                    << " warmup_samples=" << st[static_cast<size_t>(c.id)].warmup_tail_latency_samples
                    << " cost_ms=" << c.cost_ms << " tail_factor=" << c.tail_ratio << "\n";
      // Combine RQ1's service-relevant repair benefit with RQ6's robust,
      // median-normalized square-root cost penalty. Residual is weighted by
      // foreground demand and bounded measured tail degradation; the bounded
      // LinUCB gain carries post-publication repair feedback without dominating.
      std::vector<double> candidate_costs;
      candidate_costs.reserve(cand.size());
      for (const auto &c : cand) candidate_costs.push_back(c.cost_ms);
      double median_cost_ms = 1.0;
      if (!candidate_costs.empty())
      {
        const size_t mid = candidate_costs.size() / 2;
        std::nth_element(candidate_costs.begin(), candidate_costs.begin() + mid,
                         candidate_costs.end());
        median_cost_ms = std::max(0.05, candidate_costs[mid]);
      }
      std::stable_sort(cand.begin(), cand.end(), [median_cost_ms](const C2 &a, const C2 &b)
      {
        const double relative_cost_a =
            std::sqrt(std::clamp(a.cost_ms / median_cost_ms, 0.5, 2.0));
        const double relative_cost_b =
            std::sqrt(std::clamp(b.cost_ms / median_cost_ms, 0.5, 2.0));
        const double gain_a = std::clamp(1.0 + 0.5 * a.learned_gain, 0.5, 1.5);
        const double gain_b = std::clamp(1.0 + 0.5 * b.learned_gain, 0.5, 1.5);
        const double sa = a.drift * a.qps * a.tail_ratio * gain_a / relative_cost_a;
        const double sb = b.drift * b.qps * b.tail_ratio * gain_b / relative_cost_b;
        return sa == sb ? a.drift > b.drift : sa > sb;
      });
      int max_targets = -1;
      if (const char *v = getenv("LINUCB_PHASE2_MAX_TARGETS"))
      {
        int mt = atoi(v);
        if (mt > 0)
          max_targets = mt;
      }
      size_t cand_idx = 0;
      for (auto &c : cand)
      {
        if (usedB_phase1 + usedB_phase2 >= effB)
          break;
        if (max_targets > 0 && (int)usedB_phase2 >= max_targets)
          break;
        bool already = (g_retrained_segments_this_window.count(c.id) > 0);
        bool redundant = already;
        g_phase2_total_repairs++;
        if (redundant)
          g_phase2_redundant_repairs++;
        std::string action;
        if (!gScenario.disable_avoid && redundant)
        {
          action = "skip_redundant";
          dbg_p2("[P2] win=" + std::to_string(current_window) +
                 " cand_idx=" + std::to_string(cand_idx) +
                 " seg=" + std::to_string(c.id) +
                 " drift=" + std::to_string((int)c.drift) +
                 " already=1 redundant=1 avoid=1 action=" + action);
          cand_idx++;
          continue;
        }
        action = redundant ? "exec_redundant" : "exec";
        if (!gScenario.disable_avoid)
          g_retrained_segments_this_window.insert(c.id);
        const auto feedback_stat_it = std::find_if(
            st.begin(), st.end(), [&c](const SegmentStats &s) { return s.seg_id == c.id; });
        if (feedback_stat_it == st.end())
        {
          ++cand_idx;
          continue;
        }
        const SegmentStats feedback_stat = *feedback_stat_it;
        const double feedback_before_mean_ms = feedback_stat.mean_read_ms;
        const double feedback_before_p99_ms = feedback_stat.p99_read_ms;
        const double feedback_before_correction_steps =
            feedback_stat.correction_steps_per_query;
        const uint64_t feedback_before_queries = feedback_stat.correction_queries;
        const std::vector<double> feedback_context =
            make_scheduler_arm(feedback_stat).x;
        bool mark_late = (current_window == 0 && gScenario.late_injected &&
                          std::find(g_late_injected_segments.begin(),
                                    g_late_injected_segments.end(),
                                    c.id) != g_late_injected_segments.end());
        const double cost_before = g_win.retrain_cost_ms_sum;
        g_active_maintenance_phase = "phase2";
        auto done = [&, mark_late, feedback_before_mean_ms,
                     feedback_before_p99_ms, feedback_before_correction_steps,
                     feedback_before_queries, feedback_context]
                    (int id, double d_mean_read_ms, double, double cost_ms)
        {
          if (mark_late && d_mean_read_ms < 0)
            late_segments_repaired++;
          if (d_mean_read_ms >= 0.0 || feedback_before_queries < 32)
            return; // stale/failed publication or insufficient pre-retrain reads
          const SegmentFeedbackCursor feedback_cursor =
              adapter->snapshot_query_feedback(id);
          PendingMeasuredReward pending{};
          pending.segment = id;
          pending.window = current_window;
          pending.before_mean_ms = feedback_before_mean_ms;
          pending.before_correction_steps_per_query =
              feedback_before_correction_steps;
          pending.before_p99_ms = feedback_before_p99_ms;
          pending.cost_ms = cost_ms;
          pending.feedback_cursor = feedback_cursor;
          pending.feature_context = feedback_context;
          pending_measured_rewards.push_back(std::move(pending));
        };
        if (gScenario.disable_avoid && redundant)
          adapter->retrain_segment_from_stale_decision(c.id, done);
        else
          adapter->retrain_segment_async(c.id, done);
        phase2_cost_ms_sum += g_win.retrain_cost_ms_sum - cost_before;
        usedB_phase2++;
        phase2_used++;
        dbg_p2("[P2] win=" + std::to_string(current_window) +
               " cand_idx=" + std::to_string(cand_idx) +
               " seg=" + std::to_string(c.id) +
               " drift=" + std::to_string((int)c.drift) +
               " already=" + (already ? "1" : "0") +
               " redundant=" + (redundant ? "1" : "0") +
               " avoid=" + (gScenario.disable_avoid ? "0" : "1") +
               " action=" + action);
        cand_idx++;
      }
      executed_phase2_this_window = true;
      topk_sum_post_phase2_cmp_per_query = compute_topk_sum(adapter, (size_t)DRIFT_K);
      if (raw_baseline_topk_sum_cmp_per_query > 0)
        triplet_post_ratio = topk_sum_post_phase2_cmp_per_query / raw_baseline_topk_sum_cmp_per_query;
      if (g_dbg_phase2)
      {
        double rate = g_phase2_total_repairs ? (double)g_phase2_redundant_repairs / g_phase2_total_repairs : 0.0;
        std::ostringstream oss;
        oss << "[AVOID-METRICS] win=" << current_window
            << " phase2_total=" << g_phase2_total_repairs
            << " redundant=" << g_phase2_redundant_repairs
            << " rate=" << std::fixed << std::setprecision(4) << rate;
        dbg_p2(oss.str());
      }
    }

    // Naive baseline performs no maintenance.
    // Its post-maintenance residual is the current residual.
    if (baseline_finalized && Config.policy == "naive")
    {
      topk_sum_post_phase2_cmp_per_query =
          compute_topk_sum(adapter, (size_t)DRIFT_K);

      if (raw_baseline_topk_sum_cmp_per_query > 0)
        triplet_post_ratio =
            topk_sum_post_phase2_cmp_per_query / raw_baseline_topk_sum_cmp_per_query;
    }

    uint64_t delta = 0;
    for (size_t i = 0; i < N; ++i)
    {
      const uint64_t now_tput = params[i]->throughput.load(std::memory_order_relaxed);
      delta += now_tput - tput_hist[i];
      tput_hist[i] = now_tput;
    }
    sec_tput.push_back(delta);
    if (sec_tput.size() > (size_t)WIN)
      sec_tput.erase(sec_tput.begin());

    // RQ5 defines proof_rate as the probability of auditing one point at each
    // control-window boundary, not as a fraction of foreground requests.  The
    // previous once-per-second opportunity silently doubled the advertised
    // sampling opportunities for two-second windows.
    if (end_of_window && Config.verify_layer == "merklesum" && Config.proof_rate > 0.0)
    {
      std::uniform_real_distribution<double> U(0.0, 1.0);
      if (U(rng_local) < Config.proof_rate)
      {
        const uint64_t proof_key = exist_keys.empty()
                                       ? 0
                                       : static_cast<uint64_t>(exist_keys[
                                             static_cast<size_t>(rng_local() % exist_keys.size())]);
        const auto gen_begin = std::chrono::steady_clock::now();
        const auto proof = adapter->mst_range_proof(proof_key, proof_key);
        const auto gen_end = std::chrono::steady_clock::now();
        const uint64_t root = adapter->mst_root_hash();
        const auto ver_begin = std::chrono::steady_clock::now();
        const bool proof_ok = mks::MerkleSum().verify(proof, root);
        const auto ver_end = std::chrono::steady_clock::now();
        last_proof_gen_us = std::chrono::duration<double, std::micro>(gen_end - gen_begin).count();
        last_proof_ver_us = std::chrono::duration<double, std::micro>(ver_end - ver_begin).count();
        g_win.proof_cnt++;
        g_win.proof_gen_ns_sum += static_cast<uint64_t>(last_proof_gen_us * 1000.0);
        g_win.proof_ver_ns_sum += static_cast<uint64_t>(last_proof_ver_us * 1000.0);
        if (!proof_ok)
          g_win.proof_fail++;
      }
    }

    if (end_of_window)
    {
      double tput_avg = 0.0;
      for (auto v : sec_tput)
        tput_avg += (double)v;
      if (!sec_tput.empty())
        tput_avg /= (double)sec_tput.size();
      static double last_win_tput_avg = 0.0;
      static double last_win_p99_ms = 0.0;
      std::vector<uint32_t> window_latencies;
      for (size_t i = 0; i < N; ++i)
      {
        std::lock_guard<std::mutex> lk(params[i]->lat_mu);
        window_latencies.insert(window_latencies.end(),
                                params[i]->lat_samples_ns.begin(),
                                params[i]->lat_samples_ns.end());
        params[i]->lat_samples_ns.clear();
      }
      double p99_after_ms = 0.0;
      if (!window_latencies.empty())
      {
        const size_t rank = (window_latencies.size() * 99 + 99) / 100;
        const size_t idx = std::min(window_latencies.size() - 1, rank - 1);
        std::nth_element(window_latencies.begin(), window_latencies.begin() + idx,
                         window_latencies.end());
        p99_after_ms = static_cast<double>(window_latencies[idx]) / 1.0e6;
      }
      const CorrectionCoverage correction_coverage = adapter->current_correction_coverage();
      if (Config.policy == "linucb" && g_flag_single_phase)
        g_win.retrain_cnt = (int)g_retrained_segments_this_window.size();
      double avg_gen_us = g_win.proof_cnt ? (double)g_win.proof_gen_ns_sum / g_win.proof_cnt / 1000.0 : 0.0;
      double avg_ver_us = g_win.proof_cnt ? (double)g_win.proof_ver_ns_sum / g_win.proof_cnt / 1000.0 : 0.0;
      double phase1_ratio = (usedB_phase1 + usedB_phase2) ? (double)usedB_phase1 / (usedB_phase1 + usedB_phase2) : 0.0;
      // Real retraining latency statistics for this window
    size_t retrain_exec_cnt = g_win.retrain_cost_ms_samples.size();

    double retrain_latency_mean_ms = 0.0;
    double retrain_latency_p50_ms = 0.0;
    double retrain_latency_p95_ms = 0.0;
    double retrain_latency_max_ms = 0.0;

    if (!g_win.retrain_cost_ms_samples.empty())
    {
        std::vector<double> retrain_sorted = g_win.retrain_cost_ms_samples;
        std::sort(retrain_sorted.begin(), retrain_sorted.end());

        double retrain_sum = 0.0;
        for (double x : retrain_sorted)
            retrain_sum += x;

        retrain_latency_mean_ms =
            retrain_sum / static_cast<double>(retrain_sorted.size());

        const size_t n = retrain_sorted.size();

        // Nearest-rank percentiles
        size_t p50_idx = (n * 50 + 99) / 100;
        size_t p95_idx = (n * 95 + 99) / 100;

        if (p50_idx > 0) --p50_idx;
        if (p95_idx > 0) --p95_idx;

        if (p50_idx >= n) p50_idx = n - 1;
        if (p95_idx >= n) p95_idx = n - 1;

        retrain_latency_p50_ms = retrain_sorted[p50_idx];
        retrain_latency_p95_ms = retrain_sorted[p95_idx];
        retrain_latency_max_ms = retrain_sorted.back();
    }

    if (use_correction_excess_signal())
    {
      auto observed = adapter->current_correction_residuals();
      std::sort(observed.begin(), observed.end(), std::greater<double>());
      const size_t observed_k = std::min(observed.size(), static_cast<size_t>(std::max(1, DRIFT_K)));
      double observed_topk = 0.0;
      for (size_t i = 0; i < observed_k; ++i)
        observed_topk += observed[i];
      topk_sum_post_phase2_cmp_per_query = observed_topk;
      if (injected_this_window)
      {
        topk_sum_post_injection_cmp_per_query = observed_topk;
        raw_baseline_topk_sum_cmp_per_query = observed_topk;
        budget_oracle_topk_target_cmp_per_query = 0.0;
        const size_t ideal_repairs = std::min(observed_k, static_cast<size_t>(Config.budget_B));
        for (size_t i = ideal_repairs; i < observed_k; ++i)
          budget_oracle_topk_target_cmp_per_query += observed[i];
      }
    }

    if (csv_logger && csv_logger->good())
      {
        static bool header = false;
        if (!header)
        {
          (*csv_logger->ostream())
              << "time_ms,window_id,policy,baseline_tag,budget_B,budget_used,"
              << "tput_before,tput_after,p99_before_ms,p99_after_ms,"
              << "retrain_cost_ms_sum,retrain_exec_cnt,retrain_latency_mean_ms,"
            << "retrain_latency_p50_ms,retrain_latency_p95_ms,retrain_latency_max_ms,"
            << "phase1_cost_ms_sum,phase2_cost_ms_sum,"
              << "usedB_phase1,usedB_phase2,phase2_used,phase1_ratio,"
              << "proof_gen_us_last,proof_ver_us_last,proof_samples,proof_failures,"
              << "proof_gen_avg_us,proof_ver_avg_us,"
              << "raw_baseline_topk_sum_cmp_per_query,"
              << "topk_sum_post_injection_cmp_per_query,topk_sum_post_phase2_cmp_per_query,peak_topk_sum_cmp_per_query,triplet_post_ratio,"
              << "budget_oracle_topk_target_cmp_per_query,"
              << "injection_flag,phase2_total_repairs,phase2_redundant_repairs,phase2_redundant_rate,"
              << "mid_inject_flag,late_inject_flag,late_segments_repaired,tail_active_count,"
              << "routed_reads_total,fallback_reads_total,checked_reads_total,"
              << "invalidated_models_total,rejected_publications_total,actual_writes_total,"
              << "root_correction_steps_per_routed_query,prediction_bias_max_keys,feedback_mode,"
              << "p99_sample_count,min_segment_correction_queries,min_segment_cmp_per_query,min_segment_cumulative_read_observations\n";
          header = true;
        }
        int injection_flag = injected_this_window ? 1 : 0;
        std::string baseline_tag = "adaptive";
        if (gScenario.greedy_static)
          baseline_tag = "greedy";
        else if (gScenario.static_dp_limited)
          baseline_tag = "staticdp_limited";
        else if (gScenario.static_dp)
          baseline_tag = "staticdp";
        else if (gScenario.fair_static)
          baseline_tag = "staticfair";
    else if (gScenario.periodic_static)
        baseline_tag = "periodic";
    else if (gScenario.threshold_static)
        baseline_tag = "threshold";
        else if (Config.policy == "naive")
          baseline_tag = "naive";
        else if (g_flag_single_phase)
          baseline_tag = "greedy";
        else if (g_flag_disable_adapt && !g_flag_no_phase2)
          baseline_tag = "staticdp";
        else if (g_flag_no_phase2)
          baseline_tag = "nophase2";
        else if (gScenario.disable_avoid)
          baseline_tag = "noavoid";
        else if (gScenario.disable_topk)
          baseline_tag = "notopk";
        else if (Config.policy == "off")
          baseline_tag = "off";
        double p2_rate = g_phase2_total_repairs ? (double)g_phase2_redundant_repairs / g_phase2_total_repairs : 0.0;
        int64_t now_ms = (int64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
                             std::chrono::steady_clock::now().time_since_epoch())
                             .count();
        (*csv_logger->ostream())
            << now_ms << ","
            << (current_window + 1) << ","
            << Config.policy << ","
            << baseline_tag << ","
            << Config.budget_B << ","
            << (usedB_phase1 + usedB_phase2) << ","
            << last_win_tput_avg << ","
            << tput_avg << ","
            << last_win_p99_ms << ","
            << p99_after_ms << ","
            << g_win.retrain_cost_ms_sum << ","
            << retrain_exec_cnt << ","
            << retrain_latency_mean_ms << ","
            << retrain_latency_p50_ms << ","
            << retrain_latency_p95_ms << ","
            << retrain_latency_max_ms << ","
            << phase1_cost_ms_sum << ","
            << phase2_cost_ms_sum << ","
            << usedB_phase1 << ","
            << usedB_phase2 << ","
            << phase2_used << ","
            << phase1_ratio << ","
            << last_proof_gen_us << ","
            << last_proof_ver_us << ","
            << g_win.proof_cnt << ","
            << g_win.proof_fail << ","
            << avg_gen_us << ","
            << avg_ver_us << ","
            << raw_baseline_topk_sum_cmp_per_query << ","
            << topk_sum_post_injection_cmp_per_query << ","
            << topk_sum_post_phase2_cmp_per_query << ","
            << peak_topk_sum_cmp_per_query << ","
            << triplet_post_ratio << ","
            << budget_oracle_topk_target_cmp_per_query << ","
            << injection_flag << ","
            << g_phase2_total_repairs << ","
            << g_phase2_redundant_repairs << ","
            << p2_rate << ","
            << (mid_inject_flag ? 1 : 0) << ","
            << (late_inject_flag ? 1 : 0) << ","
            << late_segments_repaired << ","
            << adapter->tail_active_count() << ","
            << adapter->routed_reads() << ","
            << adapter->fallback_reads() << ","
            << adapter->checked_reads() << ","
            << adapter->invalidated_models() << ","
            << adapter->rejected_publications() << ","
            << adapter->actual_writes() << ","
            << adapter->biased_root_correction_steps_per_query() << ","
            << adapter->max_prediction_bias_keys() << ","
            << (use_correction_excess_signal() ? "measured_excess_correction_comparisons_per_query" :
             (g_measured_feedback ? "measured_writes" : "controlled_synthetic_residual"))
            << "," << window_latencies.size()
            << "," << correction_coverage.min_queries
            << "," << correction_coverage.min_comparisons_per_query
            << "," << adapter->minimum_cumulative_read_observations()
            << "\n";
        if (phase_budget_csv.good())
        {
          const double topk_reference_cmp_per_query = 1.0;
          phase_budget_csv << (current_window + 1) << ','
                           << budget_U << ',' << budget_R << ',' << budget_rho << ','
                           << budget_B1 << ',' << budget_B2 << ','
                           << usedB_phase1 << ',' << usedB_phase2 << ','
                           << p1_starvation_windows << ',' << p2_starvation_windows << ','
                           << (budget_forced_fair_split ? 1 : 0) << ','
                           << phase1_budget_credit << ','
                           << topk_reference_cmp_per_query << '\n';
          phase_budget_csv.flush();
        }
      }
      last_win_tput_avg = tput_avg;
      last_win_p99_ms = p99_after_ms;
      g_win.reset();
      adapter->begin_observation_window();
    }
    ++current_sec;
  }

  running = false;
  for (size_t i = 0; i < N; ++i)
  {
    void *st = nullptr;
    pthread_join(threads[i], &st);
  }
  adapter->emit_current_model_routes(static_cast<int>(
      std::max<size_t>(1, (sec + static_cast<size_t>(WIN) - 1) /
                              static_cast<size_t>(WIN))));
  size_t total_tput = 0;
  for (size_t i = 0; i < N; ++i)
    total_tput += params[i]->throughput.load(std::memory_order_relaxed);
  COUT_THIS("[micro] Throughput(op/s): " << (sec ? (total_tput / sec) : total_tput));
  for (auto *p : params)
    delete p;
}

int main(int argc, char **argv)
{
  preprocess_claims_args(argc, argv);
  parse_args(argc, argv);

  g_flag_single_phase = env_on("LINUCB_SINGLE_PHASE");
  g_flag_disable_runtime = env_on("LINUCB_DISABLE_RUNTIME");
  g_flag_disable_adapt = env_on("LINUCB_DISABLE_ADAPT") ||
                         g_flag_disable_runtime ||
                         g_flag_single_phase;
  g_flag_use_max_only = env_on("USE_MAX_ONLY");
  g_flag_select_random = env_on("SELECT_RANDOM");
  g_flag_no_phase2 = env_on("NO_PHASE2");
  g_flag_output_debug = env_on("SHOW_PHASE2_DEBUG") || env_on("SHOW_TOPK_DEBUG");
  g_measured_feedback = env_on("MEASURED_FEEDBACK");
  if (g_measured_feedback)
  {
    if (Config.benchmark != 13)
      throw std::invalid_argument("MEASURED_FEEDBACK currently requires benchmark=13 (SOSD)");
    g_write_warmup_sec = getenv("WRITE_WARMUP_SEC")
        ? std::max(1, atoi(getenv("WRITE_WARMUP_SEC")))
        : std::max(1, Config.win_sec) * 10;
    if (Config.read_ratio >= 1.0 || Config.insert_ratio + Config.update_ratio + Config.delete_ratio <= 0.0)
      throw std::invalid_argument("MEASURED_FEEDBACK requires real writes: set read/update/insert/delete ratios");
    if (env_on("SIMULATED_DRIFT_WAIT"))
      throw std::invalid_argument("MEASURED_FEEDBACK cannot use SIMULATED_DRIFT_WAIT");
    if (Config.insert_ratio > 0 && !getenv("SOSD_INSERT_SAMPLE_FILE"))
      throw std::invalid_argument("MEASURED_FEEDBACK insert workload requires SOSD_INSERT_SAMPLE_FILE");
  }
  init_avoid_debug_flags();

  if (gScenario.proof_rate_override >= 0.0)
    Config.proof_rate = gScenario.proof_rate_override;

  load_data();
  if (g_measured_feedback && Config.insert_ratio > 0)
  {
    const char *file = getenv("SOSD_INSERT_SAMPLE_FILE");
    std::ifstream input(file, std::ios::binary | std::ios::ate);
    if (!input || input.tellg() <= 0 || (input.tellg() % static_cast<std::streamoff>(sizeof(key_type))) != 0)
      throw std::invalid_argument("SOSD_INSERT_SAMPLE_FILE must be a nonempty raw uint64 file");
    const size_t count = static_cast<size_t>(input.tellg()) / sizeof(key_type);
    input.seekg(0);
    non_exist_keys.resize(count);
    input.read(reinterpret_cast<char *>(non_exist_keys.data()), count * sizeof(key_type));
    if (!input || !std::is_sorted(non_exist_keys.begin(), non_exist_keys.end()) ||
        std::adjacent_find(non_exist_keys.begin(), non_exist_keys.end()) != non_exist_keys.end())
      throw std::invalid_argument("insert keys must be sorted and unique");
    for (auto key : non_exist_keys)
      if (std::binary_search(exist_keys.begin(), exist_keys.end(), key))
        throw std::invalid_argument("insert pool overlaps the training keys");
  }
  init_base_latency_from_env();
  detect_drift_enabled_once();
  if (g_measured_feedback) g_drift_enabled = true;

  aidel_type *ai = new aidel_type();
  ai->train(exist_keys, exist_keys, Config.maxErr);
  auto err_stats = compute_error_stats(ai, exist_keys);
  ai->self_check();

  auto getenv_i = [](const char *k, int d) -> int
  { if(const char* v=getenv(k)){ try{return std::stoi(v);}catch(...){}} return d; };
  int seg_cnt = getenv_i("SEGMENT_COUNT", 256);
  AidelAdapter adapter(ai, exist_keys, (size_t)seg_cnt);

  // The benchmark owns the per-window scheduler. Running the background
  // runtime as well would double-spend the maintenance budget and produce
  // unlogged retrains.
  bool runtime_active = false;
  std::unique_ptr<LinVeriXRuntime> rt;
  if (runtime_active)
  {
    LinVeriXRuntime::Config cfg;
    cfg.epoch_ms = std::max(1, Config.win_sec) * 1000;
    cfg.budget_B = Config.budget_B;
    cfg.alpha = Config.alpha;
    rt.reset(new LinVeriXRuntime(&adapter, cfg));
    rt->start();
  }

  VerifyService::Config vcfg;
  vcfg.num_workers = Config.thread_num;
  vcfg.queue_cap = 1 << 16;
  vcfg.batch_max = (gScenario.proof_batch_override > 0) ? gScenario.proof_batch_override : 4096;
  vcfg.batch_interval_ms = 2;
  vcfg.point_proof_sample =
      (Config.verify_layer == "merklesum") ? Config.proof_rate : 0.0;
  VerifyService verifier(&adapter, vcfg);
  verifier.start();

  CsvLogger logger(Config.csv_log, true);
  run_benchmark(ai, &adapter, &verifier, Config.runtime, err_stats, &logger, ai->model_size());

  if (rt)
    rt->stop();
  verifier.stop();
  if (Config.verify_layer == "merklesum" && Config.proof_rate > 0.0)
    run_verification(ai);
  ai->self_check();
  delete ai;
  return 0;
}
