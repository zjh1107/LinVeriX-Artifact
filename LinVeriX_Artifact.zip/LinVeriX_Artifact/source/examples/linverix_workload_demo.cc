#include <iostream>
#include <random>
#include <chrono>
#include <thread>
#include <vector>
#include "levelindex.h"
#include "linverix_adapter_levelindex.h"
#include "linverix_runtime.h"
#include "csv_logger.h"

using Clock = std::chrono::high_resolution_clock;

int main(){
  // 1) 数据与索引
  const size_t N = 1000000;
  std::vector<uint64_t> data; data.reserve(N);
  for (uint64_t k=1;k<=N;++k) data.push_back(k);
  LevelIndex<uint64_t> index(data);

  // 2) 适配器 + Merkle-sum
  LevelIndexAdapter<uint64_t> adapter(&index);
  adapter.mst_build_if_needed();

  // 3) 启动 LinUCB 后台控制
  LinVeriXRuntime::Config cfg; cfg.epoch_ms=1000; cfg.budget_B=4; cfg.alpha=1.0;
  LinVeriXRuntime runtime(&adapter, cfg);
  runtime.start();

  // 4) 工作负载参数
  int seconds = 20;
  double write_ratio = 0.1;     // 10% 写
  int range_every = 10000;      // 每 1 万次请求做一次范围查询
  uint64_t range_len = 10000;   // 范围长度

  std::mt19937_64 rng(42);
  std::uniform_int_distribution<uint64_t> key_dist(1, N);
  std::bernoulli_distribution wr(write_ratio);

  // 5) CSV 指标
  CsvLogger qpslog("qps_latency.csv", {"sec","ops","p99_ema_hint"});
  CsvLogger prooflog("proof_metrics.csv", {"t_ms","lkey","rkey","covers","proof_ok","gen_us","verify_us"});

  size_t ops=0;
  auto start = Clock::now();
  for (int sec=0; sec<seconds; ++sec){
    auto sec_start = Clock::now();
    // 模拟每秒 ~100k 请求
    while (std::chrono::duration<double>(Clock::now()-sec_start).count() < 1.0){
      uint64_t k = key_dist(rng);
      auto t0 = Clock::now();
      // 查询路径
      size_t pos = index.find(k);
      (void)pos;
      // 写入路径（这里只是记统计；若你有真实写API，可在这里更新索引与 Merkle-sum）
      bool is_write = wr(rng);
      if (is_write){
        // 例如：adapter.mst_update_by_key(k, 1); // COUNT 语义不变
      }
      auto t1 = Clock::now();
      double lat_ms = std::chrono::duration<double,std::milli>(t1-t0).count();
      adapter.note_query_by_key(k, lat_ms, is_write);
      ++ops;

      if (ops % range_every == 0){
        uint64_t l = key_dist(rng);
        uint64_t r = std::min<uint64_t>(l+range_len, N);
        auto p0 = Clock::now();
        auto proof = adapter.mst_range_proof(l, r);
        auto p1 = Clock::now();
        // 验证（用同一实现的 verify）
        bool ok = mks::MerkleSum().verify(proof, adapter.mst_root_hash());
        auto p2 = Clock::now();
        long gen_us = std::chrono::duration_cast<std::chrono::microseconds>(p1-p0).count();
        long ver_us = std::chrono::duration_cast<std::chrono::microseconds>(p2-p1).count();
        prooflog.row((long)std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now()-start).count(),
                     l, r, (long)proof.covers.size(), ok?1:0, gen_us, ver_us);
      }
    }
    // 写每秒的简单统计（p99_ema 为 adapter 内部的一个近似）
    qpslog.row(sec+1, (long)ops, 0.0 /*你可改为读取 adapter 的每段 p99 并求 max/avg*/);
  }

  runtime.stop();
  std::cout << "Workload complete. Metrics written to qps_latency.csv and proof_metrics.csv\n";
  return 0;
}