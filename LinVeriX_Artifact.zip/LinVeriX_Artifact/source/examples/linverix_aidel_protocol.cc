#include <iostream>
#include <pthread.h>
#include <atomic>
#include <vector>
#include <random>
#include <chrono>
#include <mutex>
#include <shared_mutex>
#include <unordered_set>
#include <algorithm>
#include <unordered_map>
#include <sstream>
#include <iomanip>
#include <unistd.h>
#include <cmath>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <memory>
#include <limits>
#include <stdexcept>

#include "function.h"
#include "aidel.h"
#include "aidel_impl.h"
#include "linverix_adapter.h"
#include "linverix_runtime.h"
#include "metrics_collector.h"
#include "merklesum_tree.h"
#include "verify_service.h"
#include "aidel_metrics.h"
#include "p99_sampler.h"
#include "util/busy_wait.h"
#include "util/CsvLogger.h"
#include "config/base_latency.h"

#ifndef CACHELINE_SIZE
#define CACHELINE_SIZE 64
#endif

using aidel_type = aidel::AIDEL<key_type, val_type>;

struct ClaimsScenario
{
  struct Bucket
  {
    int count;
    uint32_t extra_ns;
  };
  std::vector<Bucket> longtail;
  bool enable_midlate = false;
  int K_start = 0, K_mid = 0, K_late = 0;
  double mid_time_s = 0.0, late_time_s = 0.0;
  int mid_global_sec = -1, late_global_sec = -1;
  bool mid_injected = false, late_injected = false;
  bool tail_enable = false;
  double tail_retention_factor = 0.2;
  double tail_decay_us = 10.0;
  bool disable_topk = false;
  bool disable_avoid = false;
  bool fair_static = false;
  bool greedy_static = false;
  bool static_dp = false;
  bool static_dp_limited = false;
    bool periodic_static = false;
    bool threshold_static = false;
  double proof_rate_override = -1.0;
  int proof_batch_override = -1;
  bool active() const
  {
    return !longtail.empty() || enable_midlate || tail_enable ||
           disable_topk || disable_avoid || fair_static || greedy_static ||
           static_dp || static_dp_limited ||
           proof_rate_override >= 0.0 || K_start > 0 || K_mid > 0 || K_late > 0;
  }
} gScenario;

static thread_local bool g_in_linucb_midwindow = false;
static bool g_drift_enabled = true;
static std::unordered_set<int> g_retrained_segments_this_window;

static bool g_flag_single_phase = false;
static bool g_flag_disable_runtime = false;
static bool g_flag_disable_adapt = false;
static bool g_flag_use_max_only = false;
static bool g_flag_select_random = false;
static bool g_flag_no_phase2 = false;
static bool g_flag_output_debug = false;

static bool g_dbg_master = false;
static bool g_dbg_phase1 = false;
static bool g_dbg_phase2 = false;

static uint64_t g_phase2_total_repairs = 0;
static uint64_t g_phase2_redundant_repairs = 0;

static std::vector<int> g_start_injected_segments;
static std::vector<int> g_mid_injected_segments;
static std::vector<int> g_late_injected_segments;

struct WindowAgg
{
  uint64_t proof_gen_ns_sum = 0;
  uint64_t proof_ver_ns_sum = 0;
  uint64_t proof_cnt = 0;
  uint64_t proof_fail = 0;

  // RQ5 controlled fault-injection statistics.
  uint64_t fault_attempts = 0;
  uint64_t fault_detected = 0;
  uint64_t false_positives = 0;

  uint64_t retrain_cnt = 0;
  double retrain_cost_ms_sum = 0.0;
    std::vector<double> retrain_cost_ms_samples;
  void reset()
  {
    proof_gen_ns_sum = proof_ver_ns_sum = proof_cnt = proof_fail = 0;
    fault_attempts = fault_detected = false_positives = 0;
    retrain_cnt = 0;
    retrain_cost_ms_sum = 0.0;
        retrain_cost_ms_samples.clear();
  }
} g_win;
static double last_proof_gen_us = 0.0;
static double last_proof_ver_us = 0.0;

static inline bool env_on(const char *k)
{
  if (const char *v = getenv(k))
    return (*v == 0) || strcmp(v, "0") != 0;
  return false;
}
static inline void init_avoid_debug_flags()
{
  bool trace = env_on("SHOW_AVOID_TRACE");
  bool dbg = env_on("SHOW_AVOID_DEBUG");
  bool p1 = env_on("SHOW_AVOID_PHASE1");
  bool p2 = env_on("SHOW_AVOID_PHASE2");
  g_dbg_master = trace || dbg;
  g_dbg_phase1 = g_dbg_master || p1;
  g_dbg_phase2 = g_dbg_master || p2;
}
static inline void dbg_p1(const std::string &s)
{
  if (g_dbg_phase1)
    std::cerr << s << "\n";
}
static inline void dbg_p2(const std::string &s)
{
  if (g_dbg_phase2)
    std::cerr << s << "\n";
}

static void detect_drift_enabled_once()
{
  auto gl = [](const char *k, long long d) -> long long
  {
    if (const char *v = getenv(k))
    {
      try
      {
        return std::stoll(v);
      }
      catch (...)
      {
      }
    }
    return d;
  };
  long long interval = gl("DRIFT_INTERVAL_SEC", 0);
  long long K = gl("DRIFT_K", 0);
  long long lat = gl("DRIFT_LAT_NS_PER_SEG", 0);
  long long p99 = gl("DRIFT_P99_MS", 0);
  long long err = gl("DRIFT_ERR", 0);
  bool periodic = (interval > 0) && (K > 0 || lat > 0 || p99 > 0 || err > 0);
  bool staged = (!gScenario.longtail.empty()) || gScenario.K_start > 0 ||
                gScenario.K_mid > 0 || gScenario.K_late > 0 || gScenario.enable_midlate ||
                gScenario.tail_enable;
  g_drift_enabled = periodic || staged;
  std::cerr << "[init] drift_enabled=" << g_drift_enabled
            << " periodic=" << periodic
            << " staged=" << staged << "\n";
}

class AidelAdapter : public IIndexAdapter
{
public:
  explicit AidelAdapter(aidel_type *ai, const std::vector<key_type> &keys, size_t segments = 256)
      : ai_(ai), segments_(segments), keys_snapshot_(keys)
  {
    if (segments_ == 0)
      throw std::invalid_argument("segments must be greater than zero");
    segment_keys_.resize(segments_);
    segment_vals_.resize(segments_);
    installed_segment_models_.resize(segments_);
    for (const auto &k : keys_snapshot_)
    {
      const size_t s = segment_of_key_(k);
      segment_keys_[s].push_back(k);
      segment_vals_[s].push_back(static_cast<val_type>(k));
    }
    std::vector<std::pair<uint64_t, uint64_t>> kv;
    if (Config.verify_layer == "merklesum" && Config.proof_rate > 0.0)
    {
      kv.reserve(keys.size());
      for (const auto &k : keys)
        kv.emplace_back(static_cast<uint64_t>(k), static_cast<uint64_t>(k));
    }
    mst_.build(kv);
    stats_.resize(segments_);
    ema_p99_.assign(segments_, 5.0);
    max_err_.assign(segments_, 50.0);
    qps_.assign(segments_, 0.0);
    write_ratio_.assign(segments_, 0.1);
    size_mb_.assign(segments_, 0.0);
    last_rt_sec_.assign(segments_, 60.0);
    est_cost_ms_.assign(segments_, 0.001);
    for (size_t s = 0; s < segments_; ++s)
    {
      size_mb_[s] = std::max(1e-6,
          segment_keys_[s].size() * (sizeof(key_type) + sizeof(val_type)) /
              (1024.0 * 1024.0));
      // Initial estimate is proportional to actual training-set size; it is
      // replaced by measured wall-clock training cost after the first repair.
      est_cost_ms_[s] = std::max(0.001, segment_keys_[s].size() * 0.0001);
    }
    drift_.assign(segments_, 0.0);
    last_drift_observed_.assign(segments_, 0.0);
    drift_slope_ema_.assign(segments_, 0.0);
    seg_extra_ns_.reset(new std::atomic<uint32_t>[segments_]);
    tail_active_.assign(segments_, 0);
    for (size_t i = 0; i < segments_; ++i)
      seg_extra_ns_[i].store(0, std::memory_order_relaxed);
    last_snapshot_ = std::chrono::steady_clock::now();
    for (size_t s = 0; s < segments_; ++s)
      stats_[s].seg_id = (int)s;
    if (const char *m = getenv("DRIFT_RESET_MODE"))
      if (std::string(m) == "never")
        drift_reset_mode_ = 1;
  }
  std::vector<SegmentStats> collect_all_stats() override
  {
    std::lock_guard<std::mutex> lk(mu_);
    decay_qps_locked();
    if (gScenario.tail_enable && gScenario.tail_decay_us > 0)
    {
      uint32_t dec_ns = (uint32_t)(gScenario.tail_decay_us * 1000.0);
      for (size_t i = 0; i < segments_; ++i)
      {
        if (!tail_active_[i])
          continue;
        uint32_t cur = seg_extra_ns_[i].load(std::memory_order_relaxed);
        if (cur > dec_ns)
          seg_extra_ns_[i].store(cur - dec_ns, std::memory_order_relaxed);
        else
        {
          seg_extra_ns_[i].store(0, std::memory_order_relaxed);
          tail_active_[i] = 0;
        }
      }
    }
    for (size_t s = 0; s < segments_; ++s)
    {
      stats_[s].seg_id = (int)s;
      stats_[s].max_err = max_err_[s];
      const double cur_drift =
          static_cast<double>(seg_extra_ns_[s].load(std::memory_order_relaxed)) / 1000.0;
      const double delta = cur_drift - last_drift_observed_[s];
      // collect_all_stats() may be called several times in one window.  Keep
      // the most recent real change instead of overwriting the slope with 0.
      if (std::abs(delta) > 1e-9)
      {
        drift_slope_ema_[s] = 0.70 * drift_slope_ema_[s] + 0.30 * delta;
        last_drift_observed_[s] = cur_drift;
      }
      stats_[s].err_slope = drift_slope_ema_[s];
      stats_[s].qps = qps_[s];
      stats_[s].write_ratio = write_ratio_[s];
      stats_[s].p99_read_ms = ema_p99_[s];
      stats_[s].size_mb = size_mb_[s];
      stats_[s].last_retrain_sec = last_rt_sec_[s];
      stats_[s].est_cost_ms = est_cost_ms_[s];
      stats_[s].drift = cur_drift;
    }
    return stats_;
  }
  void retrain_segment_async(int seg_id, RetrainDone cb) override
  {
    retrain_segment_impl(seg_id, std::move(cb), false);
  }

  // Execute a decision that was legitimately issued from the same pre-repair
  // window snapshot even if another phase has already repaired the segment.
  // This models the real wasted work exposed by the NoAvoid ablation.  Normal
  // LinVeriX never calls this path because its reservation set suppresses the
  // duplicate before execution.
  void retrain_segment_from_stale_decision(int seg_id, RetrainDone cb)
  {
    retrain_segment_impl(seg_id, std::move(cb), true);
  }

private:
  void retrain_segment_impl(int seg_id, RetrainDone cb, bool honor_stale_decision)
  {
    if (seg_id < 0 || static_cast<size_t>(seg_id) >= segments_)
    {
      std::cerr << "[REAL_RETRAIN] invalid segment id=" << seg_id << "\n";
      if (cb)
        cb(seg_id, 0.0, 0.0, 0.0);
      return;
    }
    uint64_t min_extra_ns = 1;
    if (const char *v = getenv("MIN_EXTRA_NS_FOR_RETRAIN"))
      min_extra_ns = strtoull(v, nullptr, 10);
    bool skip_costless = true;
    if (const char *v = getenv("SKIP_COSTLESS_RETRAIN"))
      skip_costless = (atoi(v) != 0);
    double cooldown_sec = 0.0;
    if (const char *v = getenv("RETRAIN_COOLDOWN_SEC"))
      cooldown_sec = atof(v);
    uint32_t extra = seg_extra_ns_[seg_id].load(std::memory_order_acquire);
    {
      std::lock_guard<std::mutex> lk(mu_);
      bool cooldown_block = (cooldown_sec > 0 && last_rt_sec_[seg_id] < cooldown_sec);
      if (!honor_stale_decision && (extra < min_extra_ns || cooldown_block))
      {
        if (!skip_costless && !(g_flag_single_phase && Config.policy == "linucb"))
          g_win.retrain_cnt++;
        if (cb)
          cb(seg_id, 0.0, 0.0, 0.0);
        return;
      }
    }
    // ------------------------------------------------------------
    // Measured retraining cost using actual AIDEL training
    // ------------------------------------------------------------
    const auto &retrain_keys = segment_keys_[static_cast<size_t>(seg_id)];
    const auto &retrain_vals = segment_vals_[static_cast<size_t>(seg_id)];

    double cost_ms_measured = 0.0;

    if (!retrain_keys.empty())
    {
        auto replacement = std::make_unique<aidel_type>();
        const auto t0 = std::chrono::steady_clock::now();
        replacement->train(retrain_keys, retrain_vals, Config.maxErr);
        const auto t1 = std::chrono::steady_clock::now();

        cost_ms_measured =
            std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::cout << "[REAL_RETRAIN] seg=" << seg_id
                  << " keys=" << retrain_keys.size()
                  << " cost_ms=" << cost_ms_measured
                  << std::endl;

        // Publish only a successfully trained replacement. These per-segment
        // models are the maintained model state used by the scheduler/auditor;
        // the monolithic foreground AIDEL instance remains the data container.
        {
          std::lock_guard<std::mutex> lk(mu_);
          installed_segment_models_[static_cast<size_t>(seg_id)] = std::move(replacement);
          ema_p99_[seg_id] = std::max(0.5, ema_p99_[seg_id] - 1.5);
          max_err_[seg_id] = std::max(0.0, max_err_[seg_id] - 3.0);
          last_rt_sec_[seg_id] = 0.0;
          if (gScenario.tail_enable)
          {
            uint64_t nv = static_cast<uint64_t>(extra * gScenario.tail_retention_factor);
            seg_extra_ns_[seg_id].store(static_cast<uint32_t>(std::max<uint64_t>(1000, nv)),
                                        std::memory_order_release);
            tail_active_[seg_id] = 1;
          }
          else if (drift_reset_mode_ == 0)
          {
            seg_extra_ns_[seg_id].store(0, std::memory_order_release);
            tail_active_[seg_id] = 0;
          }
          // Real retraining is synchronous here, so prefer the latest wall
          // clock observation.  A 0.8 old-value weight left estimates near
          // their synthetic size prior for most of a short online run.
          est_cost_ms_[seg_id] = 0.30 * est_cost_ms_[seg_id] +
                                 0.70 * std::max(0.001, cost_ms_measured);
        }
    }
    else
    {
      std::cerr << "[REAL_RETRAIN] segment " << seg_id << " contains no training keys\n";
      if (cb)
        cb(seg_id, 0.0, 0.0, 0.0);
      return;
    }
    if (!(g_flag_single_phase && Config.policy == "linucb" && g_in_linucb_midwindow))
      g_win.retrain_cnt++;
    g_win.retrain_cost_ms_sum += cost_ms_measured;
        g_win.retrain_cost_ms_samples.push_back(cost_ms_measured);
    if (cb)
      cb(seg_id, -1.5, -3.0, cost_ms_measured);
  }

public:
  void mst_build_if_needed() override {}
  void mst_update_by_key(uint64_t key, uint64_t value) override
  {
    std::lock_guard<std::mutex> lk(mu_);
    mst_.update_by_key(key, value);
  }
  RangeProof mst_range_proof(uint64_t l, uint64_t r) override
  {
    std::lock_guard<std::mutex> lk(mu_);
    return mst_.range_proof(l, r);
  }
  uint64_t mst_root_hash() const override
  {
    std::lock_guard<std::mutex> lk(mu_);
    return mst_.root_hash();
  }
  void note_operation(key_type k, double lat, bool is_write)
  {
    size_t seg = segment_of_key_(k);
    std::lock_guard<std::mutex> lk(mu_);
    qps_[seg] += 1.0;
    ema_p99_[seg] = 0.95 * ema_p99_[seg] + 0.05 * lat;
    if (is_write)
      write_ratio_[seg] = std::min(1.0, write_ratio_[seg] + 0.002);
    last_rt_sec_[seg] += 0.001;
  }
  
  // 修改注入漂移函数，使得每个segment的漂移不同
void inject_latency_drift(size_t K, uint32_t add_ns) {
    if (!segments_ || !K || !add_ns)
        return;

    const bool temporal = getenv("DRIFT_TEMPORAL_HETERO") &&
                          atoi(getenv("DRIFT_TEMPORAL_HETERO")) != 0;
    if (temporal) {
        if (temporal_ids_.empty()) {
            temporal_ids_.resize(segments_);
            for (size_t i = 0; i < segments_; ++i) temporal_ids_[i] = (int)i;
            std::mt19937_64 cohort_rng{
                static_cast<uint64_t>(Config.seed) ^ 0x74656d706f72616cULL};
            std::shuffle(temporal_ids_.begin(), temporal_ids_.end(), cohort_rng);
        }
        // A fixed seed-derived cohort contains rising, steady, decaying,
        // bursty, and low-background segments. Drift persists until an actual
        // repair resets it, so cross-window prediction can matter.
        const size_t active = std::min(segments_, std::max<size_t>(K, 2 * K));
        const size_t phase = temporal_tick_ % 6;
        const uint64_t cap_ns = getenv("DRIFT_CAP_NS")
            ? std::max<uint64_t>(add_ns,
                strtoull(getenv("DRIFT_CAP_NS"), nullptr, 10))
            : 2000000ULL;
        std::lock_guard<std::mutex> lk(mu_);
        for (size_t i = 0; i < active; ++i) {
            double scale = 0.25;
            if (i < 2) scale = 0.45 + 0.18 * phase;
            else if (i < 4) scale = 1.00;
            else if (i < 6) scale = 1.35 - 0.18 * phase;
            else if (i < 8) scale = (temporal_tick_ % 4 == 0) ? 2.00 : 0.10;
            const uint64_t inc = static_cast<uint64_t>(
                add_ns * std::max(0.10, scale));
            const int id = temporal_ids_[i];
            const uint64_t oldv =
                seg_extra_ns_[id].load(std::memory_order_relaxed);
            seg_extra_ns_[id].store(
                static_cast<uint32_t>(std::min(cap_ns, oldv + inc)),
                std::memory_order_relaxed);
        }
        ++temporal_tick_;
        return;
    }

    std::vector<int> ids(segments_);
    for (size_t i = 0; i < segments_; ++i)
        ids[i] = (int)i;

    thread_local std::mt19937_64 rng{static_cast<uint64_t>(Config.seed) ^ 0x876543210ULL};
    std::shuffle(ids.begin(), ids.end(), rng);

    size_t use = std::min(K, (size_t)segments_);
    std::lock_guard<std::mutex> lk(mu_);

    // Controlled-window mode: each window is a fresh shock instead of adding
    // synthetic delay forever until every segment reaches the 500 us cap.
    const bool no_accum = getenv("DRIFT_NO_ACCUM") && atoi(getenv("DRIFT_NO_ACCUM")) != 0;
    const bool heterogeneous = getenv("DRIFT_HETERO") && atoi(getenv("DRIFT_HETERO")) != 0;
    if (no_accum) {
        for (size_t s = 0; s < segments_; ++s) {
            seg_extra_ns_[s].store(0, std::memory_order_relaxed);
            tail_active_[s] = 0;
        }
    }
    
    // 随机为每个segment注入不同幅度的漂移
    for (size_t i = 0; i < use; ++i) {
        int id = ids[i];
        
        // A deterministic amplitude ladder preserves real heterogeneity across
        // windows and seeds without converging all arms to the same cap.
        static const double scale[] = {2.00, 1.75, 1.50, 1.25, 1.00, 0.80, 0.65, 0.50};
        uint32_t random_drift = heterogeneous
            ? static_cast<uint32_t>(add_ns * scale[i % (sizeof(scale) / sizeof(scale[0]))])
            : add_ns;
        uint32_t oldv = seg_extra_ns_[id].load(std::memory_order_relaxed);
        uint64_t merged = (uint64_t)oldv + random_drift;

        const uint64_t cap_ns = getenv("DRIFT_CAP_NS")
            ? std::max<uint64_t>(add_ns,
                strtoull(getenv("DRIFT_CAP_NS"), nullptr, 10))
            : 500000ULL;
        if (merged > cap_ns)
            merged = cap_ns;
        seg_extra_ns_[id].store((uint32_t)merged, std::memory_order_relaxed);
    }
}

  std::vector<int> inject_latency_drift_return_ids(size_t K, uint32_t add_ns)
  {
    std::vector<int> chosen;
    if (!segments_ || !K || !add_ns)
      return chosen;
    std::vector<int> ids(segments_);
    for (size_t i = 0; i < segments_; ++i)
      ids[i] = (int)i;
    thread_local std::mt19937_64 rng{static_cast<uint64_t>(Config.seed) ^ 0xABCDEF555ULL};
    std::shuffle(ids.begin(), ids.end(), rng);
    size_t use = std::min(K, (size_t)segments_);
    chosen.assign(ids.begin(), ids.begin() + use);
    {
      std::lock_guard<std::mutex> lk(mu_);
      for (int id : chosen)
      {
        uint32_t oldv = seg_extra_ns_[id].load(std::memory_order_relaxed);
        uint64_t merged = (uint64_t)oldv + add_ns;
        if (merged > 500000)
          merged = 500000;
        seg_extra_ns_[id].store((uint32_t)merged, std::memory_order_relaxed);
        if (!gScenario.tail_enable)
          tail_active_[id] = 0;
      }
    }
    return chosen;
  }
  void inject_longtail_pattern(const std::vector<ClaimsScenario::Bucket> &bs)
  {
    if (bs.empty())
      return;
    std::vector<int> pool(segments_);
    for (size_t i = 0; i < segments_; ++i)
      pool[i] = (int)i;
    static thread_local std::mt19937_64 rng{0x13579BDF1234ULL};
    std::shuffle(pool.begin(), pool.end(), rng);
    size_t off = 0;
    std::lock_guard<std::mutex> lk(mu_);
    for (auto &b : bs)
    {
      for (int j = 0; j < b.count && off < pool.size(); ++j, ++off)
      {
        int id = pool[off];
        uint32_t oldv = seg_extra_ns_[id].load(std::memory_order_relaxed);
        uint64_t merged = (uint64_t)oldv + b.extra_ns;
        if (merged > 500000)
          merged = 500000;
        seg_extra_ns_[id].store((uint32_t)merged, std::memory_order_relaxed);
        tail_active_[id] = 0;
      }
    }
  }
  uint32_t extra_latency_of_key(key_type k) const
  {
    if (!segments_)
      return 0;
    size_t seg = segment_of_key_(k);
    return seg_extra_ns_[seg].load(std::memory_order_relaxed);
  }
  size_t tail_active_count() const
  {
    size_t c = 0;
    for (auto f : tail_active_)
      if (f)
        ++c;
    return c;
  }

private:
  static inline uint64_t splitmix64(uint64_t x)
  {
    x += 0x9e3779b97f4a7c15ull;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ull;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebull;
    return x ^ (x >> 31);
  }
  size_t segment_of_key_(key_type k) const
  {
    return (size_t)(splitmix64((uint64_t)k) % segments_);
  }
  void decay_qps_locked()
  {
    auto now = std::chrono::steady_clock::now();
    double sec = std::chrono::duration<double>(now - last_snapshot_).count();
    last_snapshot_ = now;
    double d = std::exp(-sec / 1.0);
    for (auto &v : qps_)
      v *= d;
    for (auto &t : last_rt_sec_)
      t += sec;
  }
  aidel_type *ai_;
  size_t segments_;

    // Snapshot of real keys for actual segment retraining
  std::vector<key_type> keys_snapshot_;
  std::vector<std::vector<key_type>> segment_keys_;
  std::vector<std::vector<val_type>> segment_vals_;
  std::vector<std::unique_ptr<aidel_type>> installed_segment_models_;
  std::vector<SegmentStats> stats_;
  std::vector<double> ema_p99_, max_err_, qps_, write_ratio_, size_mb_,
      last_rt_sec_, est_cost_ms_, drift_;
  std::vector<double> last_drift_observed_, drift_slope_ema_;
  std::unique_ptr<std::atomic<uint32_t>[]> seg_extra_ns_;
  std::vector<uint8_t> tail_active_;
  std::vector<int> temporal_ids_;
  size_t temporal_tick_ = 0;
  int drift_reset_mode_ = 0;
  std::chrono::steady_clock::time_point last_snapshot_;
  mutable std::mutex mu_;
  mks::MerkleSum mst_;
};

template <typename T>
static double percentile(std::vector<T> &v, double q)
{
  if (v.empty())
    return 0;
  if (q < 0)
    q = 0;
  if (q > 1)
    q = 1;
  size_t k = (size_t)std::floor(q * (v.size() - 1));
  std::nth_element(v.begin(), v.begin() + k, v.end());
  return (double)v[k];
}
static double compute_topk_sum(AidelAdapter *adp, size_t K)
{
  auto st = adp->collect_all_stats();
  if (st.empty())
    return 0;
  if (g_flag_use_max_only)
  {
    double mx = 0;
    for (auto &s : st)
      mx = std::max(mx, s.drift);
    return mx;
  }
  if (K == 0)
    K = 1;
  std::vector<double> vals;
  vals.reserve(st.size());
  for (auto &s : st)
    vals.push_back(s.drift);
  std::sort(vals.begin(), vals.end(), std::greater<>());
  size_t use = std::min(vals.size(), (size_t)K);
  double sum = 0;
  for (size_t i = 0; i < use; ++i)
    sum += vals[i];
  return sum;
}

static double compute_budget_oracle_topk_remainder(AidelAdapter *adp, size_t K,
                                                    size_t budget)
{
  auto st = adp->collect_all_stats();
  std::vector<double> vals;
  vals.reserve(st.size());
  for (const auto &s : st)
    vals.push_back(std::max(0.0, s.drift));
  std::sort(vals.begin(), vals.end(), std::greater<>());
  const size_t top = std::min(vals.size(), std::max<size_t>(1, K));
  const size_t repaired = std::min(top, budget);
  double remainder = 0.0;
  for (size_t i = repaired; i < top; ++i)
    remainder += vals[i];
  return remainder;
}

static ArmContext make_scheduler_arm(const SegmentStats &s)
{
  ArmContext a;
  a.arm_id = static_cast<uint32_t>(s.seg_id);
  a.x = {
      std::tanh(std::max(0.0, s.max_err) / 50.0),
      std::tanh(std::max(0.0, s.qps) / 1000.0),
      std::tanh(std::max(0.0, s.p99_read_ms) / 50.0),
      std::clamp(s.write_ratio, 0.0, 1.0),
      std::tanh(std::max(0.0, s.size_mb) / 32.0),
      std::tanh(std::max(0.0, s.last_retrain_sec) / 60.0),
      std::tanh(std::max(0.0, s.est_cost_ms) / 100.0),
      std::tanh(std::max(0.0, s.drift +
          0.75 * std::max(0.0, s.err_slope)) / 2000.0)};
  a.est_cost = std::max(1e-6, s.est_cost_ms);
  return a;
}

static void run_verification(aidel_type *ai)
{
  if (!ai)
    return;
  if (Config.proof_rate <= 0.0 || Config.verify_layer != "merklesum")
    return;
  if (exist_keys.empty())
    return;
  size_t checks = 0, fails = 0;
  const size_t cap = 100000;
  size_t step = 1;
  if (exist_keys.size() > cap)
    step = (exist_keys.size() + cap - 1) / cap;
  for (size_t i = 0; i < exist_keys.size(); i += step)
  {
    key_type k = exist_keys[i];
    val_type v;
    bool ok = (ai->find(k, v) == Result::ok);
    checks++;
    if (!ok)
      fails++;
  }
  std::cerr << "[verify] checks=" << checks << " fails=" << fails << "\n";
}

struct alignas(CACHELINE_SIZE) ThreadParam
{
  aidel_type *ai = nullptr;
  AidelAdapter *adapter = nullptr;
  VerifyService *verifier = nullptr;
  std::atomic<uint64_t> throughput{0};
  uint32_t thread_id = 0;
  std::vector<uint32_t> lat_samples_ns;
  std::mutex lat_mu;
  uint32_t sample_tick = 0;
};
static volatile bool running = false;
static std::atomic<size_t> ready_threads{0};
static std::atomic<size_t> g_ycsb_cursor{0};
// AIDEL mutations are not internally synchronized.  Keep concurrent reads,
// but serialize CRUD writes so YCSB-D cannot corrupt the foreground index.
static std::shared_mutex g_aidel_crud_mu;

static void *run_fg(void *p)
{
  ThreadParam &tp = *(ThreadParam *)p;
  aidel_type *ai = tp.ai;
  AidelAdapter *adapter = tp.adapter;
  bool use_ycsb = (Config.benchmark >= 6 && Config.benchmark <= 11 &&
                   YCSBconfig.operate_queue != nullptr);
  std::mt19937 gen((uint32_t)(Config.seed + tp.thread_id * 1013904223u));
  std::uniform_real_distribution<> ur(0, 1);
  size_t non_exist_per = non_exist_keys.empty() ? 0 : non_exist_keys.size() / std::max<size_t>(1, Config.thread_num);
  size_t start = non_exist_keys.empty() ? 0 : tp.thread_id * non_exist_per;
  size_t stop = non_exist_keys.empty() ? 0 : (tp.thread_id + 1) * non_exist_per;
  std::vector<key_type> op_keys;
  if (!non_exist_keys.empty() && start <= stop && stop <= non_exist_keys.size())
    op_keys.assign(non_exist_keys.begin() + start, non_exist_keys.begin() + stop);
  ready_threads++;
  while (!running)
  {
  }
  val_type dummy = 0;
  size_t qi = 0, ni = 0, ii = 0, ui = 0, di = 0;
  while (running)
  {
    const auto op_begin = std::chrono::steady_clock::now();
    double d = ur(gen);
    bool is_write = false;
    key_type used_key = 0;
    if (use_ycsb)
    {
      const size_t ticket = g_ycsb_cursor.fetch_add(1, std::memory_order_relaxed);
      const auto &op = YCSBconfig.operate_queue[ticket % YCSBconfig.operate_num];
      key_type k = op.key;
      switch (op.op)
      {
      case 0:
        { std::shared_lock<std::shared_mutex> lk(g_aidel_crud_mu); ai->find(k, dummy); }
        break;
      case 1:
        { std::unique_lock<std::shared_mutex> lk(g_aidel_crud_mu);
          if (ticket < YCSBconfig.operate_num) ai->insert(k, k);
          else ai->update(k, k); }
        is_write = true;
        break;
      case 2:
        { std::unique_lock<std::shared_mutex> lk(g_aidel_crud_mu); ai->update(k, k); }
        is_write = true;
        break;
      case 3:
        { std::unique_lock<std::shared_mutex> lk(g_aidel_crud_mu); ai->remove(k); }
        is_write = true;
        break;
      case 4:
        { std::shared_lock<std::shared_mutex> lk(g_aidel_crud_mu);
          for (int i = 0; i < op.range; i++) ai->find(k + i, dummy); }
        break;
      default:
        { std::shared_lock<std::shared_mutex> lk(g_aidel_crud_mu); ai->find(k, dummy); }
        break;
      }
      used_key = k;
    }
    else
    {
      double rlim = Config.read_ratio;
      double ilim = rlim + Config.insert_ratio;
      double ulim = ilim + Config.update_ratio;
      double dlim = ulim + Config.delete_ratio;
      bool do_neg = (Config.neg_read_ratio > 0.0) && !non_exist_keys.empty() && (ur(gen) < Config.neg_read_ratio);
      if (d <= rlim)
      {
        if (do_neg)
        {
          key_type k = non_exist_keys[ni % non_exist_keys.size()];
          ai->find(k, dummy);
          used_key = k;
          ni++;
        }
        else
        {
          key_type k = exist_keys[qi % exist_keys.size()];
          ai->find(k, dummy);
          used_key = k;
          qi = (qi + 1) % exist_keys.size();
        }
      }
      else if (d <= ilim)
      {
        key_type k = op_keys.empty() ? (key_type)gen() : op_keys[ii % op_keys.size()];
        ai->insert(k, k);
        used_key = k;
        is_write = true;
        ii++;
      }
      else if (d <= ulim)
      {
        key_type k = op_keys.empty() ? exist_keys[ui % exist_keys.size()] : op_keys[ui % op_keys.size()];
        ai->update(k, k);
        used_key = k;
        is_write = true;
        ui++;
      }
      else if (d <= dlim)
      {
        if (!exist_keys.empty())
        {
          key_type k = exist_keys[di % exist_keys.size()];
          ai->remove(k);
          used_key = k;
          is_write = true;
          di++;
        }
      }
      else
      {
        key_type k = exist_keys[qi % exist_keys.size()];
        ai->find(k, dummy);
        used_key = k;
        qi = (qi + 1) % exist_keys.size();
      }
    }
    // Apply per-segment drift to the actual request path. Previously drift
    // changed only residual counters, leaving throughput and p99 unaffected.
    busy_wait_ns(adapter->extra_latency_of_key(used_key));
    const auto op_end = std::chrono::steady_clock::now();
    const auto latency_ns_i64 =
        std::chrono::duration_cast<std::chrono::nanoseconds>(op_end - op_begin).count();
    const uint32_t latency_ns = static_cast<uint32_t>(
        std::min<int64_t>(latency_ns_i64, std::numeric_limits<uint32_t>::max()));
    adapter->note_operation(used_key, static_cast<double>(latency_ns) / 1.0e6, is_write);
    if (is_write && tp.verifier)
      tp.verifier->enqueue_write(static_cast<int>(tp.thread_id), used_key, used_key);
    tp.sample_tick++;
    if ((tp.sample_tick & 0xFFu) == 0)
    {
      std::lock_guard<std::mutex> lk(tp.lat_mu);
      if (tp.lat_samples_ns.size() < 200000)
        tp.lat_samples_ns.push_back(latency_ns);
    }
    tp.throughput.fetch_add(1, std::memory_order_relaxed);
  }
  pthread_exit(nullptr);
}

static void preprocess_claims_args(int &argc, char **&argv)
{
  static bool done = false;
  if (done)
    return;
  done = true;
  static std::vector<char *> storage;
  storage.push_back(argv[0]);
  auto need = [&](int i, const char *f)
  { if(i+1>=argc){fprintf(stderr,"%s need val\n",f); exit(2);} return argv[i+1]; };
  for (int i = 1; i < argc; ++i)
  {
    std::string a = argv[i];
    if (a == "--longtail")
    {
      const char *v = need(i, "--longtail");
      ++i;
      std::stringstream ss(v);
      std::string tok;
      while (std::getline(ss, tok, ','))
      {
        auto pos = tok.find(':');
        if (pos == std::string::npos)
          continue;
        int cnt = 0;
        double us = 0;
        try
        {
          cnt = std::stoi(tok.substr(0, pos));
          us = std::stod(tok.substr(pos + 1));
        }
        catch (...)
        {
          continue;
        }
        if (cnt > 0 && us > 0)
          gScenario.longtail.push_back({cnt, (uint32_t)(us * 1000.0)});
      }
      continue;
    }
    else if (a == "--scenario")
    {
      const char *v = need(i, "--scenario");
      ++i;
      std::string sc = v;
      if (sc == "midlate")
        gScenario.enable_midlate = true;
      else if (sc == "tail")
        gScenario.tail_enable = true;
      continue;
    }
    else if (a == "--K-start")
    {
      gScenario.K_start = std::stoi(need(i, "--K-start"));
      ++i;
      continue;
    }
    else if (a == "--K-mid")
    {
      gScenario.K_mid = std::stoi(need(i, "--K-mid"));
      gScenario.enable_midlate = true;
      ++i;
      continue;
    }
    else if (a == "--K-late")
    {
      gScenario.K_late = std::stoi(need(i, "--K-late"));
      gScenario.enable_midlate = true;
      ++i;
      continue;
    }
    else if (a == "--mid-time")
    {
      gScenario.mid_time_s = std::stod(need(i, "--mid-time"));
      ++i;
      continue;
    }
    else if (a == "--late-time")
    {
      gScenario.late_time_s = std::stod(need(i, "--late-time"));
      ++i;
      continue;
    }
    else if (a == "--no-topk")
    {
      gScenario.disable_topk = true;
      continue;
    }
    else if (a == "--no-avoid")
    {
      gScenario.disable_avoid = true;
      continue;
    }
    else if (a == "--static-fair")
    {
      gScenario.fair_static = true;
      continue;
    }
    else if (a == "--greedy")
    {
      // Cost-aware myopic Greedy baseline: rank each segment by its current
      // residual reduction per estimated millisecond of real retraining.
      // It has no cross-window learning, exploration, or future information.
      gScenario.greedy_static = true;
      continue;
    }
    else if (a == "--static-dp" || a == "--static-dp-limited")
    {
      gScenario.static_dp = true;
      gScenario.static_dp_limited = (a == "--static-dp-limited");
      continue;
    }
    else if (a == "--periodic")
        {
            gScenario.periodic_static = true;
            continue;
        }
        else if (a == "--threshold")
        {
            gScenario.threshold_static = true;
            continue;
        }
        else if (a == "--tail-retention")
    {
      gScenario.tail_enable = true;
      gScenario.tail_retention_factor = std::stod(need(i, "--tail-retention"));
      ++i;
      continue;
    }
    else if (a == "--tail-decay")
    {
      gScenario.tail_enable = true;
      gScenario.tail_decay_us = std::stod(need(i, "--tail-decay"));
      ++i;
      continue;
    }
    else if (a == "--proof-rate")
    {
      gScenario.proof_rate_override = std::stod(need(i, "--proof-rate"));
      ++i;
      continue;
    }
    else if (a == "--proof-batch")
    {
      gScenario.proof_batch_override = std::stoi(need(i, "--proof-batch"));
      ++i;
      continue;
    }
    storage.push_back(argv[i]);
  }
  storage.push_back(nullptr);
  argc = (int)storage.size() - 1;
  argv = storage.data();
  optind = 1;
}

static void run_benchmark(aidel_type *ai,
                          AidelAdapter *adapter,
                          VerifyService *verifier,
                          size_t sec,
                          const PredictionErrorStats<aidel_type, key_type> &,
                          CsvLogger *csv_logger,
                          size_t /*unused*/)
{
  const size_t N = std::max<size_t>(1, Config.thread_num);
  std::vector<pthread_t> threads(N);
  std::vector<ThreadParam *> params(N);
  for (size_t i = 0; i < N; ++i)
  {
    params[i] = new ThreadParam();
    params[i]->ai = ai;
    params[i]->adapter = adapter;
    params[i]->verifier = verifier;
    params[i]->thread_id = static_cast<uint32_t>(i);
  }
  running = false;
  ready_threads = 0;
  for (size_t i = 0; i < N; ++i)
    if (pthread_create(&threads[i], nullptr, run_fg, (void *)params[i]) != 0)
    {
      std::cerr << "pthread_create fail\n";
      abort();
    }
  while (ready_threads < N)
    usleep(1000);
  running = true;

  // 添加 rng_local
  std::mt19937_64 rng_local(static_cast<uint64_t>(Config.seed) ^ 0x9e3779b97f4a7c15ULL);

  size_t current_sec = 0;
  const int WIN = std::max(1, Config.win_sec);
  LinUCBController::Param phase1_param;
  phase1_param.d = 8;
  // Strong regularization prevents the enormous cold-start confidence term
  // (lambda=1e-3) from overwhelming the observable residual signal.
  phase1_param.alpha = std::min(0.20, std::max(0.0, Config.alpha));
  phase1_param.lambda = std::max(1.0, Config.lambda);
  phase1_param.budget_B = 1;
  // NoAdapt is a calibrated-then-frozen learned scheduler.  It must not keep
  // the hand-written residual/slope shortcut after online updates are
  // disabled; otherwise it remains a near-current-window oracle despite the
  // ablation. This branch is inactive for every normal LinVeriX run.
  phase1_param.use_residual_prior = !g_flag_disable_adapt;
  LinUCBController phase1_controller(phase1_param);
  if (gScenario.enable_midlate && current_sec == 0)
  {
    gScenario.mid_global_sec = (int)std::floor(gScenario.mid_time_s);
    gScenario.late_global_sec = (int)std::ceil(gScenario.late_time_s - 1e-9);
  }
  double raw_baseline_topk_sum_us = 0.0;
  bool raw_baseline_recorded = false;
  double topk_sum_post_injection_us = 0.0;
  double topk_sum_post_phase2_us = 0.0;
  double peak_topk_sum_us = 0.0;
  double budget_oracle_topk_target_us = 0.0;
  double triplet_post_ratio = 0.0;
  size_t usedB_phase1 = 0, usedB_phase2 = 0, phase2_used = 0;
  double phase1_cost_ms_sum = 0.0, phase2_cost_ms_sum = 0.0;
  double tau_us = 0.0, phi_us = 0.0, margin_pct = 0.10;
  double fixed_tau_us = 0.0, fixed_phi_us = 0.0;
  size_t p1_starvation_windows = 0, p2_starvation_windows = 0;
  double phase1_budget_credit = 0.0;
  bool baseline_finalized = false;
  bool executed_static_batch = false;
  bool executed_phase2_this_window = false;
  bool mid_inject_flag = false, late_inject_flag = false;
  bool injected_this_window = false;
  int late_segments_repaired = 0;
  std::vector<size_t> tput_hist(N, 0);
  std::vector<uint64_t> sec_tput;
  sec_tput.reserve(WIN + 4);
  // Periodic baseline uses maintenance age, independent of residual rank.
  // -1 means the segment has not yet been maintained in this run.
  std::vector<int> last_maintenance_window(
      adapter->collect_all_stats().size(), -1);
  // Both phases schedule from one immutable window observation.  This matches
  // a dual-phase controller whose decisions can overlap in time and makes the
  // reservation/avoidance mechanism testable without changing drift values.
  std::vector<SegmentStats> window_decision_snapshot;
  // Static Threshold is a one-window-lag reactive policy.  It may only act on
  // the last completed observation, never on a shock injected at the current
  // boundary.  Keep the current raw snapshot separately and publish it only
  // after this window's threshold decision has been finalized.
  std::vector<SegmentStats> threshold_prev_stats;
  std::vector<SegmentStats> threshold_current_stats;

  auto gi = [](const char *k, int d) -> int
  { const char* v=getenv(k); if(!v) return d; try{return std::stoi(v);}catch(...){return d;} };
  auto gu = [](const char *k, uint32_t d) -> uint32_t
  { const char* v=getenv(k); if(!v) return d; try{return (uint32_t)std::stoul(v);}catch(...){return d;} };
  int DRIFT_INTERVAL = gi("DRIFT_INTERVAL_SEC", 0);
  int DRIFT_K = gi("DRIFT_K", 4);
  uint32_t DRIFT_LAT_NS_PER_SEG = gu("DRIFT_LAT_NS_PER_SEG", 20000);
  int DRIFT_WARMUP_SEC = gi("DRIFT_WARMUP_SEC", 0);
  const int warmup_windows = DRIFT_WARMUP_SEC / std::max(1, WIN);

  while (current_sec < sec)
  {
    std::this_thread::sleep_for(std::chrono::seconds(1));
    bool window_start = ((current_sec % WIN) == 0);
    bool end_of_window = (((current_sec + 1) % WIN) == 0);
    int sec_in_window = (int)(current_sec % WIN);
    int current_window = (int)(current_sec / WIN);

    if (window_start)
    {
      if (current_window > warmup_windows)
      {
        p1_starvation_windows = usedB_phase1 == 0 ? p1_starvation_windows + 1 : 0;
        p2_starvation_windows = usedB_phase2 == 0 ? p2_starvation_windows + 1 : 0;
      }
      else
      {
        p1_starvation_windows = p2_starvation_windows = 0;
      }
      usedB_phase1 = usedB_phase2 = phase2_used = 0;
      phase1_cost_ms_sum = phase2_cost_ms_sum = 0;
      tau_us = phi_us = 0;
      executed_phase2_this_window = false;
      executed_static_batch = false;
      mid_inject_flag = late_inject_flag = false;
      injected_this_window = false;
      late_segments_repaired = 0;
      g_phase2_total_repairs = g_phase2_redundant_repairs = 0;
      g_retrained_segments_this_window.clear();
      g_start_injected_segments.clear();
      g_mid_injected_segments.clear();
      g_late_injected_segments.clear();
      baseline_finalized = false;
      window_decision_snapshot.clear();
      raw_baseline_recorded = false;
      raw_baseline_topk_sum_us = 0.0;

      if (current_window > 0)
      {
        raw_baseline_topk_sum_us = topk_sum_post_phase2_us;
        raw_baseline_recorded = true;
        topk_sum_post_injection_us = raw_baseline_topk_sum_us;
        peak_topk_sum_us = raw_baseline_topk_sum_us;
        topk_sum_post_phase2_us = raw_baseline_topk_sum_us;
        baseline_finalized = true;
        triplet_post_ratio = 1.0;
      }
      else
      {
        topk_sum_post_injection_us = 0;
        topk_sum_post_phase2_us = 0;
        peak_topk_sum_us = 0;
        triplet_post_ratio = 0;
      }
    }

    bool linucb_phase_enabled = g_drift_enabled &&
                                (Config.policy == "linucb") &&
                                !g_flag_single_phase &&
                                !gScenario.greedy_static &&
                                !gScenario.static_dp;
    bool adapt_enabled = linucb_phase_enabled && !g_flag_disable_runtime;
    size_t effB = (size_t)Config.budget_B;

    if (current_window == 0 || gScenario.K_mid > 0 || gScenario.K_late > 0)
    {
      if (window_start)
      {
        if (current_window == 0 && !gScenario.longtail.empty())
        {
          adapter->inject_longtail_pattern(gScenario.longtail);
          injected_this_window = true;
        }
        if (current_window == 0 && gScenario.K_start > 0)
        {
          g_start_injected_segments =
              adapter->inject_latency_drift_return_ids((size_t)gScenario.K_start,
                                                       DRIFT_LAT_NS_PER_SEG ? DRIFT_LAT_NS_PER_SEG : 250000);
          injected_this_window = true;
        }
      }
      if (gScenario.K_mid > 0 && !gScenario.mid_injected && current_sec == gScenario.mid_global_sec)
      {
        g_mid_injected_segments =
            adapter->inject_latency_drift_return_ids((size_t)gScenario.K_mid,
                                                     DRIFT_LAT_NS_PER_SEG ? DRIFT_LAT_NS_PER_SEG : 250000);
        gScenario.mid_injected = true;
        mid_inject_flag = true;
        injected_this_window = true;
        peak_topk_sum_us = std::max(peak_topk_sum_us,
                                    compute_topk_sum(adapter, (size_t)DRIFT_K));
        budget_oracle_topk_target_us = compute_budget_oracle_topk_remainder(
            adapter, (size_t)DRIFT_K, (size_t)Config.budget_B);
      }
      if (gScenario.K_late > 0 && !gScenario.late_injected &&
          current_sec == gScenario.late_global_sec)
      {
        g_late_injected_segments =
            adapter->inject_latency_drift_return_ids((size_t)gScenario.K_late,
                                                     DRIFT_LAT_NS_PER_SEG ? DRIFT_LAT_NS_PER_SEG : 250000);
        gScenario.late_injected = true;
        late_inject_flag = true;
        injected_this_window = true;
      }
      bool staging_done = false;
      if (gScenario.K_late > 0)
        staging_done = gScenario.late_injected;
      else if (gScenario.K_mid > 0)
        staging_done = gScenario.mid_injected;
      else
        staging_done = window_start;
      if (staging_done && !baseline_finalized)
      {
        double base = compute_topk_sum(adapter, (size_t)DRIFT_K);
        raw_baseline_topk_sum_us = base;
        raw_baseline_recorded = true;
        topk_sum_post_injection_us = base;
        peak_topk_sum_us = std::max(peak_topk_sum_us, base);
        baseline_finalized = true;
        triplet_post_ratio = 1.0;
      }
    }
    if (window_start && DRIFT_INTERVAL > 0) {

      // 让 DRIFT_INTERVAL 表示"每隔多少个 window 注入一次"
      int win_id = current_window; // 从 1 开始算 periodic
      bool do_inject = (win_id >= DRIFT_WARMUP_SEC / WIN) &&
                      ((win_id - (DRIFT_WARMUP_SEC / WIN)) % (DRIFT_INTERVAL / WIN == 0 ? 1 : (DRIFT_INTERVAL / WIN)) == 0);

      // 每个 window 注入
      if (do_inject) {
        adapter->inject_latency_drift((size_t)DRIFT_K, DRIFT_LAT_NS_PER_SEG);
        injected_this_window = true;
        double base = compute_topk_sum(adapter, (size_t)DRIFT_K);
        raw_baseline_topk_sum_us = base;
        raw_baseline_recorded = true;
        topk_sum_post_injection_us = base;
        peak_topk_sum_us = base;
        budget_oracle_topk_target_us = compute_budget_oracle_topk_remainder(
            adapter, (size_t)DRIFT_K, (size_t)Config.budget_B);
        baseline_finalized = true;
        triplet_post_ratio = 1.0;
      }
    }


    bool static_policy_due = gScenario.fair_static || gScenario.greedy_static ||
                             gScenario.static_dp;
    if (gScenario.periodic_static)
    {
      const int every = std::max(1, gi("PERIODIC_EVERY_WINDOWS", 5));
      static_policy_due = (current_window % every) == 0;
    }
    if (gScenario.threshold_static && baseline_finalized && !executed_static_batch)
    {
      const double threshold_us = Config.tau > 0.0
                                      ? Config.tau
                                      : static_cast<double>(gi("THRESHOLD_DRIFT_US", 250));
      threshold_current_stats = adapter->collect_all_stats();
      double max_drift = 0.0;
      for (const auto &s : threshold_prev_stats)
        max_drift = std::max(max_drift, s.drift);
      static_policy_due = !threshold_prev_stats.empty() && max_drift >= threshold_us;
      std::cout << "[THRESHOLD_DECISION] decision_window=" << current_window
                << " observed_window=" << (current_window - 1)
                << " theta_us=" << threshold_us
                << " max_prev_drift_us=" << max_drift
                << " due=" << (static_policy_due ? 1 : 0)
                << std::endl;
    }
    if ((gScenario.fair_static || gScenario.greedy_static || gScenario.static_dp || gScenario.periodic_static || gScenario.threshold_static) &&
        baseline_finalized && !executed_static_batch && static_policy_due)
    {
      auto st_final = gScenario.threshold_static
                          ? threshold_prev_stats
                          : adapter->collect_all_stats();
      struct StaticCandidate { int id; double drift; double cost_ms; };
      std::vector<StaticCandidate> arr;
      const double threshold_us = Config.tau > 0.0
                                      ? Config.tau
                                      : static_cast<double>(gi("THRESHOLD_DRIFT_US", 250));
      for (auto &s : st_final)
        if (s.drift > 0 && (!gScenario.threshold_static || s.drift >= threshold_us))
          arr.push_back({s.seg_id, s.drift, std::max(0.001, s.est_cost_ms)});
      std::sort(arr.begin(), arr.end(), [](auto &a, auto &b)
                { return a.drift > b.drift; });
      if (gScenario.greedy_static)
      {
        std::stable_sort(arr.begin(), arr.end(), [](const auto &a, const auto &b)
        {
          const double da = a.drift / std::max(0.001, a.cost_ms);
          const double db = b.drift / std::max(0.001, b.cost_ms);
          if (da != db) return da > db;
          return a.drift > b.drift;
        });
      }
      else if (gScenario.periodic_static)
      {
        std::stable_sort(arr.begin(), arr.end(),
                         [&last_maintenance_window](const auto &a, const auto &b)
        {
          const int age_a = a.id >= 0 && static_cast<size_t>(a.id) < last_maintenance_window.size()
                                ? last_maintenance_window[static_cast<size_t>(a.id)] : -1;
          const int age_b = b.id >= 0 && static_cast<size_t>(b.id) < last_maintenance_window.size()
                                ? last_maintenance_window[static_cast<size_t>(b.id)] : -1;
          if (age_a != age_b) return age_a < age_b; // oldest maintenance first
          return a.id < b.id;
        });
      }
      std::vector<int> chosen;
      size_t repair_cap = gScenario.static_dp_limited ? std::min<size_t>(1, effB) : effB;
      if (gScenario.static_dp && repair_cap > 0 && !arr.empty())
      {
        // StaticDP: exact 0/1 knapsack over the current residual snapshot.
        // It maximizes predicted residual reduction subject to both the repair
        // count B and a fixed per-window retraining-time allowance.  Unlike
        // LinVeriX, it has no online reward update or cross-window learning.
        double cost_budget_ms = 0.0;
        if (const char *v = getenv("STATICDP_COST_BUDGET_MS"))
          cost_budget_ms = std::max(0.001, atof(v));
        if (cost_budget_ms <= 0.0)
        {
          std::vector<double> costs;
          for (const auto &c : arr) costs.push_back(c.cost_ms);
          std::nth_element(costs.begin(), costs.begin() + costs.size() / 2, costs.end());
          cost_budget_ms = costs[costs.size() / 2] * repair_cap;
        }
        // Scale the DP quantum with the actual budget.  A fixed 0.001-ms
        // floor made tiny-data smoke tests spuriously reject candidates whose
        // cost was equal to the budget after upward rounding.
        const double quantum_ms = std::max(1e-9, cost_budget_ms / 2000.0);
        const int W = std::max(1, std::min(2000, (int)std::floor(cost_budget_ms / quantum_ms)));
        const auto weight_of = [quantum_ms](double cost_ms)
        {
          return std::max(1, (int)std::ceil(cost_ms / quantum_ms - 1e-12));
        };
        const size_t n = arr.size();
        const double neg = -1e300;
        std::vector<std::vector<std::vector<double>>> dp(
            n + 1, std::vector<std::vector<double>>(repair_cap + 1,
                                                    std::vector<double>(W + 1, neg)));
        std::vector<std::vector<std::vector<uint8_t>>> take(
            n + 1, std::vector<std::vector<uint8_t>>(repair_cap + 1,
                                                     std::vector<uint8_t>(W + 1, 0)));
        dp[0][0][0] = 0.0;
        for (size_t i = 1; i <= n; ++i)
        {
          const int wi = weight_of(arr[i - 1].cost_ms);
          for (size_t b = 0; b <= repair_cap; ++b)
            for (int w = 0; w <= W; ++w)
            {
              dp[i][b][w] = dp[i - 1][b][w];
              if (b > 0 && w >= wi && dp[i - 1][b - 1][w - wi] > neg / 2)
              {
                const double value = dp[i - 1][b - 1][w - wi] + arr[i - 1].drift;
                if (value > dp[i][b][w]) { dp[i][b][w] = value; take[i][b][w] = 1; }
              }
            }
        }
        size_t best_b = 0; int best_w = 0; double best = 0.0;
        for (size_t b = 0; b <= repair_cap; ++b)
          for (int w = 0; w <= W; ++w)
            if (dp[n][b][w] > best) { best = dp[n][b][w]; best_b = b; best_w = w; }
        for (size_t i = n, b = best_b; i > 0; --i)
        {
          if (take[i][b][best_w])
          {
            chosen.push_back(arr[i - 1].id);
            best_w -= weight_of(arr[i - 1].cost_ms);
            --b;
          }
        }
      }
      else
      {
        const size_t take_n = std::min(arr.size(), repair_cap);
        for (size_t i = 0; i < take_n; ++i) chosen.push_back(arr[i].id);
      }
      for (int chosen_id : chosen)
      {
        const double cost_before = g_win.retrain_cost_ms_sum;
        adapter->retrain_segment_async(chosen_id, nullptr);
        const double cost_delta = g_win.retrain_cost_ms_sum - cost_before;
        phase1_cost_ms_sum += cost_delta;
        // A stale candidate can become clean before execution. Only a
        // completed retrain consumes the budget ledger; a selected no-op
        // remains an attempted decision, not a maintenance action.
        if (cost_delta > 0.0)
        {
          usedB_phase1++;
          g_retrained_segments_this_window.insert(chosen_id);
        }
        if (cost_delta > 0.0 && gScenario.periodic_static && chosen_id >= 0 &&
            static_cast<size_t>(chosen_id) < last_maintenance_window.size())
          last_maintenance_window[static_cast<size_t>(chosen_id)] = current_window;
      }
      topk_sum_post_phase2_us = compute_topk_sum(adapter, (size_t)DRIFT_K);
      if (raw_baseline_topk_sum_us > 0)
        triplet_post_ratio = topk_sum_post_phase2_us / raw_baseline_topk_sum_us;
      executed_static_batch = true;
      executed_phase2_this_window = true;
      if (gScenario.threshold_static)
        threshold_prev_stats = threshold_current_stats;
    }
    else if ((gScenario.fair_static || gScenario.greedy_static || gScenario.static_dp ||
              gScenario.periodic_static || gScenario.threshold_static) &&
             baseline_finalized && !executed_static_batch && !static_policy_due)
    {
      topk_sum_post_phase2_us = compute_topk_sum(adapter, static_cast<size_t>(DRIFT_K));
      if (raw_baseline_topk_sum_us > 0)
        triplet_post_ratio = topk_sum_post_phase2_us / raw_baseline_topk_sum_us;
      if (gScenario.threshold_static)
      {
        threshold_prev_stats = threshold_current_stats;
        // A threshold policy makes at most one trigger decision per window,
        // including a no-op decision below theta.
        executed_static_batch = true;
      }
    }

    if (baseline_finalized && linucb_phase_enabled &&
        !gScenario.fair_static && !gScenario.greedy_static && !gScenario.static_dp)
    {
      g_in_linucb_midwindow = true;
      auto stats = adapter->collect_all_stats();
      if (!stats.empty())
      {
        std::vector<double> dr;
        dr.reserve(stats.size());
        for (auto &s : stats)
          dr.push_back(s.drift);
        if (adapt_enabled)
        {
          tau_us = percentile(dr, 0.80);
          phi_us = tau_us * (1.0 + margin_pct);
        }
        else
        {
          if (fixed_tau_us == 0.0)
          {
            fixed_tau_us = percentile(dr, 0.80);
            fixed_phi_us = fixed_tau_us * (1.0 + margin_pct);
          }
          tau_us = fixed_tau_us;
          phi_us = fixed_phi_us;
        }
      }
      auto st2 = adapter->collect_all_stats();
      if (window_decision_snapshot.empty())
        window_decision_snapshot = st2;
      std::vector<ArmContext> allocation_arms;
      allocation_arms.reserve(st2.size());
      std::vector<uint32_t> allocation_ids;
      for (const auto &s : st2)
      {
        if (s.drift <= 0)
          continue;
        allocation_arms.push_back(make_scheduler_arm(s));
        allocation_ids.push_back(static_cast<uint32_t>(s.seg_id));
      }
      double budget_uncertainty = 0.0;
      if (!allocation_arms.empty())
      {
        phase1_controller.ensure_arms_exist(allocation_ids);
        for (const auto &arm : allocation_arms)
        {
          const double u = phase1_controller.uncertainty(arm.x);
          budget_uncertainty += u / (1.0 + u);
        }
        budget_uncertainty /= allocation_arms.size();
      }
      const double current_topk_residual = compute_topk_sum(adapter, (size_t)DRIFT_K);
      const double budget_residual = current_topk_residual / (1.0 + current_topk_residual);
      double rho = std::clamp(0.40 + 0.20 * budget_uncertainty - 0.20 * budget_residual,
                              0.20, 0.60);
      double rho_scale = 0.25;
      if (const char *v = getenv("LINUCB_PHASE1_RHO_SCALE"))
      {
        char *end = nullptr;
        const double parsed = std::strtod(v, &end);
        if (end != v && *end == '\0' && std::isfinite(parsed))
          rho_scale = std::clamp(parsed, 0.0, 1.0);
      }
      rho *= rho_scale;
      const double phase1_credit_target = phase1_budget_credit + rho * static_cast<double>(effB);
      size_t phase1_cap = std::min(effB, static_cast<size_t>(std::max(0.0, std::floor(phase1_credit_target))));
      int phase1_starvation_limit = 8;
      if (const char *v = getenv("LINUCB_PHASE1_STARVATION_WINDOWS"))
      {
        const int parsed = atoi(v);
        if (parsed > 0)
          phase1_starvation_limit = parsed;
      }
      if (!g_flag_no_phase2 && current_topk_residual > 0.0 && effB >= 2 &&
          (p2_starvation_windows >= 2 || p1_starvation_windows >= static_cast<size_t>(phase1_starvation_limit)))
        phase1_cap = 1;
      if (const char *v = getenv("LINUCB_PHASE1_MAX_B"))
      {
        int lim = atoi(v);
        if (lim >= 0 && (size_t)lim < phase1_cap)
          phase1_cap = (size_t)lim;
      }
      // A Phase-2 ablation must spend the same per-window maintenance budget
      // as Full. Transfer the entire budget to Phase 1 instead of silently
      // comparing two repairs/window against one repair/window.
      if (g_flag_no_phase2)
      {
        phase1_cap = effB;
        phase1_budget_credit = 0.0;
      }
      else
      {
        phase1_budget_credit = phase1_credit_target - static_cast<double>(phase1_cap);
      }
      if (phase1_cap > 0)
      {
        std::vector<int> selected_ids;
        if (gScenario.disable_topk)
        {
          for (const auto &s : st2)
            if (s.drift > 0)
              selected_ids.push_back(s.seg_id);
          std::shuffle(selected_ids.begin(), selected_ids.end(),
                       std::mt19937{(uint32_t)(0xFA51A000 + current_sec)});
        }
        else if (g_flag_select_random)
        {
          for (const auto &s : st2)
            if (s.drift > 0)
              selected_ids.push_back(s.seg_id);
          std::shuffle(selected_ids.begin(), selected_ids.end(),
                       std::mt19937{static_cast<uint32_t>(Config.seed + current_sec)});
        }
        else
        {
          std::vector<ArmContext> arms;
          for (const auto &s : st2)
          {
            if (s.drift <= 0)
              continue;
            arms.push_back(make_scheduler_arm(s));
          }
          phase1_controller.set_budget_B(phase1_cap);
          const auto picked = phase1_controller.select(arms);
          selected_ids.assign(picked.begin(), picked.end());
        }
        size_t step = 0;
        for (int selected_id : selected_ids)
        {
          // The contextual phase can be revisited in the second half of a
          // window after Phase 2 has already consumed slots.  Enforce the
          // window-wide budget here as well as the Phase 1 allocation cap.
          if (usedB_phase1 >= phase1_cap || usedB_phase1 + usedB_phase2 >= effB)
            break;
          const auto stat_it = std::find_if(st2.begin(), st2.end(),
                                            [selected_id](const SegmentStats &s) { return s.seg_id == selected_id; });
          if (stat_it == st2.end())
            continue;
          const auto &c = *stat_it;
          bool already_phase1 = (g_retrained_segments_this_window.count(c.seg_id) > 0);
          if (!gScenario.disable_avoid && already_phase1)
          {
            dbg_p1("[P1] win=" + std::to_string(current_window) + " step=" + std::to_string(step) +
                   " seg=" + std::to_string(c.seg_id) + " drift=" + std::to_string((int)c.drift) +
                   " already=1 action=skip_dup avoid=1");
            step++;
            continue;
          }
          const double cost_before = g_win.retrain_cost_ms_sum;
          const double selected_drift = c.drift;
          adapter->retrain_segment_async(c.seg_id, [&, selected_drift](int id, double d_p99, double d_err, double cost_ms) {
            const int noadapt_calibration_windows = getenv("NOADAPT_CALIBRATION_WINDOWS")
                ? std::max(1, atoi(getenv("NOADAPT_CALIBRATION_WINDOWS")))
                : 6;
            if (!g_flag_disable_adapt || current_window <= noadapt_calibration_windows)
            {
              // Observed utility is the actual residual removed per measured
              // millisecond of real AIDEL training, not a fixed synthetic delta.
              const double reward = (selected_drift / 250.0) /
                                    std::max(1e-6, cost_ms);
              phase1_controller.observeReward(static_cast<uint32_t>(id), reward);
            }
          });
          phase1_cost_ms_sum += g_win.retrain_cost_ms_sum - cost_before;
          usedB_phase1++;
          g_retrained_segments_this_window.insert(c.seg_id);
          dbg_p1("[P1] win=" + std::to_string(current_window) + " step=" + std::to_string(step) +
                 " seg=" + std::to_string(c.seg_id) + " drift=" + std::to_string((int)c.drift) +
                 " already=" + (already_phase1 ? "1" : "0") +
                 " action=exec avoid=" + (gScenario.disable_avoid ? "0" : "1"));
          step++;
        }
        if (g_dbg_phase1)
        {
          std::ostringstream oss;
          oss << "[P1-END] win=" << current_window
              << " total_exec=" << usedB_phase1
              << " recorded_set_sz=" << g_retrained_segments_this_window.size()
              << " {";
          bool first = true;
          for (auto &sid : g_retrained_segments_this_window)
          {
            if (!first)
              oss << ",";
            first = false;
            oss << sid;
          }
          oss << "}";
          dbg_p1(oss.str());
        }
      }
      g_in_linucb_midwindow = false;
    }

    // Phase 1 may consume the complete repair budget. In that case phase 2
    // is correctly skipped, but the post-repair residual still has to be
    // measured. Previously the CSV retained its reset value (zero), making
    // B=1 experiments appear artificially perfect.
    if (baseline_finalized && linucb_phase_enabled &&
        !gScenario.fair_static && !gScenario.greedy_static && !gScenario.static_dp &&
        !g_flag_no_phase2 && usedB_phase1 >= effB && !executed_phase2_this_window)
    {
      topk_sum_post_phase2_us = compute_topk_sum(adapter, (size_t)DRIFT_K);
      if (raw_baseline_topk_sum_us > 0)
        triplet_post_ratio = topk_sum_post_phase2_us / raw_baseline_topk_sum_us;
      executed_phase2_this_window = true;
    }

  if (baseline_finalized && linucb_phase_enabled &&
      !gScenario.fair_static && !gScenario.greedy_static && !gScenario.static_dp &&
      (g_flag_no_phase2 || gScenario.periodic_static || gScenario.threshold_static))
  {
    topk_sum_post_phase2_us = compute_topk_sum(adapter, (size_t)DRIFT_K);
    if (raw_baseline_topk_sum_us > 0)
      triplet_post_ratio = topk_sum_post_phase2_us / raw_baseline_topk_sum_us;
  }

    if (baseline_finalized && linucb_phase_enabled &&
        !gScenario.fair_static && !gScenario.greedy_static && !gScenario.static_dp &&
        !g_flag_no_phase2 && usedB_phase1 < effB && !executed_phase2_this_window)
    {
      auto st = window_decision_snapshot.empty()
                    ? adapter->collect_all_stats()
                    : window_decision_snapshot;
      double p2_thr = gScenario.disable_topk ? 0.0 : (getenv("LINUCB_PHASE2_DRIFT_MIN") ? atof(getenv("LINUCB_PHASE2_DRIFT_MIN")) : 55.0);
      if (!gScenario.disable_topk && tau_us > 0 && phi_us > 0 &&
          !getenv("LINUCB_PHASE2_DRIFT_MIN"))
      {
        p2_thr = std::max(tau_us, std::min(phi_us, tau_us * 1.5));
      }
      struct C2
      {
        int id;
        double drift;
        double cost_ms;
      };
      std::vector<C2> cand;
      cand.reserve(st.size());
      for (auto &s : st)
      {
        if (gScenario.disable_topk)
        {
          if (s.drift > 0)
            cand.push_back({s.seg_id, s.drift, std::max(0.05, s.est_cost_ms)});
        }
        else if (s.drift >= p2_thr)
        {
          cand.push_back({s.seg_id, s.drift, std::max(0.05, s.est_cost_ms)});
        }
      }
      if (gScenario.disable_topk)
      {
        std::shuffle(cand.begin(), cand.end(),
                     std::mt19937{(uint32_t)(0x9E370000 + current_sec)});
      }
      else
      {
        std::vector<double> costs;
        costs.reserve(cand.size());
        for (const auto &c : cand) costs.push_back(c.cost_ms);
        double median_cost = 1.0;
        if (!costs.empty())
        {
          const size_t mid = costs.size() / 2;
          std::nth_element(costs.begin(), costs.begin() + mid, costs.end());
          median_cost = std::max(0.05, costs[mid]);
        }
        std::stable_sort(cand.begin(), cand.end(), [median_cost](const C2 &a, const C2 &b)
        {
          const double ca = std::sqrt(std::clamp(a.cost_ms / median_cost, 0.5, 2.0));
          const double cb = std::sqrt(std::clamp(b.cost_ms / median_cost, 0.5, 2.0));
          const double sa = a.drift / ca;
          const double sb = b.drift / cb;
          return sa == sb ? a.drift > b.drift : sa > sb;
        });
      }
      int max_targets = -1;
      if (const char *v = getenv("LINUCB_PHASE2_MAX_TARGETS"))
      {
        int mt = atoi(v);
        if (mt > 0)
          max_targets = mt;
      }
      size_t cand_idx = 0;
      for (auto &c : cand)
      {
        if (usedB_phase1 + usedB_phase2 >= effB)
          break;
        if (max_targets > 0 && (int)usedB_phase2 >= max_targets)
          break;
        bool already = (g_retrained_segments_this_window.count(c.id) > 0);
        bool redundant = already;
        g_phase2_total_repairs++;
        if (redundant)
          g_phase2_redundant_repairs++;
        std::string action;
        if (!gScenario.disable_avoid && redundant)
        {
          action = "skip_redundant";
          dbg_p2("[P2] win=" + std::to_string(current_window) +
                 " cand_idx=" + std::to_string(cand_idx) +
                 " seg=" + std::to_string(c.id) +
                 " drift=" + std::to_string((int)c.drift) +
                 " already=1 redundant=1 avoid=1 action=" + action);
          cand_idx++;
          continue;
        }
        action = redundant ? "exec_redundant" : "exec";
        if (!gScenario.disable_avoid)
          g_retrained_segments_this_window.insert(c.id);
        bool mark_late = (current_window == 0 && gScenario.late_injected &&
                          std::find(g_late_injected_segments.begin(),
                                    g_late_injected_segments.end(),
                                    c.id) != g_late_injected_segments.end());
        const double cost_before = g_win.retrain_cost_ms_sum;
        auto done = [&, mark_late](int, double, double, double)
        {
          if (mark_late)
            late_segments_repaired++;
        };
        if (gScenario.disable_avoid && redundant)
          adapter->retrain_segment_from_stale_decision(c.id, done);
        else
          adapter->retrain_segment_async(c.id, done);
        phase2_cost_ms_sum += g_win.retrain_cost_ms_sum - cost_before;
        usedB_phase2++;
        phase2_used++;
        dbg_p2("[P2] win=" + std::to_string(current_window) +
               " cand_idx=" + std::to_string(cand_idx) +
               " seg=" + std::to_string(c.id) +
               " drift=" + std::to_string((int)c.drift) +
               " already=" + (already ? "1" : "0") +
               " redundant=" + (redundant ? "1" : "0") +
               " avoid=" + (gScenario.disable_avoid ? "0" : "1") +
               " action=" + action);
        cand_idx++;
      }
      executed_phase2_this_window = true;
      topk_sum_post_phase2_us = compute_topk_sum(adapter, (size_t)DRIFT_K);
      if (raw_baseline_topk_sum_us > 0)
        triplet_post_ratio = topk_sum_post_phase2_us / raw_baseline_topk_sum_us;
      if (g_dbg_phase2)
      {
        double rate = g_phase2_total_repairs ? (double)g_phase2_redundant_repairs / g_phase2_total_repairs : 0.0;
        std::ostringstream oss;
        oss << "[AVOID-METRICS] win=" << current_window
            << " phase2_total=" << g_phase2_total_repairs
            << " redundant=" << g_phase2_redundant_repairs
            << " rate=" << std::fixed << std::setprecision(4) << rate;
        dbg_p2(oss.str());
      }
    }

    // Naive baseline performs no maintenance.
    // Its post-maintenance residual is the current residual.
    if (baseline_finalized && Config.policy == "naive")
    {
      topk_sum_post_phase2_us =
          compute_topk_sum(adapter, (size_t)DRIFT_K);

      if (raw_baseline_topk_sum_us > 0)
        triplet_post_ratio =
            topk_sum_post_phase2_us / raw_baseline_topk_sum_us;
    }

    uint64_t delta = 0;
    for (size_t i = 0; i < N; ++i)
    {
      const uint64_t now_tput = params[i]->throughput.load(std::memory_order_relaxed);
      delta += now_tput - tput_hist[i];
      tput_hist[i] = now_tput;
    }
    sec_tput.push_back(delta);
    if (sec_tput.size() > (size_t)WIN)
      sec_tput.erase(sec_tput.begin());

    // RQ5 defines proof_rate as the probability of auditing one point at each
    // control-window boundary, not as a fraction of foreground requests.  The
    // previous once-per-second opportunity silently doubled the advertised
    // sampling opportunities for two-second windows.
    if (end_of_window && Config.verify_layer == "merklesum" && Config.proof_rate > 0.0)
    {
      std::uniform_real_distribution<double> U(0.0, 1.0);
      if (U(rng_local) < Config.proof_rate)
      {
        const uint64_t proof_key = exist_keys.empty()
                                       ? 0
                                       : static_cast<uint64_t>(exist_keys[
                                             static_cast<size_t>(rng_local() % exist_keys.size())]);
        // RQ5 fault injection: clean / omission / modification / replay.
        // The environment variable is read once per process so every run has
        // one declared mode and can be audited from its launch command.
        static const std::string rq5_fault = []() {
          const char *p = std::getenv("RQ5_FAULT");
          return p ? std::string(p) : std::string("clean");
        }();

        const auto gen_begin = std::chrono::steady_clock::now();
        auto proof = adapter->mst_range_proof(proof_key, proof_key);
        const auto gen_end = std::chrono::steady_clock::now();
        uint64_t root = adapter->mst_root_hash();

        // Preserve the fresh artifact before applying the declared fault.
        const auto fresh_proof = proof;
        int proof_window = current_window;
        bool count_this_audit = true;

        if (rq5_fault == "omission")
        {
          // Remove authenticated evidence.
          proof.covers.clear();
        }
        else if (rq5_fault == "modification")
        {
          // Corrupt authenticated proof material; fall back to the root only
          // if an implementation change ever yields an empty cover list.
          if (!proof.covers.empty())
            proof.covers[0].h ^= uint64_t{1};
          else
            root ^= uint64_t{1};
        }
        else if (rq5_fault == "replay")
        {
          // Replay the previously sampled valid artifact.  The first sampled
          // audit only seeds the cache and is not counted as an injected fault.
          static bool replay_have_previous = false;
          static mks::RangeProof replay_previous_proof;
          static int replay_previous_window = -1;

          if (replay_have_previous)
          {
            proof = replay_previous_proof;
            proof_window = replay_previous_window;
          }
          else
          {
            count_this_audit = false;
          }

          replay_previous_proof = fresh_proof;
          replay_previous_window = current_window;
          replay_have_previous = true;
        }
        else if (rq5_fault != "clean")
        {
          std::cerr << "[RQ5] unknown fault mode: " << rq5_fault << std::endl;
          std::exit(2);
        }

        const auto ver_begin = std::chrono::steady_clock::now();
        const bool cryptographic_ok = mks::MerkleSum().verify(proof, root);
        // A previously valid proof must also belong to the current control
        // window; this freshness check is what exposes replay.
        const bool freshness_ok = (proof_window == current_window);
        const bool proof_ok = cryptographic_ok && freshness_ok;
        const auto ver_end = std::chrono::steady_clock::now();

        if (count_this_audit)
        {
          if (rq5_fault == "clean")
          {
            if (!proof_ok)
              g_win.false_positives++;
          }
          else
          {
            g_win.fault_attempts++;
            if (!proof_ok)
              g_win.fault_detected++;
          }

          last_proof_gen_us = std::chrono::duration<double, std::micro>(gen_end - gen_begin).count();
          last_proof_ver_us = std::chrono::duration<double, std::micro>(ver_end - ver_begin).count();
          g_win.proof_cnt++;
          g_win.proof_gen_ns_sum += static_cast<uint64_t>(last_proof_gen_us * 1000.0);
          g_win.proof_ver_ns_sum += static_cast<uint64_t>(last_proof_ver_us * 1000.0);
          if (!proof_ok)
            g_win.proof_fail++;
        }
      }
    }

    if (end_of_window)
    {
      double tput_avg = 0.0;
      for (auto v : sec_tput)
        tput_avg += (double)v;
      if (!sec_tput.empty())
        tput_avg /= (double)sec_tput.size();
      static double last_win_tput_avg = 0.0;
      static double last_win_p99_ms = 0.0;
      std::vector<uint32_t> window_latencies;
      for (size_t i = 0; i < N; ++i)
      {
        std::lock_guard<std::mutex> lk(params[i]->lat_mu);
        window_latencies.insert(window_latencies.end(),
                                params[i]->lat_samples_ns.begin(),
                                params[i]->lat_samples_ns.end());
        params[i]->lat_samples_ns.clear();
      }
      double p99_after_ms = 0.0;
      if (!window_latencies.empty())
      {
        const size_t rank = (window_latencies.size() * 99 + 99) / 100;
        const size_t idx = std::min(window_latencies.size() - 1, rank - 1);
        std::nth_element(window_latencies.begin(), window_latencies.begin() + idx,
                         window_latencies.end());
        p99_after_ms = static_cast<double>(window_latencies[idx]) / 1.0e6;
      }
      if (Config.policy == "linucb" && g_flag_single_phase)
        g_win.retrain_cnt = (int)g_retrained_segments_this_window.size();
      double avg_gen_us = g_win.proof_cnt ? (double)g_win.proof_gen_ns_sum / g_win.proof_cnt / 1000.0 : 0.0;
      double avg_ver_us = g_win.proof_cnt ? (double)g_win.proof_ver_ns_sum / g_win.proof_cnt / 1000.0 : 0.0;
      double phase1_ratio = (usedB_phase1 + usedB_phase2) ? (double)usedB_phase1 / (usedB_phase1 + usedB_phase2) : 0.0;
      // Real retraining latency statistics for this window
    size_t retrain_exec_cnt = g_win.retrain_cost_ms_samples.size();

    double retrain_latency_mean_ms = 0.0;
    double retrain_latency_p50_ms = 0.0;
    double retrain_latency_p95_ms = 0.0;
    double retrain_latency_max_ms = 0.0;

    if (!g_win.retrain_cost_ms_samples.empty())
    {
        std::vector<double> retrain_sorted = g_win.retrain_cost_ms_samples;
        std::sort(retrain_sorted.begin(), retrain_sorted.end());

        double retrain_sum = 0.0;
        for (double x : retrain_sorted)
            retrain_sum += x;

        retrain_latency_mean_ms =
            retrain_sum / static_cast<double>(retrain_sorted.size());

        const size_t n = retrain_sorted.size();

        // Nearest-rank percentiles
        size_t p50_idx = (n * 50 + 99) / 100;
        size_t p95_idx = (n * 95 + 99) / 100;

        if (p50_idx > 0) --p50_idx;
        if (p95_idx > 0) --p95_idx;

        if (p50_idx >= n) p50_idx = n - 1;
        if (p95_idx >= n) p95_idx = n - 1;

        retrain_latency_p50_ms = retrain_sorted[p50_idx];
        retrain_latency_p95_ms = retrain_sorted[p95_idx];
        retrain_latency_max_ms = retrain_sorted.back();
    }

    if (csv_logger && csv_logger->good())
      {
        static bool header = false;
        if (!header)
        {
          (*csv_logger->ostream())
              << "time_ms,window_id,policy,baseline_tag,budget_B,budget_used,"
              << "tput_before,tput_after,p99_before_ms,p99_after_ms,"
              << "retrain_cost_ms_sum,retrain_exec_cnt,retrain_latency_mean_ms,"
            << "retrain_latency_p50_ms,retrain_latency_p95_ms,retrain_latency_max_ms,"
            << "phase1_cost_ms_sum,phase2_cost_ms_sum,"
              << "usedB_phase1,usedB_phase2,phase2_used,phase1_ratio,"
              << "proof_gen_us_last,proof_ver_us_last,proof_samples,proof_failures,"
              << "fault_attempts,fault_detected,false_positives,"
              << "proof_gen_avg_us,proof_ver_avg_us,"
              << "raw_baseline_topk_sum_us,"
              << "topk_sum_post_injection_us,topk_sum_post_phase2_us,peak_topk_sum_us,budget_oracle_topk_target_us,triplet_post_ratio,"
              << "injection_flag,phase2_total_repairs,phase2_redundant_repairs,phase2_redundant_rate,"
              << "mid_inject_flag,late_inject_flag,late_segments_repaired,tail_active_count\n";
          header = true;
        }
        int injection_flag = injected_this_window ? 1 : 0;
        std::string baseline_tag = "adaptive";
        if (gScenario.greedy_static)
          baseline_tag = "greedy";
        else if (gScenario.static_dp_limited)
          baseline_tag = "staticdp_limited";
        else if (gScenario.static_dp)
          baseline_tag = "staticdp";
        else if (gScenario.fair_static)
          baseline_tag = "staticfair";
    else if (gScenario.periodic_static)
        baseline_tag = "periodic";
    else if (gScenario.threshold_static)
        baseline_tag = "threshold";
        else if (Config.policy == "naive")
          baseline_tag = "naive";
        else if (g_flag_single_phase)
          baseline_tag = "greedy";
        else if (g_flag_disable_adapt && !g_flag_no_phase2)
          baseline_tag = "staticdp";
        else if (g_flag_no_phase2)
          baseline_tag = "nophase2";
        else if (gScenario.disable_avoid)
          baseline_tag = "noavoid";
        else if (gScenario.disable_topk)
          baseline_tag = "notopk";
        else if (Config.policy == "off")
          baseline_tag = "off";
        double p2_rate = g_phase2_total_repairs ? (double)g_phase2_redundant_repairs / g_phase2_total_repairs : 0.0;
        int64_t now_ms = (int64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
                             std::chrono::steady_clock::now().time_since_epoch())
                             .count();
        (*csv_logger->ostream())
            << now_ms << ","
            << (current_window + 1) << ","
            << Config.policy << ","
            << baseline_tag << ","
            << Config.budget_B << ","
            << (usedB_phase1 + usedB_phase2) << ","
            << last_win_tput_avg << ","
            << tput_avg << ","
            << last_win_p99_ms << ","
            << p99_after_ms << ","
            << g_win.retrain_cost_ms_sum << ","
            << retrain_exec_cnt << ","
            << retrain_latency_mean_ms << ","
            << retrain_latency_p50_ms << ","
            << retrain_latency_p95_ms << ","
            << retrain_latency_max_ms << ","
            << phase1_cost_ms_sum << ","
            << phase2_cost_ms_sum << ","
            << usedB_phase1 << ","
            << usedB_phase2 << ","
            << phase2_used << ","
            << phase1_ratio << ","
            << last_proof_gen_us << ","
            << last_proof_ver_us << ","
            << g_win.proof_cnt << ","
            << g_win.proof_fail << ","
            << g_win.fault_attempts << ","
            << g_win.fault_detected << ","
            << g_win.false_positives << ","
            << avg_gen_us << ","
            << avg_ver_us << ","
            << raw_baseline_topk_sum_us << ","
            << topk_sum_post_injection_us << ","
            << topk_sum_post_phase2_us << ","
            << peak_topk_sum_us << ","
            << budget_oracle_topk_target_us << ","
            << triplet_post_ratio << ","
            << injection_flag << ","
            << g_phase2_total_repairs << ","
            << g_phase2_redundant_repairs << ","
            << p2_rate << ","
            << (mid_inject_flag ? 1 : 0) << ","
            << (late_inject_flag ? 1 : 0) << ","
            << late_segments_repaired << ","
            << adapter->tail_active_count()
            << "\n";
      }
      last_win_tput_avg = tput_avg;
      last_win_p99_ms = p99_after_ms;
      g_win.reset();
    }
    ++current_sec;
  }

  running = false;
  for (size_t i = 0; i < N; ++i)
  {
    void *st = nullptr;
    pthread_join(threads[i], &st);
  }
  size_t total_tput = 0;
  for (size_t i = 0; i < N; ++i)
    total_tput += params[i]->throughput.load(std::memory_order_relaxed);
  COUT_THIS("[micro] Throughput(op/s): " << (sec ? (total_tput / sec) : total_tput));
  for (auto *p : params)
    delete p;
}

int main(int argc, char **argv)
{
  preprocess_claims_args(argc, argv);
  parse_args(argc, argv);

  g_flag_single_phase = env_on("LINUCB_SINGLE_PHASE");
  g_flag_disable_runtime = env_on("LINUCB_DISABLE_RUNTIME");
  g_flag_disable_adapt = env_on("LINUCB_DISABLE_ADAPT") ||
                         g_flag_disable_runtime ||
                         g_flag_single_phase;
  g_flag_use_max_only = env_on("USE_MAX_ONLY");
  g_flag_select_random = env_on("SELECT_RANDOM");
  g_flag_no_phase2 = env_on("NO_PHASE2");
  g_flag_output_debug = env_on("SHOW_PHASE2_DEBUG") || env_on("SHOW_TOPK_DEBUG");
  init_avoid_debug_flags();

  if (gScenario.proof_rate_override >= 0.0)
    Config.proof_rate = gScenario.proof_rate_override;

  load_data();
  init_base_latency_from_env();
  detect_drift_enabled_once();

  aidel_type *ai = new aidel_type();
  ai->train(exist_keys, exist_keys, Config.maxErr);
  auto err_stats = compute_error_stats(ai, exist_keys);
  ai->self_check();

  auto getenv_i = [](const char *k, int d) -> int
  { if(const char* v=getenv(k)){ try{return std::stoi(v);}catch(...){}} return d; };
  int seg_cnt = getenv_i("SEGMENT_COUNT", 256);
  AidelAdapter adapter(ai, exist_keys, (size_t)seg_cnt);

  // The benchmark owns the per-window scheduler. Running the background
  // runtime as well would double-spend the maintenance budget and produce
  // unlogged retrains.
  bool runtime_active = false;
  std::unique_ptr<LinVeriXRuntime> rt;
  if (runtime_active)
  {
    LinVeriXRuntime::Config cfg;
    cfg.epoch_ms = std::max(1, Config.win_sec) * 1000;
    cfg.budget_B = Config.budget_B;
    cfg.alpha = Config.alpha;
    rt.reset(new LinVeriXRuntime(&adapter, cfg));
    rt->start();
  }

  VerifyService::Config vcfg;
  vcfg.num_workers = Config.thread_num;
  vcfg.queue_cap = 1 << 16;
  vcfg.batch_max = (gScenario.proof_batch_override > 0) ? gScenario.proof_batch_override : 4096;
  vcfg.batch_interval_ms = 2;
  vcfg.point_proof_sample =
      (Config.verify_layer == "merklesum") ? Config.proof_rate : 0.0;
  VerifyService verifier(&adapter, vcfg);
  verifier.start();

  CsvLogger logger(Config.csv_log, true);
  run_benchmark(ai, &adapter, &verifier, Config.runtime, err_stats, &logger, ai->model_size());

  if (rt)
    rt->stop();
  verifier.stop();
  if (Config.verify_layer == "merklesum" && Config.proof_rate > 0.0)
    run_verification(ai);
  ai->self_check();
  delete ai;
  return 0;
}
