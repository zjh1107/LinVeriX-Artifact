#include <iostream>
#include <vector>
#include <cstdint>
#include "levelindex.h"
#include "linverix_adapter_levelindex.h"
#include "linverix_runtime.h"

int main(){
  // 1) 构造真实 LevelIndex
  std::vector<uint64_t> data;
  data.reserve(100000);
  for (uint64_t k=1;k<=100000;++k) data.push_back(k);
  LevelIndex<uint64_t> index(data);

  // 2) 适配器 + Merkle-sum 初始化
  LevelIndexAdapter<uint64_t> adapter(&index);
  adapter.mst_build_if_needed();

  // 3) LinUCB 运行时
  LinVeriXRuntime::Config cfg; cfg.epoch_ms=800; cfg.budget_B=3; cfg.alpha=1.0;
  LinVeriXRuntime runtime(&adapter, cfg);
  runtime.start();

  // 4) 模拟一些查询，顺便记到适配器做统计
  for (uint64_t k=1; k<=50000; k+=17){
    size_t pos = index.find(k);
    (void)pos;
    adapter.note_query_by_key(k, /*latency_ms=*/10.0, /*is_write=*/(k%101==0));
  }

  // 5) 生成一次范围 SUM 证明
  auto proof = adapter.mst_range_proof(100, 9999);
  bool ok = mks::MerkleSum().verify(proof, adapter.mst_root_hash()); // 静态验证器用同一实现
  std::cout << "Proof ok = " << std::boolalpha << ok << "\n";

  // 让 runtime 跑几轮
  std::this_thread::sleep_for(std::chrono::seconds(3));
  runtime.stop();
  return 0;
}