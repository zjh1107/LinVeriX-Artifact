#!/usr/bin/env bash
set -euo pipefail
repo_root="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$repo_root/build"
if command -v cmake >/dev/null 2>&1; then
  cmake -S "$repo_root" -B "$repo_root/build" -DCMAKE_BUILD_TYPE=Release
  cmake --build "$repo_root/build" -j"${BUILD_JOBS:-$(nproc)}" --target linverix_aidel_benchmark
else
  echo "[WARN] cmake not found; using the equivalent direct g++ build"
  "${CXX:-g++}" -std=c++17 -O3 -DNDEBUG -Wno-deprecated-declarations \
    -I"$repo_root" -I"$repo_root/include" -I"$repo_root/config" -I"$repo_root/util" \
    "$repo_root/examples/linverix_aidel_benchmark.cc" \
    "$repo_root/src/linucb_controller.cc" "$repo_root/config/base_latency.cpp" \
    "$repo_root/src/data_globals.cpp" -pthread -lcrypto -lm -ldl \
    -o "$repo_root/build/linverix_aidel_benchmark"
fi
echo "[DONE] $repo_root/build/linverix_aidel_benchmark"
