#pragma once
#include <chrono>
#include <thread>

inline void busy_wait_ns(uint64_t ns) {
    if (ns == 0) return;
    auto start = std::chrono::high_resolution_clock::now();
    while (true) {
        auto now = std::chrono::high_resolution_clock::now();
        if (std::chrono::duration_cast<std::chrono::nanoseconds>(now - start).count() >= (long long)ns) break;
    }
}