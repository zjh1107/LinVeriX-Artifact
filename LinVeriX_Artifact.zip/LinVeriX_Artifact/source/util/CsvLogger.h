#pragma once
#include <fstream>
#include <string>
#include <vector>
#include <cstdint>
#include <iostream>

class CsvLogger {
public:
    explicit CsvLogger(const std::string& path, bool extended=false)
        : extended_(extended)
    {
        out_.open(path);
        if (!out_) {
            std::cerr << "[CsvLogger] open failed: " << path << "\n";
            return;
        }
        // 如果你原来会先写 header，可以保留；这里不自动写 header，让外部手写
    }

    bool good() const { return out_.good(); }

    // 旧接口：如果别的地方还在用，可保留
    void write_row_basic(int64_t time_ms, int win_id, const std::string& policy,
                         int budget_B, double last_tput_avg, double tput_avg,
                         double last_p99_ms, double p99_after_ms,
                         double retrain_cost_ms, int retrain_cnt,
                         int proof_cnt, int proof_fail,
                         double avg_gen_us, double avg_ver_us) {
        if (!out_) return;
        out_ << time_ms << ',' << win_id << ',' << policy << ',' << budget_B << ','
             << last_tput_avg << ',' << tput_avg << ',' << last_p99_ms << ',' << p99_after_ms << ','
             << retrain_cost_ms << ',' << retrain_cnt << ',' << proof_cnt << ',' << proof_fail << ','
             << avg_gen_us << ',' << avg_ver_us << '\n';
    }

    // === 新增：提供底层流指针，支持你现有 csv_logger->ostream() 写自定义列 ===
    std::ostream* ostream() { return &out_; }

private:
    std::ofstream out_;
    bool extended_{false};
};