"""Reconcile per-window budget counters in archived RQ4 formal CSVs."""

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "formal_results" / "RQ4_Audit" / "rq4"
OUT = ROOT / "formal_results" / "RQ4_Audit" / "budget_reconciliation.csv"

totals = dict(runs=0, windows=0, budget_violations=0,
              phase_budget_violations=0, execution_budget_violations=0,
              used_execution_mismatches=0)
for path in sorted(SOURCE.glob("*.csv")):
    totals["runs"] += 1
    with path.open(newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            totals["windows"] += 1
            budget = int(float(row["budget_B"]))
            used = int(float(row["budget_used"]))
            phase1 = int(float(row["usedB_phase1"]))
            phase2 = int(float(row["usedB_phase2"]))
            executed = int(float(row["retrain_exec_cnt"]))
            totals["budget_violations"] += used > budget
            totals["phase_budget_violations"] += phase1 + phase2 > budget
            totals["execution_budget_violations"] += executed > budget
            totals["used_execution_mismatches"] += used != executed

with OUT.open("w", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(totals))
    writer.writeheader()
    writer.writerow(totals)
print(totals)
