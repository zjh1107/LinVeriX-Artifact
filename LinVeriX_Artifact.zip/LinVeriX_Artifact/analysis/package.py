"""Create a checksum manifest and ZIP archive for the experiment artifact."""

from __future__ import annotations

import hashlib
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "MANIFEST_SHA256.txt"
ARCHIVE = ROOT.parent / "LinVeriX_Artifact.zip"
ARCHIVE_ROOT = "LinVeriX_Artifact"


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


files = sorted(
    (path for path in ROOT.rglob("*") if path.is_file() and path != MANIFEST),
    key=lambda path: path.relative_to(ROOT).as_posix(),
)
MANIFEST.write_text(
    "".join(f"{digest(path)}  {path.relative_to(ROOT).as_posix()}\n" for path in files),
    encoding="utf-8",
)
with zipfile.ZipFile(ARCHIVE, "w", zipfile.ZIP_DEFLATED, compresslevel=7) as output:
    for path in [*files, MANIFEST]:
        output.write(path, (ARCHIVE_ROOT + "/" + path.relative_to(ROOT).as_posix()))
print(f"Created {ARCHIVE} with {len(files) + 1} files")
