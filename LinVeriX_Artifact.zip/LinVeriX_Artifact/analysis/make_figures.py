"""Generate the paper's RQ1/RQ3/RQ5/RQ6 figures from formal CSV records.

Requires ReportLab. The figures are vector PDFs; all numeric values come from
the archived seed-level logs or their recorded formal-run aggregates.
"""
from __future__ import annotations

import csv
import math
import statistics
import argparse
from pathlib import Path

from reportlab.lib import colors
from reportlab.pdfgen import canvas


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "formal_results"
OUT = ROOT / "generated_figures"

# Colorblind-safe, high-contrast palette (Okabe-Ito family).
BLUE = colors.HexColor("#0072B2")
ORANGE = colors.HexColor("#E69F00")
VERMILLION = colors.HexColor("#D55E00")
GREEN = colors.HexColor("#009E73")
GRAY = colors.HexColor("#777777")
INK = colors.HexColor("#252A30")
GRID = colors.HexColor("#D9DEE4")
PALETTE = {
    "linverix": BLUE,
    "greedy": VERMILLION,
    "threshold": GRAY,
    "periodic": GREEN,
}
POLICIES = ["linverix", "greedy", "threshold", "periodic"]
POLICY_LABELS = {
    "linverix": "LinVeriX",
    "greedy": "Greedy",
    "threshold": "Threshold",
    "periodic": "Periodic",
}
T95_N5 = 2.7764451051977987


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def new_canvas(name: str, width: int, height: int) -> canvas.Canvas:
    return canvas.Canvas(str(OUT / name), pagesize=(width, height), pageCompression=1)


def text(c: canvas.Canvas, x: float, y: float, value: object, size: float = 8.5,
         bold: bool = False, align: str = "left", color=INK) -> None:
    c.setFillColor(color)
    c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
    draw = {"left": c.drawString, "center": c.drawCentredString,
            "right": c.drawRightString}[align]
    draw(x, y, str(value))


def line(c: canvas.Canvas, x0: float, y0: float, x1: float, y1: float,
         color=INK, width: float = 0.8) -> None:
    c.setStrokeColor(color)
    c.setLineWidth(width)
    c.line(x0, y0, x1, y1)


def ci_bar(c: canvas.Canvas, x: float, y0: float, y1: float,
           cap: float = 3.0, width: float = 0.8) -> None:
    line(c, x, y0, x, y1, INK, width)
    line(c, x - cap, y0, x + cap, y0, INK, width)
    line(c, x - cap, y1, x + cap, y1, INK, width)


def legend(c: canvas.Canvas, items: list[tuple[str, colors.Color]],
           y: float, center_x: float = 260) -> None:
    widths = [20 + 6.5 * len(label) for label, _ in items]
    gap = 16
    x = center_x - (sum(widths) + gap * (len(items) - 1)) / 2
    for (label, color), item_width in zip(items, widths):
        c.setFillColor(color)
        c.rect(x, y - 1, 9, 9, fill=1, stroke=0)
        text(c, x + 14, y, label, 8.5)
        x += item_width + gap


def grouped_panel(c: canvas.Canvas, *, x: float, y: float, width: float,
                  height: float, groups: list[str], values: list[list[float]],
                  errors: list[list[float]], maximum: float, ticks: list[float],
                  axis_label: str, series: list[str]) -> None:
    """Grouped bars with 95% CI whiskers; labels stay >= 8 pt."""
    text(c, x, y + height + 11, axis_label, 9.2, bold=True)
    for tick in ticks:
        yy = y + height * tick / maximum
        line(c, x, yy, x + width, yy, GRID, 0.6)
        text(c, x - 7, yy - 2.8, f"{tick:g}", 8, align="right", color=GRAY)
    line(c, x, y, x, y + height, INK, 0.8)
    line(c, x, y, x + width, y, INK, 0.8)

    group_width = width / len(groups)
    inner_width = group_width * 0.78
    slot_width = inner_width / len(series)
    bar_width = slot_width * 0.76
    for group_index, group in enumerate(groups):
        center = x + group_width * (group_index + 0.5)
        text(c, center, y - 16, group, 8.5, align="center")
        for series_index, policy in enumerate(series):
            value = values[group_index][series_index]
            error = errors[group_index][series_index]
            bx = center - inner_width / 2 + series_index * slot_width + (slot_width - bar_width) / 2
            bar_height = height * value / maximum
            c.setFillColor(PALETTE[policy])
            c.rect(bx, y, bar_width, bar_height, fill=1, stroke=0)
            if error > 0:
                cx = bx + bar_width / 2
                low = y + height * max(0, value - error) / maximum
                high = y + height * min(maximum, value + error) / maximum
                ci_bar(c, cx, low, high, cap=2.5, width=0.75)


def raw_case_summary(folder: Path, prefixes: list[str]) -> dict[str, dict[str, float]]:
    """Aggregate 290 evaluated windows per seed, then summarize five seeds."""
    result: dict[str, dict[str, float]] = {}
    for prefix in prefixes:
        files = sorted(folder.glob(f"{prefix}_s*.csv"))
        if len(files) != 5:
            raise ValueError(f"Expected five formal seed logs for {prefix}; found {len(files)}")
        per_seed = {"p99": [], "residual": [], "maintenance": []}
        for path in files:
            rows = [row for row in read_rows(path) if int(row["window_id"]) > 10]
            if len(rows) != 290:
                raise ValueError(f"Expected 290 evaluated windows in {path.name}; found {len(rows)}")
            per_seed["p99"].append(statistics.mean(float(row["p99_after_ms"]) * 1000 for row in rows))
            per_seed["residual"].append(statistics.mean(float(row["topk_sum_post_phase2_us"]) for row in rows))
            per_seed["maintenance"].append(statistics.mean(float(row["retrain_cost_ms_sum"]) for row in rows))
        result[prefix] = {}
        for metric, values in per_seed.items():
            result[prefix][metric] = statistics.mean(values)
            result[prefix][metric + "_ci"] = T95_N5 * statistics.stdev(values) / math.sqrt(5)
    return result


def rq1() -> None:
    datasets = ["books", "facebook", "wiki"]
    names = {"books": "Books", "facebook": "Facebook", "wiki": "Wiki"}
    data = {
        dataset: {row["policy"]: row for row in read_rows(RESULTS / "RQ1_AIDEL" / dataset / "aggregate.csv")}
        for dataset in datasets
    }
    c = new_canvas("rq1_overall.pdf", 540, 224)
    config = [
        (40, "Foreground P99 (µs)", "p99_after_ms_mean", "p99_after_ms_ci95", 1500,
         [0, 500, 1000, 1500], 1000),
        (212, "P99-degradation AUC (10^6 s)", "p99_auc_s_mean", "p99_auc_s_ci95", 1.8,
         [0, 0.6, 1.2, 1.8], 1e-6),
        (384, "Top-6 residual (µs)", "mean_residual_us_mean", "mean_residual_us_ci95", 10500,
         [0, 3500, 7000, 10500], 1),
    ]
    for x, label, mean_key, ci_key, maximum, ticks, scale in config:
        values = [[float(data[d][p][mean_key]) * scale for p in POLICIES] for d in datasets]
        errors = [[float(data[d][p][ci_key]) * scale for p in POLICIES] for d in datasets]
        grouped_panel(c, x=x, y=50, width=132, height=128,
                      groups=[names[d] for d in datasets], values=values, errors=errors,
                      maximum=maximum, ticks=ticks, axis_label=label, series=POLICIES)
    legend(c, [(POLICY_LABELS[p], PALETTE[p]) for p in POLICIES], y=12,
           center_x=270)
    c.showPage()
    c.save()


def rq3() -> None:
    data = raw_case_summary(RESULTS / "RQ3_Ablation" / "rq3",
                            ["full", "no_avoid", "no_phase2", "no_topk"])
    labels = ["Full", "No Avoidance", "No Phase 2", "No Top-K"]
    keys = ["full", "no_avoid", "no_phase2", "no_topk"]
    c = new_canvas("rq3_ablation.pdf", 520, 225)
    chart_left, chart_right, chart_width = 152, 350, 158
    base_y, chart_height = 45, 137
    panel_specs = [
        (chart_left, "Foreground P99 (µs)", "p99", 2100, [0, 700, 1400, 2100]),
        (chart_right, "Top-6 residual (µs)", "residual", 12500, [0, 4000, 8000, 12000]),
    ]
    row_centers = [base_y + chart_height * (3.5 - i) / 4 for i in range(4)]
    for x, label, key, maximum, ticks in panel_specs:
        text(c, x, base_y + chart_height + 11, label, 9.2, bold=True)
        for tick in ticks:
            xx = x + chart_width * tick / maximum
            line(c, xx, base_y, xx, base_y + chart_height, GRID, 0.6)
            text(c, xx, base_y - 14, f"{tick:g}", 8, align="center", color=GRAY)
        line(c, x, base_y, x + chart_width, base_y, INK, 0.8)
        for row_index, case in enumerate(keys):
            y_center = row_centers[row_index]
            value = data[case][key]
            error = data[case][key + "_ci"]
            bar_color = BLUE if case == "full" else GRAY
            c.setFillColor(bar_color)
            c.rect(x, y_center - 6.5, chart_width * value / maximum, 13,
                   fill=1, stroke=0)
            xerr0 = x + chart_width * max(0, value - error) / maximum
            xerr1 = x + chart_width * min(maximum, value + error) / maximum
            line(c, xerr0, y_center, xerr1, y_center, INK, 0.75)
            line(c, xerr0, y_center - 3.3, xerr0, y_center + 3.3, INK, 0.75)
            line(c, xerr1, y_center - 3.3, xerr1, y_center + 3.3, INK, 0.75)
    for y_center, label in zip(row_centers, labels):
        text(c, 142, y_center - 3, label, 8.5, align="right")
    c.showPage()
    c.save()


def rq5() -> None:
    data = raw_case_summary(RESULTS / "RQ5_Budget" / "rq5", ["B1", "B2", "B4", "B6"])
    budgets = [1, 2, 4, 6]
    c = new_canvas("rq5_budget.pdf", 520, 225)
    specs = [
        (34, "Foreground P99 (µs)", "p99", 1600, [0, 800, 1600], BLUE),
        (202, "Top-6 residual (µs)", "residual", 9000, [0, 4500, 9000], ORANGE),
        (370, "Maintenance (ms/window)", "maintenance", 11, [0, 5.5, 11], GREEN),
    ]
    y0, plot_height, plot_width = 52, 122, 130
    xmin, xmax = 0.5, 6.5
    for x0, label, metric, maximum, ticks, color in specs:
        text(c, x0, y0 + plot_height + 12, label, 9, bold=True)
        for tick in ticks:
            yy = y0 + plot_height * tick / maximum
            line(c, x0, yy, x0 + plot_width, yy, GRID, 0.6)
            text(c, x0 - 5, yy - 2.8, f"{tick:g}", 8, align="right", color=GRAY)
        line(c, x0, y0, x0, y0 + plot_height, INK, 0.8)
        line(c, x0, y0, x0 + plot_width, y0, INK, 0.8)
        def px(budget: int) -> float:
            return x0 + plot_width * (budget - xmin) / (xmax - xmin)
        points = []
        for budget in budgets:
            row = data[f"B{budget}"]
            value = row[metric]
            error = row[metric + "_ci"]
            xx = px(budget)
            yy = y0 + plot_height * value / maximum
            points.append((xx, yy))
            low = y0 + plot_height * max(0, value - error) / maximum
            high = y0 + plot_height * min(maximum, value + error) / maximum
            ci_bar(c, xx, low, high, cap=2.4, width=0.8)
            c.setFillColor(color)
            c.circle(xx, yy, 3.2, fill=1, stroke=0)
            text(c, xx, y0 - 15, budget, 8.5, align="center")
        for (x1, y1), (x2, y2) in zip(points, points[1:]):
            line(c, x1, y1, x2, y2, color, 1.8)
        for xx, yy in points:
            c.setFillColor(color)
            c.circle(xx, yy, 3.2, fill=1, stroke=0)
    text(c, 260, 12, "Budget per window, B", 8.5, align="center")
    c.showPage()
    c.save()


def rq6() -> None:
    data = {row["policy"]: row for row in read_rows(RESULTS / "RQ6_PGM" / "aggregate.csv")}
    policies = POLICIES
    c = new_canvas("rq6_pgm.pdf", 540, 215)
    specs = [
        (40, "Foreground P99 (µs)", "p99_after_ms_mean", "p99_after_ms_ci95", 1250,
         [0, 400, 800, 1200], 1000),
        (212, "P99-degradation AUC (10^6 s)", "p99_auc_s_mean", "p99_auc_s_ci95", 1.8,
         [0, 0.6, 1.2, 1.8], 1e-6),
        (384, "Top-6 residual (µs)", "mean_residual_us_mean", "mean_residual_us_ci95", 7000,
         [0, 2000, 4000, 6000], 1),
    ]
    for x, label, mean_key, ci_key, maximum, ticks, scale in specs:
        values = [[float(data[p][mean_key]) * scale for p in policies]]
        errors = [[float(data[p][ci_key]) * scale for p in policies]]
        grouped_panel(c, x=x, y=49, width=132, height=127,
                      groups=["Books"], values=values, errors=errors,
                      maximum=maximum, ticks=ticks, axis_label=label, series=policies)
    legend(c, [(POLICY_LABELS[p], PALETTE[p]) for p in POLICIES], y=12,
           center_x=270)
    c.showPage()
    c.save()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--out-dir", type=Path, default=ROOT / "generated_figures",
        help="directory for regenerated vector figures",
    )
    args = parser.parse_args()
    OUT = args.out_dir
    OUT.mkdir(parents=True, exist_ok=True)
    rq1()
    rq3()
    rq5()
    rq6()
    print("Generated RQ1, RQ3, RQ5, and RQ6 vector figures from formal results.")
